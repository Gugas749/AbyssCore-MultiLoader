package com.gugas749.abysscore.platform.services;

import net.minecraft.class_3222;
import net.minecraft.class_8710;

/**
 * Loader-neutral contract for sending packets.
 *
 * Common code calls AbyssNetwork.sendToX() which delegates here.
 * Each loader module provides one implementation registered in META-INF/services/.
 *
 * Why CustomPacketPayload as the parameter type?
 * It is a vanilla Minecraft interface (net.minecraft.network.protocol.common.custom),
 * so it is safe to use in common without any loader imports.
 */
public interface INetworkPlatform {

    void sendToPlayer(class_3222 player, class_8710 packet);

    void sendToServer(class_8710 packet);
}
