package com.gugas749.abysscore.api.gui.widget;

import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_5481;
import net.minecraft.class_6381;
import net.minecraft.class_6382;

/**
 * A line of text as a widget — so it can go into a layout next to buttons.
 * Too long for its width → cut with "…". Not clickable.
 *
 *   AbyssLabel status = ctx.add(new AbyssLabel(0, 0, 150, Component.literal("Ready")));
 *   status.setText(Component.literal("Saved!"));
 */
public class AbyssLabel extends class_339 {

    public enum Align { LEFT, CENTER, RIGHT }

    private class_2561 text;
    private int color = AbyssTheme.TEXT;
    private Align align = Align.LEFT;

    public AbyssLabel(int x, int y, int width, class_2561 text) {
        super(x, y, width, 9, text);
        this.text = text;
        this.field_22763 = false;   // display only
    }

    public AbyssLabel setText(class_2561 text) { this.text = text; method_25355(text); return this; }
    public AbyssLabel color(int argb) { this.color = argb; return this; }
    public AbyssLabel align(Align align) { this.align = align; return this; }

    @Override
    protected void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        var font = class_310.method_1551().field_1772;
        var line = AbyssDraw.trimmed(font, text, method_25368());
        int w = font.method_30880(line);
        int x = switch (align) {
            case LEFT -> method_46426();
            case CENTER -> method_46426() + (method_25368() - w) / 2;
            case RIGHT -> method_46426() + method_25368() - w;
        };
        g.method_51430(font, line, x, method_46427(), color, true);
    }

    @Override
    protected void method_47399(class_6382 output) {
        output.method_37034(class_6381.field_33788, text);
    }
}
