package com.gugas749.abysscore.api.gui.widget;

import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import javax.annotation.Nullable;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * A scrollable list of ANY kind of item. You decide how a row looks:
 *
 *   AbyssScrollList<String> list = new AbyssScrollList<>(x, y, 200, 120, 12,
 *       (g, name, rx, ry, rw, rh, hovered, selected) ->
 *           g.drawString(font, name, rx, ry + 2, AbyssTheme.TEXT, true));
 *   list.setItems(playerNames);
 *   list.onSelect(name -> selectedLabel.setText(Component.literal(name)));
 *
 * Hover + selection highlights, mouse wheel, draggable scrollbar and the "empty" text
 * are handled here; the row renderer only draws the row's content.
 */
public class AbyssScrollList<T> extends class_339 {

    /** Draws one row's content. (x, y, width, height) = the row's area. */
    @FunctionalInterface
    public interface RowRenderer<T> {
        void render(class_332 g, T item, int x, int y, int width, int height, boolean hovered, boolean selected);
    }

    private static final int SCROLL_GAP = 2;

    private final int rowHeight;
    private final RowRenderer<T> renderer;
    private List<T> items = new ArrayList<>();
    @Nullable private T selected;
    private boolean selectable = true;
    @Nullable private Consumer<T> onSelect;
    private class_2561 emptyText = class_2561.method_43471("gui.abysscore.list.empty");

    private int scroll = 0;              // index of the first visible row
    private boolean draggingScrollbar = false;

    public AbyssScrollList(int x, int y, int width, int height, int rowHeight, RowRenderer<T> renderer) {
        super(x, y, width, height, class_2561.method_43473());
        this.rowHeight = rowHeight;
        this.renderer = renderer;
    }

    // ── API ────────────────────────────────────────────────────────────────────

    /** Replaces the items. The selection is kept if that item is still in the new list. */
    public AbyssScrollList<T> setItems(List<? extends T> newItems) {
        this.items = new ArrayList<>(newItems);
        if (selected != null && !items.contains(selected)) selected = null;
        scroll = class_3532.method_15340(scroll, 0, maxScroll());
        return this;
    }

    public List<T> getItems() { return items; }

    @Nullable public T getSelected() { return selected; }

    public AbyssScrollList<T> setSelected(@Nullable T item) { this.selected = item; return this; }

    public AbyssScrollList<T> onSelect(Consumer<T> onSelect) { this.onSelect = onSelect; return this; }

    /** false = rows only highlight on hover, clicking does nothing. */
    public AbyssScrollList<T> selectable(boolean selectable) { this.selectable = selectable; return this; }

    public AbyssScrollList<T> emptyText(class_2561 text) { this.emptyText = text; return this; }

    // ── Geometry ───────────────────────────────────────────────────────────────

    private int visibleRows() { return Math.max(1, method_25364() / rowHeight); }
    private int maxScroll()   { return Math.max(0, items.size() - visibleRows()); }
    private boolean scrollable() { return items.size() > visibleRows(); }
    private int rowWidth()    { return method_25368() - (scrollable() ? AbyssTheme.SCROLL_WIDTH + SCROLL_GAP : 0); }
    private int scrollbarX()  { return method_46426() + method_25368() - AbyssTheme.SCROLL_WIDTH; }

    /** Which item is under the mouse, or -1. */
    private int indexAt(double mouseX, double mouseY) {
        if (mouseX < method_46426() || mouseX >= method_46426() + rowWidth() || mouseY < method_46427()) return -1;
        int row = (int) ((mouseY - method_46427()) / rowHeight);
        int index = scroll + row;
        return row < visibleRows() && index < items.size() ? index : -1;
    }

    // ── Render ─────────────────────────────────────────────────────────────────

    @Override
    protected void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        if (items.isEmpty()) {
            var font = class_310.method_1551().field_1772;
            g.method_27534(font, emptyText, method_46426() + method_25368() / 2, method_46427() + method_25364() / 2 - 4, AbyssTheme.TEXT_DIM);
            return;
        }
        scroll = class_3532.method_15340(scroll, 0, maxScroll());
        int hoveredIndex = method_49606() ? indexAt(mouseX, mouseY) : -1;
        int w = rowWidth();

        for (int row = 0; row < visibleRows() && scroll + row < items.size(); row++) {
            int index = scroll + row;
            T item = items.get(index);
            int y = method_46427() + row * rowHeight;
            boolean isSelected = item.equals(selected);
            boolean isHovered = index == hoveredIndex;

            if (isSelected) {
                g.method_25294(method_46426(), y, method_46426() + w, y + rowHeight, AbyssTheme.ROW_SELECTED);
                g.method_25294(method_46426(), y, method_46426() + 1, y + rowHeight, AbyssTheme.ACCENT);   // accent bar on the left
            } else if (isHovered) {
                g.method_25294(method_46426(), y, method_46426() + w, y + rowHeight, AbyssTheme.ROW_HOVER);
            }
            renderer.render(g, item, method_46426() + 3, y, w - 3, rowHeight, isHovered, isSelected);
        }

        if (scrollable()) drawScrollbar(g, mouseX, mouseY);
    }

    private void drawScrollbar(class_332 g, int mouseX, int mouseY) {
        int trackH = visibleRows() * rowHeight;
        AbyssDraw.nineSlice(g, AbyssTheme.SCROLL_TRACK, AbyssTheme.SCROLL_BORDER, scrollbarX(), method_46427(), AbyssTheme.SCROLL_WIDTH, trackH);
        int handleH = Math.max(10, trackH * visibleRows() / items.size());
        int handleY = method_46427() + (maxScroll() == 0 ? 0 : (trackH - handleH) * scroll / maxScroll());
        boolean hover = draggingScrollbar || (mouseX >= scrollbarX() && mouseY >= handleY && mouseY < handleY + handleH
                && mouseX < scrollbarX() + AbyssTheme.SCROLL_WIDTH);
        AbyssDraw.nineSlice(g, hover ? AbyssTheme.SCROLL_HANDLE_HOVER : AbyssTheme.SCROLL_HANDLE, AbyssTheme.SCROLL_BORDER,
                scrollbarX(), handleY, AbyssTheme.SCROLL_WIDTH, handleH);
    }

    // ── Input ──────────────────────────────────────────────────────────────────

    /** Shared by both versions' mouseScrolled (their signatures differ). */
    protected boolean scrollBy(double amount) {
        scroll = class_3532.method_15340(scroll - (int) Math.signum(amount), 0, maxScroll());
        return true;
    }

    // 1.21.1 signature: horizontal AND vertical scroll — we use the vertical one
    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        return scrollBy(scrollY);
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        draggingScrollbar = scrollable() && mouseX >= scrollbarX();
        if (draggingScrollbar) {
            scrollToMouse(mouseY);
            return;
        }
        int index = indexAt(mouseX, mouseY);
        if (selectable && index >= 0) {
            selected = items.get(index);
            if (onSelect != null) onSelect.accept(selected);
        }
    }

    @Override
    protected void method_25349(double mouseX, double mouseY, double dragX, double dragY) {
        if (draggingScrollbar) scrollToMouse(mouseY);
    }

    @Override
    public void method_25357(double mouseX, double mouseY) {
        draggingScrollbar = false;
    }

    private void scrollToMouse(double mouseY) {
        double fraction = (mouseY - method_46427()) / (double) (visibleRows() * rowHeight);
        scroll = class_3532.method_15340((int) Math.round(fraction * maxScroll()), 0, maxScroll());
    }

    @Override
    protected void method_47399(class_6382 output) {
        if (selected != null) output.method_37034(class_6381.field_33788, class_2561.method_43470(String.valueOf(selected)));
    }
}
