package com.gugas749.abysscore.api.damages;

import com.gugas749.abysscore.Constants;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_8108;
import net.minecraft.class_8110;

public class AbyssDamageTypes {
    public static final class_5321<class_8110>
            CORRUPTION_DAMAGE = key("corruption_damage"),
            TEST_DAMAGE = key("test_damage");

    private static class_5321<class_8110> key(String name) {
        return class_5321.method_29179(class_7924.field_42534, Constants.asResource(name));
    }

    public static void bootstrap(class_7891<class_8110> ctx) {
        new DamageTypeBuilder(CORRUPTION_DAMAGE).scaling(class_8108.field_42287).exhaustion(0.1f).register(ctx);
        new DamageTypeBuilder(TEST_DAMAGE).scaling(class_8108.field_42287).register(ctx);
    }
}
