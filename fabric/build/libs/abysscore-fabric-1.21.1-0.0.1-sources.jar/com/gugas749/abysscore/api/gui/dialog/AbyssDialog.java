package com.gugas749.abysscore.api.gui.dialog;

import com.gugas749.abysscore.api.gui.layout.AbyssLayout;
import com.gugas749.abysscore.api.gui.layout.AbyssLayout.Flow;
import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import com.gugas749.abysscore.api.gui.widget.AbyssButton;
import com.gugas749.abysscore.api.gui.widget.AbyssTextField;
import org.lwjgl.glfw.GLFW;

import javax.annotation.Nullable;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * Pop-up dialogs drawn over the screen that opened them.
 *
 *   ctx.open(AbyssDialog.alert(screen, title, message));
 *   ctx.open(AbyssDialog.confirm(screen, title, message, () -> save()));
 *   ctx.open(AbyssDialog.confirmDanger(screen, title, message, () -> deleteRegion()));   // red button
 *   ctx.open(AbyssDialog.input(screen, title, message, "default", name -> !name.isBlank(), name -> rename(name)));
 *
 * Closing (button, Esc) goes back to the parent screen; the callback runs AFTER that, so a
 * callback may open yet another screen/dialog. Enter = confirm.
 */
public class AbyssDialog extends class_437 {

    private enum Kind { ALERT, CONFIRM, INPUT }

    private static final int WIDTH = 220;
    private static final int PAD = 10;
    private static final int LINE_H = 10;
    private static final float DIALOG_Z = 300;

    private final class_437 parent;
    private final Kind kind;
    private final class_2561 message;
    private final boolean danger;
    @Nullable private final Runnable onConfirm;
    @Nullable private final Consumer<String> onSubmit;
    private final Predicate<String> validator;
    private String inputValue;

    private int boxX, boxY, boxH;
    private List<class_5481> lines = List.of();
    private AbyssButton confirmButton;
    private AbyssTextField field;

    private AbyssDialog(class_437 parent, Kind kind, class_2561 title, class_2561 message, boolean danger,
                        @Nullable Runnable onConfirm, @Nullable Consumer<String> onSubmit,
                        Predicate<String> validator, String initialInput) {
        super(title);
        this.parent = parent;
        this.kind = kind;
        this.message = message;
        this.danger = danger;
        this.onConfirm = onConfirm;
        this.onSubmit = onSubmit;
        this.validator = validator;
        this.inputValue = initialInput;
    }

    // ── Factories ──────────────────────────────────────────────────────────────

    public static AbyssDialog alert(class_437 parent, class_2561 title, class_2561 message) {
        return new AbyssDialog(parent, Kind.ALERT, title, message, false, null, null, s -> true, "");
    }

    public static AbyssDialog confirm(class_437 parent, class_2561 title, class_2561 message, Runnable onConfirm) {
        return new AbyssDialog(parent, Kind.CONFIRM, title, message, false, onConfirm, null, s -> true, "");
    }

    /** Same as confirm, with a red DANGER confirm button — for delete/reset/ban. */
    public static AbyssDialog confirmDanger(class_437 parent, class_2561 title, class_2561 message, Runnable onConfirm) {
        return new AbyssDialog(parent, Kind.CONFIRM, title, message, true, onConfirm, null, s -> true, "");
    }

    /** @param validator the confirm button is only enabled while this returns true */
    public static AbyssDialog input(class_437 parent, class_2561 title, class_2561 message, String initial,
                                    Predicate<String> validator, Consumer<String> onSubmit) {
        return new AbyssDialog(parent, Kind.INPUT, title, message, false, null, onSubmit, validator, initial);
    }

    // ── Setup ──────────────────────────────────────────────────────────────────

    @Override
    protected void method_25426() {
        // Keep the parent laid out for the current window size (it's drawn behind us)
        parent.method_25423(this.field_22787, this.field_22789, this.field_22790);

        lines = this.field_22793.method_1728(message, WIDTH - 2 * PAD);
        int inputH = kind == Kind.INPUT ? AbyssTextField.HEIGHT + 6 : 0;
        boxH = 22 + 6 + lines.size() * LINE_H + 8 + inputH + AbyssButton.HEIGHT + PAD;
        boxX = (this.field_22789 - WIDTH) / 2;
        boxY = (this.field_22790 - boxH) / 2;

        int contentY = boxY + 22 + 6 + lines.size() * LINE_H + 8;

        if (kind == Kind.INPUT) {
            field = method_37063(new AbyssTextField(boxX + PAD, contentY, WIDTH - 2 * PAD, class_2561.method_43473()));
            field.method_1880(128);
            field.method_1852(inputValue);
            field.method_1863(value -> {
                inputValue = value;
                if (confirmButton != null) confirmButton.field_22763 = validator.test(value);
            });
            method_48265(field);
            contentY += inputH;
        }

        // Buttons bottom-right: [Cancel] [Confirm]   (alert: just [OK])
        int buttonW = 70;
        var buttons = AbyssLayout.row(boxX + WIDTH - PAD - (kind == Kind.ALERT ? buttonW : 2 * buttonW + 4), contentY, 4);
        if (kind != Kind.ALERT) {
            buttons.add(method_37063(new AbyssButton(0, 0, buttonW,
                    class_2561.method_43471("gui.abysscore.dialog.cancel"), b -> method_25419())));
        }
        class_2561 confirmText = class_2561.method_43471(kind == Kind.ALERT ? "gui.abysscore.dialog.ok" : "gui.abysscore.dialog.confirm");
        confirmButton = buttons.add(method_37063(new AbyssButton(0, 0, buttonW, confirmText,
                danger ? AbyssButton.Style.DANGER : AbyssButton.Style.NORMAL, b -> confirm())));
        confirmButton.field_22763 = kind != Kind.INPUT || validator.test(inputValue);
    }

    private void confirm() {
        if (!confirmButton.field_22763) return;
        this.field_22787.method_1507(parent);                      // back first...
        if (onConfirm != null) onConfirm.run();                // ...then the action
        if (onSubmit != null) onSubmit.accept(inputValue);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            confirm();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }

    // ── Rendering ──────────────────────────────────────────────────────────────

    /** Dark overlay + the dialog box — everything UNDER the buttons, inside the raised layer. */
    protected void renderDialog(class_332 g) {
        g.method_25294(0, 0, this.field_22789, this.field_22790, AbyssTheme.DIM_OVERLAY);

        AbyssDraw.nineSlice(g, AbyssTheme.PANEL, AbyssTheme.PANEL_BORDER, boxX, boxY, WIDTH, boxH);
        AbyssDraw.nineSlice(g, AbyssTheme.HEADER, AbyssTheme.HEADER_BORDER, boxX + 3, boxY + 3, WIDTH - 6, 16);
        g.method_51430(this.field_22793, AbyssDraw.trimmed(this.field_22793, this.field_22785, WIDTH - 20), boxX + 9, boxY + 7,
                danger ? AbyssTheme.DANGER_TEXT : AbyssTheme.TITLE, true);

        int y = boxY + 22 + 6;
        for (class_5481 line : lines) {
            g.method_51430(this.field_22793, line, boxX + PAD, y, AbyssTheme.TEXT, false);
            y += LINE_H;
        }
    }

    // NeoForge 1.21.1: parent at Z = 0, then the whole dialog raised in front of it.
    // super.render() calls renderBackground() (below) and then draws the widgets —
    // both inside the raised layer.
    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partialTick) {
        parent.method_25394(g, -1, -1, partialTick);         // -1,-1: nothing in the parent looks hovered

        g.method_51448().method_22903();
        g.method_51448().method_46416(0, 0, DIALOG_Z);
        super.method_25394(g, mouseX, mouseY, partialTick);
        g.method_51448().method_22909();
    }

    // Called by super.render() → our overlay + box instead of vanilla's blur
    @Override
    public void method_25420(class_332 g, int mouseX, int mouseY, float partialTick) {
        renderDialog(g);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}