package com.gugas749.abysscore.api.overlay;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.network.AbyssPacketContext;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;

/**
 * CLIENT: draws every active overlay (ABY-15). You never call this directly —
 * use AbyssScreenOverlay on the server / in common code.
 *
 * Register this renderer as a GUI layer via NeoForgeClientEventListeners on RegisterGuiLayersEvent.
 * Call onLoggingOut() from the logout event to clear active overlays.
 */
public final class AbyssOverlayRenderer {

    public static final class_2960 LAYER_ID = Constants.asResource("screen_overlay");

    private static final float MS_PER_TICK = 50f;

    private static final Map<class_2960, Timed> TIMED = new HashMap<>();

    private static final class Timed {
        final AbyssOverlaySpec spec;
        final long startMs;
        float durationTicks;

        Timed(AbyssOverlaySpec spec, long startMs, float durationTicks) {
            this.spec = spec;
            this.startMs = startMs;
            this.durationTicks = durationTicks;
        }

        float elapsedTicks(long now) {
            return (now - startMs) / MS_PER_TICK;
        }
    }

    private AbyssOverlayRenderer() {}

    // ── Packet handler ────────────────────────────────────────────────────────

    public static void handle(ScreenOverlayPacket packet, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> {
            long now = class_156.method_658();
            if (packet.durationTicks() > 0) {
                TIMED.put(packet.id(), new Timed(packet.spec(), now, packet.durationTicks()));
                return;
            }
            Timed t = TIMED.get(packet.id());
            if (t != null) {
                t.durationTicks = Math.min(t.durationTicks, t.elapsedTicks(now) + t.spec.fadeOutTicks());
            }
        });
    }

    /** Called by NeoForgeClientEventListeners on player logout. */
    public static void onLoggingOut() {
        TIMED.clear();
    }

    // ── Render (pass as method reference to RegisterGuiLayersEvent) ───────────

    public static void render(class_332 g, class_9779 delta) {
        var player = class_310.method_1551().field_1724;
        if (player == null) return;
        long now = class_156.method_658();

        Iterator<Timed> it = TIMED.values().iterator();
        while (it.hasNext()) {
            Timed t = it.next();
            float elapsed = t.elapsedTicks(now);
            float remaining = t.durationTicks - elapsed;
            if (remaining <= 0) { it.remove(); continue; }

            float fadeIn  = t.spec.fadeInTicks()  > 0 ? Math.min(1f, elapsed   / t.spec.fadeInTicks())  : 1f;
            float fadeOut = t.spec.fadeOutTicks() > 0 ? Math.min(1f, remaining / t.spec.fadeOutTicks()) : 1f;
            draw(g, t.spec, t.spec.maxAlpha() * Math.min(fadeIn, fadeOut));
        }

        var bindings = AbyssScreenOverlay.effectOverlays();
        if (bindings.isEmpty()) return;
        for (class_1293 inst : player.method_6026()) {
            var key = inst.method_5579().method_40230();
            if (key.isEmpty()) continue;
            AbyssOverlaySpec spec = bindings.get(key.get().method_29177());
            if (spec == null) continue;

            float strength = spec.ampScaling() ? Math.min(1f, (inst.method_5578() + 1) / 4f) : 1f;
            float fadeOut = 1f;
            if (!inst.method_48559() && spec.fadeOutTicks() > 0) {
                fadeOut = Math.min(1f, inst.method_5584() / (float) spec.fadeOutTicks());
            }
            draw(g, spec, spec.maxAlpha() * strength * fadeOut);
        }
    }

    private static void draw(class_332 g, AbyssOverlaySpec spec, float alpha) {
        if (alpha <= 0.003f) return;
        int w = g.method_51421(), h = g.method_51443();
        int full = argb(spec.color(), alpha);

        if (spec.style() == AbyssOverlaySpec.Style.TINT) {
            g.method_25294(0, 0, w, h, full);
            return;
        }

        int clear = argb(spec.color(), 0f);
        int bandY = h / 4;
        g.method_25296(0, 0, w, bandY, full, clear);
        g.method_25296(0, h - bandY, w, h, clear, full);

        int bandX = w / 5, steps = 16;
        float stripW = bandX / (float) steps;
        for (int i = 0; i < steps; i++) {
            int c = argb(spec.color(), alpha * (1f - i / (float) steps));
            int x0 = Math.round(i * stripW), x1 = Math.round((i + 1) * stripW);
            g.method_25294(x0, 0, x1, h, c);
            g.method_25294(w - x1, 0, w - x0, h, c);
        }
    }

    private static int argb(int rgb, float alpha) {
        int a = Math.round(Math.max(0f, Math.min(1f, alpha)) * 255f);
        return (a << 24) | (rgb & 0xFFFFFF);
    }
}
