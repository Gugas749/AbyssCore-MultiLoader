package com.gugas749.abysscore.api.damages;

import javax.annotation.Nullable;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_4538;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public class AbyssDamageSources {
    public static class_1282 corruption(class_1937 level) {
        return source(AbyssDamageTypes.CORRUPTION_DAMAGE, level);
    }

    private static class_1282 source(class_5321<class_8110> key, class_4538 level) {
        class_2378<class_8110> registry = level.method_30349().method_30530(class_7924.field_42534);
        return new class_1282(registry.method_40290(key));
    }

    private static class_1282 source(class_5321<class_8110> key, class_4538 level, @Nullable class_1297 entity) {
        class_2378<class_8110> registry = level.method_30349().method_30530(class_7924.field_42534);
        return new class_1282(registry.method_40290(key), entity);
    }

    private static class_1282 source(class_5321<class_8110> key, class_4538 level, @Nullable class_1297 causingEntity, @Nullable class_1297 directEntity) {
        class_2378<class_8110> registry = level.method_30349().method_30530(class_7924.field_42534);
        return new class_1282(registry.method_40290(key), causingEntity, directEntity);
    }
}
