package com.gugas749.abysscore.api.attachment;

import com.gugas749.abysscore.Constants;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SyncAttachmentPacket(class_2960 id, byte[] data) implements class_8710 {

    public static final class_9154<SyncAttachmentPacket> TYPE =
            new class_9154<>(Constants.asResource("sync_attachment"));

    public static final class_9139<class_9129, SyncAttachmentPacket> CODEC =
            class_9139.method_56437(
                    (buf, pkt) -> {
                        buf.method_10812(pkt.id());
                        buf.method_10813(pkt.data());
                    },
                    buf -> new SyncAttachmentPacket(
                            buf.method_10810(),
                            buf.method_10795()
                    )
            );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
