package com.gugas749.abysscore.api.geckolib;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;

public abstract class AbyssGeoEntity  extends class_1297 implements AbyssGeoBase, GeoEntity {

    /*
     *           EXAMPLE ENTITY
     *
     *   public class VortexEntity extends AbyssGeoEntity {
     *
     *       public VortexEntity(EntityType<?> entityType, Level level) {
     *           super(entityType, level);
     *       }
     *
     *       @Override
     *       public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
     *           // just the animation logic
     *       }
     *
     *       @Override
     *       public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
     *           // just the renderer
     *       }
     *
     *       @Override
     *       protected void defineSynchedData(SynchedEntityData.Builder builder) {
     *           // entity-specific synced data if needed
     *       }
     *
     *       @Override
     *       protected void readAdditionalSaveData(CompoundTag tag) {}
     *
     *       @Override
     *       protected void addAdditionalSaveData(CompoundTag tag) {}
     *   }
     *
     * */

    private final AnimatableInstanceCache cache = createCache();

    public AbyssGeoEntity(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    public double getTick(Object o) {
        return field_6012;
    }

    @Override
    public abstract void registerControllers(AnimatableManager.ControllerRegistrar controllers);

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
