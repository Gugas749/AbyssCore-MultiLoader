package com.gugas749.abysscore.api.gui.screen;

import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import com.gugas749.abysscore.api.gui.widget.AbyssButton;
import com.gugas749.abysscore.api.gui.widget.AbyssIconButton;
import com.gugas749.abysscore.api.gui.widget.AbyssTabButton;
import com.gugas749.abysscore.api.permission.AbyssClientPermission;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import javax.annotation.Nullable;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Base class for Abyss staff screens: panel + header + sidebar tabs + content area.
 *
 *   public class RegionScreen extends AbyssPanelScreen {
 *       public RegionScreen() { super(Component.literal("Regions")); }
 *
 *       @Override protected void addTabs(List<AbyssTab> tabs) {
 *           tabs.add(new RegionListTab());
 *           tabs.add(AbyssTab.of(Component.literal("Settings"), ctx -> { ... }));
 *       }
 *   }
 *   // open it:  Minecraft.getInstance().setScreen(new RegionScreen());
 *
 *   ┌─ TITLE ─────────────────────── STAFF ✕ ┐
 *   │ [Tab 1] │                              │
 *   │  Tab 2  │   content area (TabContext)  │
 *   │  Tab 3  │                              │
 *   └─────────┴──────────────────────────────┘
 *
 * With only ONE tab there is no sidebar and the content uses the full width.
 *
 * PERMISSIONS: by default only MODERATOR and ADMIN can use these screens (override
 * requiredLevel()). This client-side check is for the user experience only — a modified
 * client can skip it — so the SERVER must still check the permission on every packet
 * the screen sends.
 */
public abstract class AbyssPanelScreen extends class_437 {

    private static final int HEADER_H = 22;          // header bar incl. margins
    private static final int SIDEBAR_W = 84;
    private static final int TAB_SPACING = 20;       // 18 tall + 2 gap
    private static final int MARGIN = 8;

    /** Remembers the last tab per screen class while the game runs. */
    private static final Map<Class<?>, Integer> LAST_TAB = new HashMap<>();

    private final List<AbyssTab> tabs = new ArrayList<>();
    private final List<class_339> tabWidgets = new ArrayList<>();
    private int selectedTab;
    private boolean denied;
    private TabContext context;

    protected int panelX, panelY, panelW, panelH;

    /** Where Close / Esc goes back to. null = close the GUI completely. */
    @Nullable protected final class_437 parent;

    protected AbyssPanelScreen(class_2561 title) {
        this(title, null);
    }

    /** @param parent the screen to return to on Close/Esc (e.g. the main menu that opened this one) */
    protected AbyssPanelScreen(class_2561 title, @Nullable class_437 parent) {
        super(title);
        this.parent = parent;
    }

    // ── What subclasses define ─────────────────────────────────────────────────

    /** Add the tabs, in sidebar order. Called once, the first time the screen opens. */
    protected abstract void addTabs(List<AbyssTab> tabs);

    /** Preferred panel size; shrunk automatically on small windows. */
    protected int panelWidth()  { return 320; }
    protected int panelHeight() { return 200; }

    /** Who may use this screen. */
    protected AbyssPermissionLevel requiredLevel() { return AbyssPermissionLevel.MODERATOR; }

    // ── Setup ──────────────────────────────────────────────────────────────────

    /** Runs on open AND on every window resize — so all positions are computed here. */
    @Override
    protected void method_25426() {
        panelW = Math.min(panelWidth(), this.field_22789 - 10);
        panelH = Math.min(panelHeight(), this.field_22790 - 10);
        panelX = (this.field_22789 - panelW) / 2;
        panelY = (this.field_22790 - panelH) / 2;

        method_37063(new AbyssIconButton(panelX + panelW - 16, panelY + 6,
                AbyssTheme.ICON_CLOSE, AbyssTheme.ICON_CLOSE_HOVER,
                class_2561.method_43471("gui.abysscore.close"), this::method_25419));

        denied = !AbyssClientPermission.has(requiredLevel());
        if (denied) {
            method_37063(new AbyssButton(panelX + (panelW - 60) / 2, panelY + panelH / 2 + 8, 60,
                    class_2561.method_43471("gui.abysscore.close"), b -> method_25419()));
            return;
        }

        if (tabs.isEmpty()) {
            addTabs(tabs);
            selectedTab = Math.min(LAST_TAB.getOrDefault(getClass(), 0), Math.max(0, tabs.size() - 1));
        }

        if (hasSidebar()) {
            for (int i = 0; i < tabs.size(); i++) {
                int index = i;
                method_37063(new AbyssTabButton(panelX + 6, panelY + HEADER_H + 4 + i * TAB_SPACING,
                        SIDEBAR_W - 10, tabs.get(i).title(),
                        () -> selectedTab == index, () -> selectTab(index)));
            }
        }
        rebuildTab();
    }

    private boolean hasSidebar() {
        return tabs.size() > 1;
    }

    public void selectTab(int index) {
        selectedTab = index;
        LAST_TAB.put(getClass(), index);
        rebuildTab();
    }

    /** Throws away the current tab's widgets and lets the tab build them again. */
    void rebuildTab() {
        tabWidgets.forEach(this::method_37066);
        tabWidgets.clear();
        if (tabs.isEmpty()) return;

        int contentX = panelX + (hasSidebar() ? SIDEBAR_W + MARGIN + 2 : MARGIN);
        int contentY = panelY + HEADER_H + 4;
        int contentW = panelX + panelW - MARGIN - contentX;
        int contentH = panelY + panelH - MARGIN - contentY;
        context = new TabContext(this, contentX, contentY, contentW, contentH);
        tabs.get(selectedTab).init(context);
    }

    <W extends class_339> W addTabWidget(W widget) {
        tabWidgets.add(widget);
        return method_37063(widget);
    }

    @Override
    public void method_25393() {
        super.method_25393();
        if (!denied && context != null) tabs.get(selectedTab).tick(context);
    }

    // ── Rendering ──────────────────────────────────────────────────────────────

    /** Everything UNDER the widgets: dim, panel, stars, header, sidebar, the tab's own drawing. */
    protected void renderPanel(class_332 g, int mouseX, int mouseY, float partialTick) {
        g.method_25294(0, 0, this.field_22789, this.field_22790, 0x90000000);   // dim the world (no blur, on both versions)

        AbyssDraw.nineSlice(g, AbyssTheme.PANEL, AbyssTheme.PANEL_BORDER, panelX, panelY, panelW, panelH);
        AbyssDraw.stars(g, panelX + 6, panelY + HEADER_H, panelW - 12, panelH - HEADER_H - 6, (long) panelW * 31 + panelH);

        // header bar: title left, STAFF badge right (before the close icon)
        AbyssDraw.nineSlice(g, AbyssTheme.HEADER, AbyssTheme.HEADER_BORDER, panelX + 3, panelY + 3, panelW - 6, 16);
        g.method_51430(this.field_22793, AbyssDraw.trimmed(this.field_22793, this.field_22785, panelW - 90), panelX + 9, panelY + 7, AbyssTheme.TITLE, true);
        class_2561 badge = class_2561.method_43471("gui.abysscore.staff");
        g.method_51439(this.field_22793, badge, panelX + panelW - 22 - this.field_22793.method_27525(badge), panelY + 7, AbyssTheme.BADGE, true);

        if (denied) {
            g.method_27534(this.field_22793, class_2561.method_43471("gui.abysscore.no_permission"),
                    panelX + panelW / 2, panelY + panelH / 2 - 10, AbyssTheme.DANGER_TEXT);
            return;
        }

        if (hasSidebar()) {   // vertical divider between sidebar and content
            g.method_25294(panelX + SIDEBAR_W + 3, panelY + HEADER_H, panelX + SIDEBAR_W + 4, panelY + panelH - 6, AbyssTheme.DIVIDER);
        }
        if (context != null) tabs.get(selectedTab).render(g, context, mouseX, mouseY, partialTick);
    }

    /*
     * NeoForge 1.21.1: Screen.render() calls renderBackground() first, and the vanilla one
     * BLURS the world (1.21 only allows one blur per frame — a dialog drawing this panel
     * behind it would crash). We replace it with our panel; render() then draws the widgets
     * on top as usual. (Forge 1.20.1 instead overrides render(), which draws no background.)
     */
    @Override
    public void method_25420(class_332 g, int mouseX, int mouseY, float partialTick) {
        renderPanel(g, mouseX, mouseY, partialTick);
    }

    /** Close / Esc: back to the parent screen if there is one, otherwise out of the GUI. */
    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
