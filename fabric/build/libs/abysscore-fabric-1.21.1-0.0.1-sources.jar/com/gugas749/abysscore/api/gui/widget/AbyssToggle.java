package com.gugas749.abysscore.api.gui.widget;

import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6381;
import net.minecraft.class_6382;

/**
 * On/off switch with a label on its right. 20 tall so it lines up with buttons.
 *
 *   new AbyssToggle(x, y, Component.literal("Vanish"), isVanished, on -> sendVanish(on));
 *
 * The width is computed from the label (switch + gap + text).
 */
public class AbyssToggle extends class_4264 {

    private static final int SWITCH_W = 24, SWITCH_H = 12, GAP = 4;

    private boolean value;
    private final Consumer<Boolean> onChange;

    public AbyssToggle(int x, int y, class_2561 label, boolean initial, Consumer<Boolean> onChange) {
        super(x, y, SWITCH_W + GAP + class_310.method_1551().field_1772.method_27525(label), 20, label);
        this.value = initial;
        this.onChange = onChange;
    }

    public boolean getValue() {
        return value;
    }

    /** Change it from code (does NOT call onChange — that's only for the user's clicks). */
    public void setValue(boolean value) {
        this.value = value;
    }

    @Override
    public void method_25306() {
        value = !value;
        onChange.accept(value);
    }

    @Override
    protected void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        boolean hover = method_25367() && this.field_22763;
        AbyssTheme.Sprite sprite = value
                ? (hover ? AbyssTheme.TOGGLE_ON_HOVER : AbyssTheme.TOGGLE_ON)
                : (hover ? AbyssTheme.TOGGLE_OFF_HOVER : AbyssTheme.TOGGLE_OFF);
        AbyssDraw.sprite(g, sprite, method_46426(), method_46427() + (method_25364() - SWITCH_H) / 2);

        int color = !this.field_22763 ? AbyssTheme.TEXT_OFF : value ? AbyssTheme.TEXT : AbyssTheme.TEXT_DIM;
        g.method_51439(class_310.method_1551().field_1772, method_25369(), method_46426() + SWITCH_W + GAP, method_46427() + 6, color, true);
    }

    @Override
    protected void method_47399(class_6382 output) {
        output.method_37034(class_6381.field_33788, class_2561.method_43473().method_10852(method_25369())
                .method_27693(": ").method_10852(class_2561.method_43471(value ? "options.on" : "options.off")));
    }
}
