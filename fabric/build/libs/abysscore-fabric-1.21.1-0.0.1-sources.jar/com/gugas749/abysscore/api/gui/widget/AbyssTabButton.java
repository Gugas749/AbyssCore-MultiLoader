package com.gugas749.abysscore.api.gui.widget;

import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import java.util.function.BooleanSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6382;

/**
 * A sidebar tab (used by AbyssPanelScreen). 18 tall, any width.
 * Asks "am I selected?" every frame, so the screen is the only owner of that state.
 */
public class AbyssTabButton extends class_4264 {

    public static final int HEIGHT = 18;

    private final BooleanSupplier selected;
    private final Runnable onSelect;

    public AbyssTabButton(int x, int y, int width, class_2561 label, BooleanSupplier selected, Runnable onSelect) {
        super(x, y, width, HEIGHT, label);
        this.selected = selected;
        this.onSelect = onSelect;
    }

    @Override
    public void method_25306() {
        if (!selected.getAsBoolean()) onSelect.run();
    }

    @Override
    protected void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        boolean isSelected = selected.getAsBoolean();
        boolean hover = method_25367();
        AbyssDraw.nineSlice(g, isSelected ? AbyssTheme.TAB_SELECTED : hover ? AbyssTheme.TAB_HOVER : AbyssTheme.TAB,
                AbyssTheme.TAB_BORDER, method_46426(), method_46427(), method_25368(), method_25364());

        int color = isSelected ? AbyssTheme.TEXT_BRIGHT : hover ? AbyssTheme.TEXT : AbyssTheme.TEXT_DIM;
        var font = class_310.method_1551().field_1772;
        g.method_51430(font, AbyssDraw.trimmed(font, method_25369(), method_25368() - 12), method_46426() + 8, method_46427() + 5, color, true);
    }

    @Override
    protected void method_47399(class_6382 output) {
        method_37021(output);
    }
}
