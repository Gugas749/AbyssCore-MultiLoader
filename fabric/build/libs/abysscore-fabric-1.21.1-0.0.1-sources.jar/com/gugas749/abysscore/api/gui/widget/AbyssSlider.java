package com.gugas749.abysscore.api.gui.widget;

import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_357;

/**
 * Slider. Internally always 0.0 – 1.0; convert in your two functions:
 *
 *   new AbyssSlider(x, y, 150, radius / 128.0,
 *       v -> Component.literal("Radius: " + (int) (v * 128)),   // label on the slider
 *       v -> radius = (int) (v * 128));                          // on every change
 */
public class AbyssSlider extends class_357 {

    private static final int HANDLE_W = 6;

    private final DoubleFunction<class_2561> label;
    private final DoubleConsumer onChange;

    public AbyssSlider(int x, int y, int width, double initial,
                       DoubleFunction<class_2561> label, DoubleConsumer onChange) {
        super(x, y, width, 20, class_2561.method_43473(), initial);
        this.label = label;
        this.onChange = onChange;
        method_25346();   // super() ran before our fields existed → build the label now
    }

    public double getValue() {
        return this.field_22753;
    }

    @Override
    protected void method_25346() {
        method_25355(label.apply(this.field_22753));
    }

    @Override
    protected void method_25344() {
        onChange.accept(this.field_22753);
    }

    @Override
    public void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        AbyssDraw.nineSlice(g, AbyssTheme.SLIDER_TRACK, AbyssTheme.SLIDER_BORDER, method_46426(), method_46427(), method_25368(), method_25364());
        int handleX = method_46426() + (int) (this.field_22753 * (method_25368() - HANDLE_W));
        AbyssDraw.sprite(g, method_25367() ? AbyssTheme.SLIDER_HANDLE_HOVER : AbyssTheme.SLIDER_HANDLE, handleX, method_46427());
        this.method_49604(g, class_310.method_1551().field_1772, 2,
                this.field_22763 ? AbyssTheme.TEXT : AbyssTheme.TEXT_OFF);
    }
}
