package com.gugas749.abysscore.api.effects;

import java.util.*;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

/**
 * Keeps registered effects on entities permanently (refreshes them before they expire).
 * Event wiring (NeoForge) lives in NeoForgeEventListeners; only plain methods here.
 */
public class AbyssEffectHandler {

    // UUID → list of effects to keep active on this entity
    private static final Map<UUID, List<class_1293>> continuousEffects = new HashMap<>();

    private static final int REFRESH_THRESHOLD = 200;

    public static void registerContinuousEffect(UUID target, List<class_1293> effects) {
        continuousEffects
                .computeIfAbsent(target, k -> new ArrayList<>())
                .addAll(effects);
    }

    public static void registerContinuousEffect(UUID target, class_1293 effect) {
        registerContinuousEffect(target, List.of(effect));
    }

    public static void unregisterEveryContinuousEffect(UUID target) {
        continuousEffects.remove(target);
    }

    public static void unregisterContinuousEffect(UUID target, class_1293 effect) {
        List<class_1293> effects = continuousEffects.get(target);
        if (effects != null) {
            effects.removeIf(e -> e.method_5579().equals(effect.method_5579()));
            if (effects.isEmpty()) {
                continuousEffects.remove(target);
            }
        }
    }

    /** Called every server-side entity tick by NeoForgeEventListeners. */
    public void onEntityTick(class_1309 entity) {
        List<class_1293> effects = continuousEffects.get(entity.method_5667());
        if (effects == null) return;

        for (class_1293 ce : effects) {
            var current = entity.method_6112(ce.method_5579());
            if (current == null || current.method_5584() < REFRESH_THRESHOLD) {
                entity.method_6092(new class_1293(ce));
            }
        }
    }

    /** Called on player logout by NeoForgeEventListeners to remove continuous effects. */
    public void onPlayerLeave(class_1657 player) {
        continuousEffects.remove(player.method_5667());
    }
}
