package com.gugas749.abysscore.api.permission;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server → Client: "your AbyssCore permission level is now X". */
public record PermissionSyncPacket(AbyssPermissionLevel level) implements class_8710 {

    public static final class_9154<PermissionSyncPacket> TYPE =
            new class_9154<>(class_2960.method_60655("abysscore", "permission_sync"));

    public static final class_9139<class_9129, PermissionSyncPacket> CODEC = class_9139.method_56437(
            (buf, pkt) -> buf.method_10817(pkt.level()),
            buf -> new PermissionSyncPacket(buf.method_10818(AbyssPermissionLevel.class))
    );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
