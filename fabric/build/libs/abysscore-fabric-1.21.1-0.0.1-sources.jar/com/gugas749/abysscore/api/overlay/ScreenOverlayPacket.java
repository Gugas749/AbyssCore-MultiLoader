package com.gugas749.abysscore.api.overlay;

import com.gugas749.abysscore.Constants;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Server → Client: "show overlay `id` for `durationTicks`", or clear it when durationTicks <= 0.
 * Sent by AbyssScreenOverlay.show/clear; never construct it yourself.
 */
public record ScreenOverlayPacket(class_2960 id, AbyssOverlaySpec spec, int durationTicks)
        implements class_8710 {

    public static final class_9154<ScreenOverlayPacket> TYPE = new class_9154<>(Constants.asResource("screen_overlay"));

    public static final class_9139<class_9129, ScreenOverlayPacket> CODEC = class_9139.method_56437(
            (buf, pkt) -> {
                buf.method_10812(pkt.id());
                buf.method_53002(pkt.spec().color());
                buf.method_52941(pkt.spec().maxAlpha());
                buf.method_10817(pkt.spec().style());
                buf.method_10804(pkt.spec().fadeInTicks());
                buf.method_10804(pkt.spec().fadeOutTicks());
                buf.method_10804(pkt.durationTicks());
            },
            buf -> new ScreenOverlayPacket(
                    buf.method_10810(),
                    new AbyssOverlaySpec(buf.readInt(), buf.readFloat(),
                            buf.method_10818(AbyssOverlaySpec.Style.class),
                            buf.method_10816(), buf.method_10816(), false),
                    buf.method_10816())
    );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
