package com.gugas749.abysscore.api.gui.widget;

import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;

/**
 * Abyss button. Any width, always 20 tall.
 *
 *   new AbyssButton(x, y, 80, Component.literal("Save"), b -> save());
 *   new AbyssButton(x, y, 80, Component.literal("Delete"), AbyssButton.Style.DANGER, b -> delete());
 *
 * Style.DANGER is red — use it for destructive staff actions (delete, reset, ban) so they
 * never look like an ordinary button. Pair it with AbyssDialog.confirmDanger(...).
 */
public class AbyssButton extends class_4185 {

    public static final int HEIGHT = 20;

    public enum Style { NORMAL, DANGER }

    private final Style style;

    public AbyssButton(int x, int y, int width, class_2561 message, class_4241 onPress) {
        this(x, y, width, message, Style.NORMAL, onPress);
    }

    public AbyssButton(int x, int y, int width, class_2561 message, Style style, class_4241 onPress) {
        super(x, y, width, HEIGHT, message, onPress, field_40754);
        this.style = style;
    }

    @Override
    protected void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        boolean hovered = this.method_25367();
        AbyssTheme.Sprite sprite;
        int color;
        if (!this.field_22763) {
            sprite = AbyssTheme.BUTTON_DISABLED;
            color = AbyssTheme.TEXT_OFF;
        } else if (style == Style.DANGER) {
            sprite = hovered ? AbyssTheme.BUTTON_DANGER_HOVER : AbyssTheme.BUTTON_DANGER;
            color = hovered ? AbyssTheme.TEXT_BRIGHT : AbyssTheme.DANGER_TEXT;
        } else {
            sprite = hovered ? AbyssTheme.BUTTON_HOVER : AbyssTheme.BUTTON;
            color = hovered ? AbyssTheme.TEXT_BRIGHT : AbyssTheme.TEXT;
        }
        AbyssDraw.nineSlice(g, sprite, AbyssTheme.BUTTON_BORDER, method_46426(), method_46427(), method_25368(), method_25364());
        // renderString centers the label and SCROLLS it if it doesn't fit (long translations)
        this.method_48589(g, class_310.method_1551().field_1772, (color & 0xFFFFFF) | class_3532.method_15386(this.field_22765 * 255.0F) << 24);
    }
}
