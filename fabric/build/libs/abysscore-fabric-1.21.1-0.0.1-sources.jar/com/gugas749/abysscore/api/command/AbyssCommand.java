package com.gugas749.abysscore.api.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;

public interface AbyssCommand {
    void register(CommandDispatcher<class_2168> dispatcher);
}
