package com.gugas749.abysscore.api.gui.widget;

import com.gugas749.abysscore.api.gui.layout.AbyssSized;
import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;

/**
 * Text input with the Abyss frame. Everything from vanilla EditBox works:
 * getValue(), setValue(), setResponder(...), setFilter(...), setMaxLength(...).
 *
 *   AbyssTextField name = new AbyssTextField(x, y, 150, Component.literal("Region name..."));
 *   name.setResponder(text -> saveButton.active = !text.isBlank());
 *
 * How it works: vanilla EditBox either draws its OWN frame or none. We turn its frame off
 * (setBordered(false)) and make the EditBox only the INNER text area; our frame is drawn
 * around it. So:
 *   - x, y, width you pass = the whole frame (what you see)
 *   - setX / setY also take the FRAME position
 *   - getX / getY / getWidth return the inner text area (vanilla needs that internally)
 *   - layouts use outerWidth()/outerHeight() (AbyssSized) to get the frame size
 */
public class AbyssTextField extends class_342 implements AbyssSized {

    public static final int HEIGHT = 20;
    private static final int PAD_X = 5, PAD_Y = 6;   // frame → text

    public AbyssTextField(int x, int y, int width, class_2561 hint) {
        super(class_310.method_1551().field_1772, x + PAD_X, y + PAD_Y, width - 2 * PAD_X, 12, hint);
        method_1858(false);
        method_1868(AbyssTheme.TEXT & 0xFFFFFF);
        method_1860(AbyssTheme.TEXT_OFF & 0xFFFFFF);
        method_47404(hint.method_27661().method_27694(s -> s.method_36139(AbyssTheme.TEXT_DIM & 0xFFFFFF)));
    }

    @Override
    public void method_46421(int frameX) {
        super.method_46421(frameX + PAD_X);
    }

    @Override
    public void method_46419(int frameY) {
        super.method_46419(frameY + PAD_Y);
    }

    public int frameX() { return method_46426() - PAD_X; }
    public int frameY() { return method_46427() - PAD_Y; }

    @Override public int outerWidth()  { return method_25368() + 2 * PAD_X; }
    @Override public int outerHeight() { return HEIGHT; }

    @Override
    public void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        if (!method_1885()) return;
        AbyssDraw.nineSlice(g, method_25370() ? AbyssTheme.FIELD_FOCUSED : AbyssTheme.FIELD, AbyssTheme.FIELD_BORDER,
                frameX(), frameY(), outerWidth(), HEIGHT);
        super.method_48579(g, mouseX, mouseY, partialTick);   // vanilla draws text, cursor, selection
    }
}
