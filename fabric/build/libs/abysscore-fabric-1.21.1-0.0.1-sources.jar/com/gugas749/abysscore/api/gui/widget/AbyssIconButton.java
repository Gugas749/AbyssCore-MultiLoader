package com.gugas749.abysscore.api.gui.widget;

import com.gugas749.abysscore.api.gui.render.AbyssDraw;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6382;
import net.minecraft.class_7919;

/**
 * A small button that is just an icon (e.g. the panel's close "X").
 * The label is never drawn — it's used as tooltip and for narration.
 */
public class AbyssIconButton extends class_4264 {

    private final AbyssTheme.Sprite icon, iconHover;
    private final Runnable onPress;

    public AbyssIconButton(int x, int y, AbyssTheme.Sprite icon, AbyssTheme.Sprite iconHover,
                           class_2561 label, Runnable onPress) {
        super(x, y, icon.width(), icon.height(), label);
        this.icon = icon;
        this.iconHover = iconHover;
        this.onPress = onPress;
        method_47400(class_7919.method_47407(label));
    }

    @Override
    public void method_25306() {
        onPress.run();
    }

    @Override
    protected void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        AbyssDraw.sprite(g, method_25367() ? iconHover : icon, method_46426(), method_46427());
    }

    @Override
    protected void method_47399(class_6382 output) {
        method_37021(output);
    }
}
