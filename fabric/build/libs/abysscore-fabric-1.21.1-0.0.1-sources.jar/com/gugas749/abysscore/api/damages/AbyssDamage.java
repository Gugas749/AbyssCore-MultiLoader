package com.gugas749.abysscore.api.damages;

import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_6880;

public class AbyssDamage {

    public static void deal(class_1309 target, class_1282 source, float damage) {
        target.method_5643(source, damage);
    }

    /**
     * Duration example: 100 is 5 seconds
     * Amplifier example: if the amplifier value given is 0 then the effect level is 1
     *                    if the amplifier value given is 1 then the effect level is 2
     */
    public static void deal(class_1309 target, class_1282 source, float damage, class_6880<class_1291> effect, int duration, int amplifier) {
        if (target.method_5643(source, damage)) {
            target.method_6092(new class_1293(effect, duration, amplifier));
        }
    }
}
