package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1309;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ACGodCommands {

    private static final Set<UUID> godModePlayers = new HashSet<>();

    public static Set<UUID> godModePlayers() { return godModePlayers; }

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("abysscore")
                .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.MODERATOR))

                .then(class_2170.method_9247("god")

                    .executes(ACGodCommands::executeToggleSelf)

                    .then(class_2170.method_9244("target", class_2186.method_9305())
                        .executes(ACGodCommands::executeToggleTarget)
                    )
                )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore god [player]");
    }

    private static int executeToggleSelf(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.god.player_only"));
            return 0;
        }
        return toggle(source, player);
    }

    private static int executeToggleTarget(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        try {
            return toggle(source, class_2186.method_9315(ctx, "target"));
        } catch (Exception e) {
            source.method_9213(class_2561.method_43471("message.abysscore.god.player_not_found"));
            return 0;
        }
    }

    private static int toggle(class_2168 source, class_3222 player) {
        boolean nowGod;

        if (godModePlayers.contains(player.method_5667())) {
            godModePlayers.remove(player.method_5667());
            nowGod = false;
        } else {
            godModePlayers.add(player.method_5667());
            nowGod = true;
        }

        source.method_9226(
            () -> class_2561.method_43469(
                nowGod ? "message.abysscore.god.enabled" : "message.abysscore.god.disabled",
                player.method_5477().getString()
            ),
            true
        );

        if (source.method_9228() != player) {
            player.method_43496(class_2561.method_43471(
                nowGod ? "message.abysscore.god.enabled_self" : "message.abysscore.god.disabled_self"
            ));
        }

        Constants.LOG.info("[AbyssCore] God mode {} for {}",
            nowGod ? "ENABLED" : "DISABLED", player.method_5477().getString());
        return 1;
    }

    // ── Damage cancel ─────────────────────────────────────────────────────────

    /** Returns true if damage should be cancelled (called by NeoForgeEventListeners). */
    public boolean onIncomingDamage(class_1309 entity) {
        if (!(entity instanceof class_3222 player)) return false;
        return godModePlayers.contains(player.method_5667());
    }

    /** Called every server-side player tick by NeoForgeEventListeners. */
    public void onPlayerTick(class_3222 player) {
        if (!godModePlayers.contains(player.method_5667())) return;
        if (player.field_6012 % 20 != 0) return;

        player.method_51469().method_8390(
                net.minecraft.class_1308.class,
                player.method_5829().method_1014(64),
                mob -> player.equals(mob.method_5968())
        ).forEach(mob -> mob.method_5980(null));
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public static boolean hasGodMode(UUID uuid) {
        return godModePlayers.contains(uuid);
    }

    public static void onPlayerLeave(UUID uuid) {
        godModePlayers.remove(uuid);
    }
}
