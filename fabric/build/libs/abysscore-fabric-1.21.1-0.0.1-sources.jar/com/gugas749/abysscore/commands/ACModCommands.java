package com.gugas749.abysscore.commands;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.AbysscoreServerConfig;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.gugas749.abysscore.commands.subRegisters.*;
import com.gugas749.abysscore.features.bulk.BulkCommandManager;
import com.gugas749.abysscore.features.chat.ACChatLockListener;
import com.gugas749.abysscore.features.title.ACTitleManager;
import com.gugas749.abysscore.network.AbyssNetwork;
import com.gugas749.abysscore.network.menu.MenuPacketHandlers;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ACModCommands {

    /** Called from the loader's RegisterCommandsEvent to register all common commands. */
    public static void registerAll(CommandDispatcher<class_2168> dispatcher) {
        Constants.LOG.info("[AbyssCore] Registering commands...");

        register(dispatcher);

        ACBindCommands.register(dispatcher);
        ACBlindCommands.register(dispatcher);
        ACBulkCommands.register(dispatcher);
        ACDimenCommands.register(dispatcher);
        ACDimenSettingsCommands.register(dispatcher);
        ACGodCommands.register(dispatcher);
        ACHelpCommands.register(dispatcher);
        ACPermissionCommands.register(dispatcher);
        ACRegionCommands.register(dispatcher);
        ACVanishCommands.register(dispatcher);
    }

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("abysscore")
                        .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.MODERATOR))
                        .executes(ctx -> {
                            if (!(ctx.getSource().method_9228() instanceof class_3222 player)) return 0;
                            AbyssNetwork.sendToPlayer(player,
                                    MenuPacketHandlers.buildMenuPacket(player));
                            return 1;
                        })

                        .then(class_2170.method_9247("reload")
                                .executes(ctx -> {
                                    AbysscoreServerConfig.load();
                                    AbyssPermissionHandler.load();
                                    ACTitleManager.load();
                                    BulkCommandManager.load();
                                    ctx.getSource().method_9226(
                                            () -> class_2561.method_43470("[AbyssCore] Reloaded."), true);
                                    return 1;
                                })
                        )

                        .then(class_2170.method_9247("chat")
                                .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.ADMIN))
                                .executes(ctx -> {
                                    if (!(ctx.getSource().method_9228() instanceof class_3222 player)) return 0;
                                    ACChatLockListener.toggleAdminMute(player.method_5667());
                                    boolean muted = ACChatLockListener.isAdminMuted(player.method_5667());
                                    ctx.getSource().method_9226(
                                            () -> class_2561.method_43470("[AbyssCore] Your chat is now " + (muted ? "muted" : "active") + "."),
                                            false);
                                    return 1;
                                })
                        )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore");
    }

}
