package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.gugas749.abysscore.features.bulk.BulkCommandData;
import com.gugas749.abysscore.features.bulk.BulkCommandManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import java.util.Collection;
import java.util.Optional;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;

/**
 * /abysscore bulk add → opens the creation GUI on the OP's client
 * /abysscore bulk remove <name>  → deletes a saved bulk command
 * /abysscore bulk list → lists all saved bulk commands
 * /abysscore run <name> → executes a saved bulk command
 */
public class ACBulkCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {

        dispatcher.register(
            class_2170.method_9247("abysscore")
                .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.MODERATOR))

                .then(class_2170.method_9247("bulk")

                    // /abysscore bulk remove <name>
                    .then(class_2170.method_9247("remove")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests((ctx, builder) ->
                                class_2172.method_9265(BulkCommandManager.getNames(), builder)
                            )
                            .executes(ACBulkCommands::executeBulkRemove)
                        )
                    )

                    // /abysscore bulk list
                    .then(class_2170.method_9247("list")
                        .executes(ACBulkCommands::executeBulkList)
                    )
                )
        );

        // /abysscore run <name> — usable by anyone depending on the command's permLevel
        dispatcher.register(
            class_2170.method_9247("abysscore")
                .then(class_2170.method_9247("run")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests((ctx, builder) ->
                            class_2172.method_9265(BulkCommandManager.getNames(), builder)
                        )
                        .executes(ACBulkCommands::executeRun)
                    )
                )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore bulk & /abysscore run");
    }

    // ── /abysscore bulk remove ───────────────────────────────────────────────

    private static int executeBulkRemove(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name").toLowerCase();

        if (BulkCommandManager.remove(name)) {
            source.method_9226(
                () -> class_2561.method_43469("message.abysscore.bulk.removed", name),
                true
            );
            return 1;
        } else {
            source.method_9213(class_2561.method_43469("message.abysscore.bulk.not_found", name));
            return 0;
        }
    }

    // ── /abysscore bulk list ─────────────────────────────────────────────────

    private static int executeBulkList(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        var all = BulkCommandManager.getAll();

        if (all.isEmpty()) {
            source.method_9226(
                () -> class_2561.method_43471("message.abysscore.bulk.list_empty"),
                false
            );
            return 0;
        }

        source.method_9226(
            () -> class_2561.method_43469("message.abysscore.bulk.list_header", all.size()),
            false
        );

        for (BulkCommandData cmd : all) {
            String permStr = cmd.permLevel == 0 ? "everyone" : "OP";
            source.method_9226(
                () -> class_2561.method_43470(
                    "  §e" + cmd.name + "§7 [perm: " + permStr + "] — " + cmd.commands.size() + " command(s)"
                ),
                false
            );
        }

        return all.size();
    }

    // ── /abysscore run <name> ────────────────────────────────────────────────

    private static int executeRun(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name").toLowerCase();

        Optional<BulkCommandData> opt = BulkCommandManager.get(name);
        if (opt.isEmpty()) {
            source.method_9213(class_2561.method_43469("message.abysscore.bulk.not_found", name));
            return 0;
        }

        BulkCommandData data = opt.get();

        // Check permission level
        if (!source.method_9259(data.permLevel)) {
            source.method_9213(class_2561.method_43471("message.abysscore.bulk.no_permission"));
            return 0;
        }

        int executed = 0;
        for (String cmd : data.commands) {
            try {
                source.method_9211().method_3734().method_9235().execute(cmd, source);
                executed++;
            } catch (Exception e) {
                Constants.LOG.warn(
                    "[AbyssCore] Bulk command '{}' failed on sub-command '{}': {}",
                    name, cmd, e.getMessage()
                );
                source.method_9213(
                    class_2561.method_43469("message.abysscore.bulk.cmd_failed", cmd)
                );
            }
        }

        int finalExecuted = executed;
        source.method_9226(
            () -> class_2561.method_43469("message.abysscore.bulk.run_success", name, finalExecuted),
            false
        );

        return executed;
    }
}
