package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_1928;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2232;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;


public class ACDimenSettingsCommands {
    // All boolean gamerules for tab completion
    private static final List<String> BOOL_GAMERULES = List.of(
            "doFireTick", "mobGriefing", "keepInventory", "doMobSpawning",
            "doMobLoot", "doTileDrops", "commandBlockOutput", "naturalRegeneration",
            "doDaylightCycle", "logAdminCommands", "showDeathMessages",
            "doWeatherCycle", "doLimitedCrafting", "doInsomnia",
            "doImmediateRespawn", "drowningDamage", "fallDamage", "fireDamage",
            "freezeDamage", "doPatrolSpawning", "doTraderSpawning",
            "doWardenSpawning", "forgiveDeadPlayers", "universalAnger",
            "announceAdvancements", "disableRaids", "doEntityDrops",
            "pvp", "sendCommandFeedback", "reducedDebugInfo"
    );

    // All integer gamerules for tab completion
    private static final List<String> INT_GAMERULES = List.of(
            "randomTickSpeed", "spawnRadius", "maxEntityCramming",
            "maxCommandChainLength", "playersSleepingPercentage"
    );

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("abysscore")
                        .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.MODERATOR))

                        .then(class_2170.method_9247("dimen")
                                .then(class_2170.method_9247("settings")

                                        .then(class_2170.method_9244("dimension", class_2232.method_9441())
                                                .suggests((ctx, builder) -> class_2172.method_9265(
                                                        getAllLoadedDimKeys(ctx.getSource().method_9211()), builder
                                                ))

                                                // list gamerules for this dimension
                                                .then(class_2170.method_9247("list")
                                                        .executes(ACDimenSettingsCommands::executeList)
                                                )

                                                // set a boolean gamerule
                                                .then(class_2170.method_9247("set")
                                                        .then(class_2170.method_9244("gamerule", StringArgumentType.word())
                                                                .suggests((ctx, builder) -> {
                                                                    List<String> all = new ArrayList<>(BOOL_GAMERULES);
                                                                    all.addAll(INT_GAMERULES);
                                                                    return class_2172.method_9265(all, builder);
                                                                })

                                                                // bool value
                                                                .then(class_2170.method_9244("bool_value", BoolArgumentType.bool())
                                                                        .executes(ACDimenSettingsCommands::executeSetBool)
                                                                )

                                                                // int value
                                                                .then(class_2170.method_9244("int_value", IntegerArgumentType.integer(0))
                                                                        .executes(ACDimenSettingsCommands::executeSetInt)
                                                                )
                                                        )
                                                )
                                        )
                                )
                        )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore dimen settings <dim> <list|set>");
    }

    // ── list ──────────────────────────────────────────────────────────────────

    private static int executeList(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        class_2960 dimId = class_2232.method_9443(ctx, "dimension");

        class_3218 level = findLevel(source.method_9211(), dimId.toString());
        if (level == null) {
            source.method_9213(class_2561.method_43469("message.abysscore.dimen.not_found_or_unloaded", dimId));
            return 0;
        }

        source.method_9226(
                () -> class_2561.method_43470("§1[AbyssCore] §fGamerules for §e" + dimId + "§f:"),
                false
        );

        class_1928 rules = level.method_8450();

        // Visit all gamerule keys and display their current value for this dimension
        class_1928.method_20744(new class_1928.class_4311() {
            @Override
            public <T extends class_1928.class_4315<T>> void method_20762(
                    class_1928.class_4313<T> key, class_1928.class_4314<T> type) {
                T value = rules.method_20746(key);
                source.method_9226(
                        () -> class_2561.method_43470("  " + key.method_20771() + " : " + value.method_20779()),
                        false
                );
            }
        });

        return 1;
    }

    // ── set bool ──────────────────────────────────────────────────────────────

    private static int executeSetBool(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        class_2960 dimId = class_2232.method_9443(ctx, "dimension");
        String ruleName = StringArgumentType.getString(ctx, "gamerule");
        boolean value = BoolArgumentType.getBool(ctx, "bool_value");

        class_3218 level = findLevel(source.method_9211(), dimId.toString());
        if (level == null) {
            source.method_9213(class_2561.method_43469("message.abysscore.dimen.not_found_or_unloaded", dimId));
            return 0;
        }

        // Find the gamerule key by name and set it
        boolean[] found = {false};
        class_1928.method_20744(new class_1928.class_4311() {
            @Override
            public void method_27329(class_1928.class_4313<class_1928.class_4310> key,
                                     class_1928.class_4314<class_1928.class_4310> type) {
                if (key.method_20771().equals(ruleName)) {
                    level.method_8450().method_20746(key).method_20758(value, null);
                    found[0] = true;
                    source.method_9226(
                            () -> class_2561.method_43470(
                                    "§e[AbyssCore] §fSet §e" + ruleName + "§f to §a" + value
                                            + "§f in §e" + dimId + "§f only."
                            ),
                            true
                    );
                }
            }
        });

        if (!found[0]) {
            source.method_9213(class_2561.method_43470(
                    "[AbyssCore] '" + ruleName + "' is not a boolean gamerule. Use an integer value instead."
            ));
            return 0;
        }

        Constants.LOG.info("[AbyssCore] Set gamerule {} = {} in dimension {}",
                ruleName, value, dimId);
        return 1;
    }

    // ── set int ───────────────────────────────────────────────────────────────

    private static int executeSetInt(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        class_2960 dimId = class_2232.method_9443(ctx, "dimension");
        String ruleName = StringArgumentType.getString(ctx, "gamerule");
        int value = IntegerArgumentType.getInteger(ctx, "int_value");

        class_3218 level = findLevel(source.method_9211(), dimId.toString());
        if (level == null) {
            source.method_9213(class_2561.method_43469("message.abysscore.dimen.not_found_or_unloaded", dimId));
            return 0;
        }

        boolean[] found = {false};
        class_1928.method_20744(new class_1928.class_4311() {
            @Override
            public void method_27330(class_1928.class_4313<class_1928.class_4312> key,
                                     class_1928.class_4314<class_1928.class_4312> type) {
                if (key.method_20771().equals(ruleName)) {
                    level.method_8450().method_20746(key).method_35236(value, null);
                    found[0] = true;
                    source.method_9226(
                            () -> class_2561.method_43470(
                                    "§e[AbyssCore] §fSet §e" + ruleName + "§f to §a" + value
                                            + "§f in §e" + dimId + "§f only."
                            ),
                            true
                    );
                }
            }
        });

        if (!found[0]) {
            source.method_9213(class_2561.method_43470(
                    "[AbyssCore] '" + ruleName + "' is not an integer gamerule. Use a boolean value instead."
            ));
            return 0;
        }

        Constants.LOG.info("[AbyssCore] Set gamerule {} = {} in dimension {}",
                ruleName, value, dimId);
        return 1;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static class_3218 findLevel(MinecraftServer server, String dimArg) {
        for (class_3218 level : server.method_3738()) {
            String key = level.method_27983().method_29177().toString();
            if (key.equals(dimArg)) return level;
        }
        return null;
    }

    private static List<String> getAllLoadedDimKeys(MinecraftServer server) {
        List<String> keys = new ArrayList<>();
        server.method_3738().forEach(l -> keys.add(l.method_27983().method_29177().toString()));
        return keys;
    }
}
