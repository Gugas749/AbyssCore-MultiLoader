package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.network.AbyssNetwork;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.gugas749.abysscore.features.dimen.ACDimensionData;
import com.gugas749.abysscore.features.dimen.ACDimensionManager;
import com.gugas749.abysscore.network.dimen.OpenDimenCreateScreenPacket;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2232;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Optional;

public class ACDimenCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("abysscore")
                .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.ADMIN))

                .then(class_2170.method_9247("dimen")

                    // ── tp ────────────────────────────────────────────────────
                    .then(class_2170.method_9247("tp")
                        .then(class_2170.method_9244("dimension", class_2232.method_9441())
                            .suggests((ctx, builder) -> class_2172.method_9265(
                                getAllLoadedDimKeys(ctx.getSource().method_9211()), builder
                            ))
                            .executes(ACDimenCommands::executeTp)
                        )
                    )

                    // ── list ──────────────────────────────────────────────────
                    .then(class_2170.method_9247("list")
                        .executes(ACDimenCommands::executeList)
                    )

                    // ── create ────────────────────────────────────────────────
                    .then(class_2170.method_9247("create")
                        .executes(ACDimenCommands::executeCreate)
                    )

                    // ── unload ────────────────────────────────────────────────
                    .then(class_2170.method_9247("unload")
                        .then(class_2170.method_9244("dimension", class_2232.method_9441())
                            .suggests((ctx, builder) -> class_2172.method_9265(
                                getUnloadableDimKeys(ctx.getSource().method_9211()), builder
                            ))
                            .executes(ACDimenCommands::executeUnload)
                        )
                    )

                    // ── load ──────────────────────────────────────────────────
                    .then(class_2170.method_9247("load")
                        .then(class_2170.method_9244("dimension", class_2232.method_9441())
                            .suggests((ctx, builder) -> class_2172.method_9265(
                                getManagedUnloadedDimNames(), builder
                            ))
                            .executes(ACDimenCommands::executeLoad)
                        )
                    )

                    // ── remove ────────────────────────────────────────────────
                    .then(class_2170.method_9247("remove")
                        .then(class_2170.method_9244("dimension", class_2232.method_9441())
                            .suggests((ctx, builder) -> class_2172.method_9265(
                                getManagedDimNames(), builder
                            ))
                            .executes(ACDimenCommands::executeRemove)
                        )
                    )
                )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore dimen <tp|list|create|unload|load|remove>");
    }

    // ── /abysscore dimen tp <dimension> ──────────────────────────────────────

    private static int executeTp(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        String dimArg = class_2232.method_9443(ctx, "dimension").toString();

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.dimen.player_only"));
            return 0;
        }

        MinecraftServer server = source.method_9211();

        // Try to find the dimension — accept short names like "the_nether" or full
        // "minecraft:the_nether" or AbyssCore-managed "my_world" → "abysscore:my_world"
        class_3218 target = findLevel(server, dimArg);

        if (target == null) {
            source.method_9213(class_2561.method_43469("message.abysscore.dimen.not_found_or_unloaded", dimArg));
            return 0;
        }

        // Teleport to dimension
        net.minecraft.class_2338 spawn = target.method_43126();
        player.method_14251(
            target,
            spawn.method_10263() + 0.5,
            spawn.method_10264(),
            spawn.method_10260() + 0.5,
            player.method_36454(),
            player.method_36455()
        );

        source.method_9226(
            () -> class_2561.method_43469("message.abysscore.dimen.teleported",
                target.method_27983().method_29177().toString()),
            false
        );
        return 1;
    }

    // ── /abysscore dimen list ─────────────────────────────────────────────────

    private static int executeList(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        MinecraftServer server = source.method_9211();

        source.method_9226(
            () -> class_2561.method_43471("message.abysscore.dimen.list_header"),
            false
        );

        // All loaded levels — vanilla + modded + AbyssCore
        server.method_3738().forEach(level -> {
            String key = level.method_27983().method_29177().toString();
            String stateTag = "";

            // Check if it's AbyssCore-managed
            String name = level.method_27983().method_29177().method_12832();
            Optional<ACDimensionData> managed = ACDimensionManager.get(name);
            if (managed.isPresent()) {
                stateTag = " [abysscore:" + managed.get().state.name().toLowerCase() + "]";
            }

            final String line = "  " + key + stateTag;
            source.method_9226(() -> class_2561.method_43470(line), false);
        });

        // Also show PENDING_CREATE and UNLOADED dims (not currently loaded)
        ACDimensionManager.getAll().forEach(data -> {
            if (data.state == ACDimensionData.State.PENDING_CREATE
                    || data.state == ACDimensionData.State.UNLOADED
                    || data.state == ACDimensionData.State.PENDING_REMOVE) {
                String line = "  abysscore:" + data.name
                    + " [" + data.state.name().toLowerCase() + "]"
                    + (data.state == ACDimensionData.State.PENDING_CREATE
                        ? " (restart required)" : "");
                source.method_9226(() -> class_2561.method_43470(line), false);
            }
        });

        return 1;
    }

    // ── /abysscore dimen create ───────────────────────────────────────────────

    private static int executeCreate(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.dimen.player_only"));
            return 0;
        }

        // Send packet to open the creation screen
        AbyssNetwork.sendToPlayer(player, new OpenDimenCreateScreenPacket());
        return 1;
    }

    // ── /abysscore dimen unload <dimension> ──────────────────────────────────

    private static int executeUnload(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        String dimArg  = class_2232.method_9443(ctx, "dimension").toString();
        String dimName = class_2232.method_9443(ctx, "dimension").method_12832();

        if (isVanillaDim(dimArg)) {
            source.method_9213(class_2561.method_43469("message.abysscore.dimen.cannot_unload_vanilla", dimArg));
            return 0;
        }

        // Check if it's an AbyssCore-managed dim
        if (ACDimensionManager.exists(dimName)) {
            boolean success = ACDimensionManager.unload(dimName, source.method_9211());
            if (!success) {
                source.method_9213(class_2561.method_43469("message.abysscore.dimen.not_found_or_unloaded", dimArg));
                return 0;
            }
            source.method_9226(
                    () -> class_2561.method_43469("message.abysscore.dimen.unloaded_pending", dimArg), true);
            return 1;
        }

        source.method_9213(class_2561.method_43469("message.abysscore.dimen.cannot_unload_external", dimArg));
        return 0;
    }

    // ── /abysscore dimen load <dimension> ────────────────────────────────────

    private static int executeLoad(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        String dimArg  = class_2232.method_9443(ctx, "dimension").toString();
        String dimName = class_2232.method_9443(ctx, "dimension").method_12832();

        boolean success = ACDimensionManager.load(dimName, source.method_9211());
        if (!success) {
            source.method_9213(class_2561.method_43469("message.abysscore.dimen.not_found_or_loaded", dimArg));
            return 0;
        }

        source.method_9226(
                () -> class_2561.method_43469("message.abysscore.dimen.load_pending", dimArg),
                true
        );
        return 1;
    }

    // ── /abysscore dimen remove <dimension> ──────────────────────────────────

    private static int executeRemove(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        String dimArg  = class_2232.method_9443(ctx, "dimension").toString();
        String dimName = class_2232.method_9443(ctx, "dimension").method_12832();

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.dimen.player_only"));
            return 0;
        }

        if (isVanillaDim(dimArg)) {
            source.method_9213(class_2561.method_43469("message.abysscore.dimen.cannot_remove_vanilla", dimArg));
            return 0;
        }

        if (!ACDimensionManager.exists(dimName)) {
            source.method_9213(class_2561.method_43469("message.abysscore.dimen.not_found", dimArg));
            return 0;
        }

        if (!ACDimensionManager.hasPendingConfirm(player.method_5667(), dimName)) {
            ACDimensionManager.startRemoveConfirm(player.method_5667(), dimName);
            source.method_9226(
                    () -> class_2561.method_43469("message.abysscore.dimen.remove_confirm", dimArg),
                    false
            );
            return 0;
        }

        boolean success = ACDimensionManager.confirmRemove(dimName, source.method_9211());
        if (!success) {
            source.method_9213(class_2561.method_43469("message.abysscore.dimen.remove_failed", dimArg));
            return 0;
        }

        source.method_9226(
                () -> class_2561.method_43469("message.abysscore.dimen.removed_pending", dimArg),
                true
        );
        return 1;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static class_3218 findLevel(MinecraftServer server, String dimArg) {
        for (class_3218 level : server.method_3738()) {
            String key = level.method_27983().method_29177().toString();
            String path = level.method_27983().method_29177().method_12832();

            if (key.equals(dimArg) || path.equals(dimArg)
                    || key.equals("minecraft:" + dimArg)
                    || key.equals("abysscore:" + dimArg)) {
                return level;
            }
        }
        return null;
    }

    private static List<String> getAllLoadedDimKeys(MinecraftServer server) {
        List<String> keys = new java.util.ArrayList<>();
        server.method_3738().forEach(l -> keys.add(l.method_27983().method_29177().toString()));
        return keys;
    }

    private static List<String> getManagedDimNames() {
        return ACDimensionManager.getAll().stream()
            .map(d -> d.name)
            .toList();
    }

    private static List<String> getManagedUnloadedDimNames() {
        return ACDimensionManager.getAll().stream()
            .filter(d -> d.state == ACDimensionData.State.UNLOADED)
            .map(d -> d.name)
            .toList();
    }

    private static boolean isVanillaDim(String name) {
        return name.equals("overworld") || name.equals("the_nether") || name.equals("the_end")
            || name.equals("minecraft:overworld") || name.equals("minecraft:the_nether")
            || name.equals("minecraft:the_end");
    }

    private static List<String> getUnloadableDimKeys(MinecraftServer server) {
        List<String> keys = new java.util.ArrayList<>();
        server.method_3738().forEach(level -> {
            String key = level.method_27983().method_29177().toString();
            if (!isVanillaDim(key)) {
                keys.add(key);
            }
        });
        return keys;
    }
}
