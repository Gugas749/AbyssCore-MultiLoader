package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ACPermissionCommands {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("abysscore")
                        .requires(source -> source.method_9259(2))

                        .then(class_2170.method_9247("permission")
                                .then(class_2170.method_9247("grant")
                                        .then(class_2170.method_9244("target", class_2186.method_9305())
                                                .then(class_2170.method_9244("level", StringArgumentType.word())
                                                        .suggests((ctx, builder) -> class_2172.method_9265(
                                                                java.util.Arrays.stream(AbyssPermissionLevel.values())
                                                                        .filter(l -> l != AbyssPermissionLevel.ADMIN)
                                                                        .map(Enum::name)
                                                                        .toList(),
                                                                builder
                                                        ))
                                                        .executes(ACPermissionCommands::executeGrant)
                                                )
                                        )
                                )

                                .then(class_2170.method_9247("revoke")
                                        .then(class_2170.method_9244("target", class_2186.method_9305())
                                                .executes(ACPermissionCommands::executeRevoke)
                                        )
                                )
                        )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore permissions");
    }

    private static int executeGrant(CommandContext<class_2168> ctx){
        class_2168 source = ctx.getSource();
        try {
            class_3222 player = class_2186.method_9315(ctx, "target");
            String levelStr = StringArgumentType.getString(ctx, "level");
            AbyssPermissionLevel level;

            try {
                level = AbyssPermissionLevel.valueOf(levelStr.toUpperCase());
            } catch (IllegalArgumentException e) {
                source.method_9213(class_2561.method_43471("message.abysscore.permission.invalidlevel"));
                return 0;
            }

            AbyssPermissionHandler.grant(player.method_5667(), level);
            source.method_9226(() -> class_2561.method_43469("message.abysscore.permission.grant", StringArgumentType.getString(ctx, "level"), player.method_5477()), true);
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43471("message.abysscore.god.player_not_found"));
            return 0;
        }
    }

    private static int executeRevoke(CommandContext<class_2168> ctx){
        class_2168 source = ctx.getSource();
        try {
            class_3222 player = class_2186.method_9315(ctx, "target");
            AbyssPermissionHandler.revoke(player.method_5667());
            source.method_9226(() -> class_2561.method_43469("message.abysscore.permission.revoke", player.method_5477()), true);
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43471("message.abysscore.god.player_not_found"));
            return 0;
        }
    }
}
