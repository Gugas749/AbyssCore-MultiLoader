package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.gugas749.abysscore.features.blind.ACBlindManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ACBlindCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("abysscore")
                .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.MODERATOR))

                .then(class_2170.method_9247("blind")
                    .then(class_2170.method_9244("target", class_2186.method_9305())
                        .executes(ACBlindCommands::executeBlind)
                    )
                )

                .then(class_2170.method_9247("unblind")
                    .then(class_2170.method_9244("target", class_2186.method_9305())
                        .executes(ACBlindCommands::executeUnblind)
                    )
                )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore blind|unblind <player>");
    }

    private static int executeBlind(CommandContext<class_2168> ctx) {
        try {
            class_3222 target = class_2186.method_9315(ctx, "target");
            ACBlindManager.blind(target);
            ctx.getSource().method_9226(() -> class_2561.method_43469("message.abysscore.blind.enabled", target.method_5477().getString()),
                true
            );
            target.method_43496(
                class_2561.method_43471("message.abysscore.blind.enabled_self"));
            return 1;
        } catch (Exception e) {
            ctx.getSource().method_9213(
                class_2561.method_43471("message.abysscore.blind.player_not_found"));
            return 0;
        }
    }

    private static int executeUnblind(CommandContext<class_2168> ctx) {
        try {
            class_3222 target = class_2186.method_9315(ctx, "target");
            ACBlindManager.unblind(target);
            ctx.getSource().method_9226(
                () -> class_2561.method_43469("message.abysscore.blind.disabled",
                    target.method_5477().getString()),
                true
            );
            target.method_43496(
                class_2561.method_43471("message.abysscore.blind.disabled_self"));
            return 1;
        } catch (Exception e) {
            ctx.getSource().method_9213(
                class_2561.method_43471("message.abysscore.blind.player_not_found"));
            return 0;
        }
    }
}
