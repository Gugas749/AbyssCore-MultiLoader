package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.network.AbyssNetwork;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.gugas749.abysscore.features.regions.ACRegion;
import com.gugas749.abysscore.features.regions.ACRegionSavedData;
import com.gugas749.abysscore.features.regions.ACWorldEditSelection;
import com.gugas749.abysscore.network.region.OpenRegionScreenPacket;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class ACRegionCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("abysscore")
                .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.ADMIN))

                .then(class_2170.method_9247("region")

                    // ── add via WorldEdit selection ───────────────────────────
                    .then(class_2170.method_9247("add")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(ACRegionCommands::executeAddFromWorldEdit)
                            .then(class_2170.method_9244("from", class_2262.method_9698())
                                .then(class_2170.method_9244("to", class_2262.method_9698())
                                    .executes(ACRegionCommands::executeAddFromCorners)
                                )
                            )
                        )
                    )

                    // ── tp to region ──────────────────────────────────────────
                    .then(class_2170.method_9247("tp")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests((ctx, builder) -> class_2172.method_9265(
                                getRegionNames(ctx.getSource().method_9225()), builder
                            ))
                            .executes(ACRegionCommands::executeTp)
                        )
                    )

                    // ── open region manager screen ────────────────────────────
                    .then(class_2170.method_9247("screen")
                        .executes(ACRegionCommands::executeScreen)
                    )
                )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore region <add|tp|screen>");
    }

    // ── screen ────────────────────────────────────────────────────────────────

    private static int executeScreen(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.region.player_required"));
            return 0;
        }

        ACRegionSavedData data = ACRegionSavedData.get(source.method_9225());
        List<OpenRegionScreenPacket.RegionEntry> entries = new ArrayList<>();

        for (ACRegion region : data.regions()) {
            entries.add(new OpenRegionScreenPacket.RegionEntry(
                    region.name(), region.dimension(),
                    region.minX(), region.minY(), region.minZ(),
                    region.maxX(), region.maxY(), region.maxZ(),
                    region.tags(),
                    region.entryFilterTag()
            ));
        }

        AbyssNetwork.sendToPlayer(player, new OpenRegionScreenPacket(entries));
        return 1;
    }

    // ── tp ────────────────────────────────────────────────────────────────────

    private static int executeTp(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.region.player_required"));
            return 0;
        }

        Optional<ACRegion> regionOpt = ACRegionSavedData.get(source.method_9225()).getRegion(name);
        if (regionOpt.isEmpty()) {
            source.method_9213(class_2561.method_43469("message.abysscore.region.not_found", name));
            return 0;
        }

        ACRegion region = regionOpt.get();
        class_3218 targetLevel = null;
        for (class_3218 level : source.method_9211().method_3738()) {
            if (level.method_27983().method_29177().toString().equals(region.dimension())) {
                targetLevel = level;
                break;
            }
        }

        if (targetLevel == null) {
            source.method_9213(class_2561.method_43469("message.abysscore.region.dimension_not_loaded",
                region.dimension()));
            return 0;
        }

        double cx = (region.minX() + region.maxX()) / 2.0 + 0.5;
        double cz = (region.minZ() + region.maxZ()) / 2.0 + 0.5;
        double cy = region.minY() + 1;
        player.method_14251(targetLevel, cx, cy, cz, player.method_36454(), player.method_36455());

        source.method_9226(
            () -> class_2561.method_43469("message.abysscore.region.tp", name), false);
        return 1;
    }

    // ── add ───────────────────────────────────────────────────────────────────

    private static int executeAddFromWorldEdit(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");

        class_3222 player;
        try { player = source.method_9207(); }
        catch (Exception e) {
            source.method_9213(class_2561.method_43471("message.abysscore.region.player_required"));
            return 0;
        }

        Optional<ACWorldEditSelection.Selection> selection;
        try {
            selection = ACWorldEditSelection.getSelection(player);
        } catch (ACWorldEditSelection.SelectionUnavailableException e) {
            source.method_9213(class_2561.method_43471(
                e.reason() == ACWorldEditSelection.SelectionUnavailableReason.INCOMPLETE
                    ? "message.abysscore.region.worldedit_incomplete"
                    : "message.abysscore.region.worldedit_error"
            ));
            return 0;
        }

        if (selection.isEmpty()) {
            source.method_9213(class_2561.method_43471("message.abysscore.region.worldedit_missing"));
            return 0;
        }

        return addRegion(source, name, selection.get().min(), selection.get().max());
    }

    private static int executeAddFromCorners(CommandContext<class_2168> ctx) {
        return addRegion(
            ctx.getSource(),
            StringArgumentType.getString(ctx, "name"),
            class_2262.method_48299(ctx, "from"),
            class_2262.method_48299(ctx, "to")
        );
    }

    private static int addRegion(class_2168 source, String name, class_2338 from, class_2338 to) {
        class_3218 level = source.method_9225();
        String dimension = level.method_27983().method_29177().toString();
        boolean added = ACRegionSavedData.get(level).addRegion(name, dimension, from, to);

        if (!added) {
            source.method_9213(class_2561.method_43469("message.abysscore.region.already_exists", name));
            return 0;
        }
        source.method_9226(
            () -> class_2561.method_43469("message.abysscore.region.added",
                name, dimension,
                from.method_10263(), from.method_10264(), from.method_10260(),
                to.method_10263(), to.method_10264(), to.method_10260()),
            true
        );
        return 1;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static List<String> getRegionNames(class_3218 level) {
        return ACRegionSavedData.get(level).regions().stream()
            .map(ACRegion::name).toList();
    }
}
