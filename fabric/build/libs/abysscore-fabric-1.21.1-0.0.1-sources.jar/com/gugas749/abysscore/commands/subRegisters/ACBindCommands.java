package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.gugas749.abysscore.features.bind.BindManager;
import com.gugas749.abysscore.features.bulk.BulkCommandManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * /abysscore bind set <slot 1-9> <bulkName or raw command>
 * /abysscore bind clear <slot 1-9>
 * /abysscore bind list
 */
public class ACBindCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {

        dispatcher.register(
                class_2170.method_9247("abysscore")
                        .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.ADMIN))
                        .then(class_2170.method_9247("bind")

                                // /abysscore bind set <slot> <value>
                                .then(class_2170.method_9247("set")
                                        .then(class_2170.method_9244("slot", IntegerArgumentType.integer(1, 9))
                                                .then(class_2170.method_9244("value", StringArgumentType.greedyString())
                                                        .suggests((ctx, builder) -> {
                                                            // Suggest existing bulk command names
                                                            List<String> suggestions = new ArrayList<>(BulkCommandManager.getNames());
                                                            return class_2172.method_9265(suggestions, builder);
                                                        })
                                                        .executes(ACBindCommands::executeSet)
                                                )
                                        )
                                )

                                // /abysscore bind clear <slot>
                                .then(class_2170.method_9247("clear")
                                        .then(class_2170.method_9244("slot", IntegerArgumentType.integer(1, 9))
                                                .executes(ACBindCommands::executeClear)
                                        )
                                )

                                // /abysscore bind list
                                .then(class_2170.method_9247("list")
                                        .executes(ACBindCommands::executeList)
                                )
                        )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore bind <set|clear|list>");
    }

    // ── /abysscore bind set <slot> <value> ───────────────────────────────────

    private static int executeSet(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.bulk.player_only"));
            return 0;
        }

        int slot    = IntegerArgumentType.getInteger(ctx, "slot");
        String value = StringArgumentType.getString(ctx, "value").trim();

        if (value.isEmpty()) {
            source.method_9213(class_2561.method_43471("message.abysscore.bind.empty_value"));
            return 0;
        }

        BindManager.setBinding(player.method_5667(), slot, value);

        // Tell the player what got bound, and whether it matched a bulk command
        boolean isBulk = BulkCommandManager.get(value).isPresent();
        source.method_9226(
                () -> class_2561.method_43469(
                        isBulk
                                ? "message.abysscore.bind.set_bulk"
                                : "message.abysscore.bind.set_raw",
                        slot, value
                ),
                false
        );

        return 1;
    }

    // ── /abysscore bind clear <slot> ─────────────────────────────────────────

    private static int executeClear(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.bulk.player_only"));
            return 0;
        }

        int slot = IntegerArgumentType.getInteger(ctx, "slot");
        String existing = BindManager.getBinding(player.method_5667(), slot);

        if (existing == null) {
            source.method_9226(
                    () -> class_2561.method_43469("message.abysscore.bind.already_empty", slot),
                    false
            );
            return 0;
        }

        BindManager.clearBinding(player.method_5667(), slot);
        source.method_9226(
                () -> class_2561.method_43469("message.abysscore.bind.cleared", slot),
                false
        );
        return 1;
    }

    // ── /abysscore bind list ──────────────────────────────────────────────────

    private static int executeList(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.bulk.player_only"));
            return 0;
        }

        Map<String, String> binds = BindManager.getAllBindings(player.method_5667());

        source.method_9226(
                () -> class_2561.method_43471("message.abysscore.bind.list_header"),
                false
        );

        boolean anyBound = false;
        for (int i = 1; i <= 9; i++) {
            String bound = binds.get(String.valueOf(i));
            final int slot = i;
            if (bound != null) {
                boolean isBulk = BulkCommandManager.get(bound).isPresent();
                final String display = bound;
                source.method_9226(
                        () -> class_2561.method_43470(
                                "  Slot " + slot + ": " + display
                                        + (isBulk ? " [bulk]" : " [cmd]")
                        ),
                        false
                );
                anyBound = true;
            } else {
                source.method_9226(
                        () -> class_2561.method_43470("  Slot " + slot + ": unbound"),
                        false
                );
            }
        }

        return anyBound ? 1 : 0;
    }
}
