package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.features.help.ACHelpManager;
import com.gugas749.abysscore.network.AbyssHelpWebhook;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import java.util.Collection;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ACHelpCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {

        // ── /abysshelp ────────────────────────────────────────────────────────
        dispatcher.register(
            class_2170.method_9247("abysshelp")

                .then(class_2170.method_9244("reason", StringArgumentType.greedyString())
                    .executes(ACHelpCommands::executeHelp)
                )

                .then(class_2170.method_9247("cancel")
                    .executes(ACHelpCommands::executeCancel)
                )

                .then(class_2170.method_9247("list")
                    .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.MODERATOR))
                    .executes(ACHelpCommands::executeList)
                )
        );

        // ── /abysscore helpaccept <player> ────────────────────────────────────
        dispatcher.register(
                class_2170.method_9247("abysscore")
                        .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.MODERATOR))
                        .then(class_2170.method_9247("helpaccept")
                                .then(class_2170.method_9244("target", StringArgumentType.word())
                                        .suggests((ctx, builder) -> class_2172.method_9265(
                                                ACHelpManager.getAll().stream()
                                                        .map(r -> r.playerName)
                                                        .toList(),
                                                builder
                                        ))
                                        .executes(ACHelpCommands::executeAccept)
                                )
                        )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysshelp and /abysscore helpaccept");
    }

    // ── /abysshelp <reason> ───────────────────────────────────────────────────

    private static int executeHelp(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.help.player_only"));
            return 0;
        }

        if (ACHelpManager.hasActiveRequest(player.method_5667())) {
            source.method_9213(class_2561.method_43471("message.abysscore.help.already_pending"));
            return 0;
        }

        String reason = StringArgumentType.getString(ctx, "reason");
        boolean submitted = ACHelpManager.submit(player, reason, source.method_9211());

        if (submitted) {
            source.method_9226(
                () -> class_2561.method_43471("message.abysscore.help.submitted"),
                false
            );

            AbyssHelpWebhook.sendDCMessage(
                    player.method_7334().getName(),
                    player.method_5667().toString(),
                    reason
            );
        } else {
            source.method_9213(class_2561.method_43471("message.abysscore.help.already_pending"));
        }

        return submitted ? 1 : 0;
    }

    // ── /abysshelp cancel ────────────────────────────────────────────────────

    private static int executeCancel(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.abysscore.help.player_only"));
            return 0;
        }

        boolean cancelled = ACHelpManager.cancel(player);
        if (cancelled) {
            source.method_9226(
                () -> class_2561.method_43471("message.abysscore.help.cancelled"),
                false
            );
        } else {
            source.method_9213(class_2561.method_43471("message.abysscore.help.no_request"));
        }

        return cancelled ? 1 : 0;
    }

    // ── /abysshelp list ───────────────────────────────────────────────────────

    private static int executeList(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        var all = ACHelpManager.getAll();

        if (all.isEmpty()) {
            source.method_9226(
                () -> class_2561.method_43471("message.abysscore.help.list_empty"),
                false
            );
            return 0;
        }

        source.method_9226(
            () -> class_2561.method_43469("message.abysscore.help.list_header", all.size()),
            false
        );

        all.forEach(req -> source.method_9226(
            () -> class_2561.method_43470("  §e" + req.playerName + "§7: §f" + req.reason),
            false
        ));

        return all.size();
    }

    // ── /abysscore helpaccept <player> ────────────────────────────────────────

    private static int executeAccept(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();

        if (!(source.method_9228() instanceof class_3222 staff)) {
            source.method_9213(class_2561.method_43471("message.abysscore.help.player_only"));
            return 0;
        }

        String targetName = StringArgumentType.getString(ctx, "target");

        UUID targetUUID = ACHelpManager.getAll().stream()
                .filter(r -> r.playerName.equalsIgnoreCase(targetName))
                .map(r -> r.playerUUID)
                .findFirst()
                .orElse(null);

        if (targetUUID == null) {
            source.method_9213(
                    class_2561.method_43469("message.abysscore.help.no_request_for", targetName)
            );
            return 0;
        }

        boolean accepted = ACHelpManager.accept(staff, targetUUID);
        if (!accepted) {
            source.method_9213(
                    class_2561.method_43469("message.abysscore.help.accept_failed", targetName)
            );
            return 0;
        }

        return 1;
    }
}
