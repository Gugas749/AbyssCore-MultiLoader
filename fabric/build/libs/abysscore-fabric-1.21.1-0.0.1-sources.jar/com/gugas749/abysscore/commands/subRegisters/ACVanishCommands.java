package com.gugas749.abysscore.commands.subRegisters;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.gugas749.abysscore.features.vanish.ACVanishExtras;
import com.gugas749.abysscore.features.vanish.VanishManager;
import com.gugas749.abysscore.features.vanish.VanishOption;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * /abysscore vanish                          toggle yourself
 * /abysscore vanish on | off                 set yourself
 * /abysscore vanish toggle <players>         toggle other players
 * /abysscore vanish list                     who is vanished
 * /abysscore vanish option                   your options
 * /abysscore vanish option <name> [true|false]   flip or set one option
 * /abysscore vanish teamvisibility           teammates can / can't see vanished players
 * /abysscore vanish show|hide <player>       per-player exception for YOU
 * /abysscore vanish clearexceptions | status
 */
public class ACVanishCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("abysscore")
                // .requires on the SUB-literal: Brigadier merges every literal("abysscore")
                // and keeps only the first root .requires (ACModCommands' MODERATOR one).
                .then(class_2170.method_9247("vanish")
                    .requires(source -> AbyssPermissionHandler.sourceHas(source, AbyssPermissionLevel.ADMIN))
                    .executes(ctx -> setSelf(ctx, null))

                    .then(class_2170.method_9247("on").executes(ctx -> setSelf(ctx, true)))
                    .then(class_2170.method_9247("off").executes(ctx -> setSelf(ctx, false)))

                    .then(class_2170.method_9247("toggle")
                        .then(class_2170.method_9244("targets", class_2186.method_9308())
                            .executes(ACVanishCommands::executeToggleOthers)))

                    .then(class_2170.method_9247("list").executes(ACVanishCommands::executeList))

                    .then(class_2170.method_9247("option")
                        .executes(ACVanishCommands::executeListOptions)
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests((ctx, builder) -> class_2172.method_9264(
                                    Arrays.stream(VanishOption.values()).map(VanishOption::id), builder))
                            .executes(ctx -> executeOption(ctx, null))
                            .then(class_2170.method_9244("value", BoolArgumentType.bool())
                                .executes(ctx -> executeOption(ctx, BoolArgumentType.getBool(ctx, "value"))))))

                    .then(class_2170.method_9247("teamvisibility").executes(ACVanishCommands::executeTeamVisibility))

                    .then(class_2170.method_9247("show")
                        .then(class_2170.method_9244("target", class_2186.method_9305())
                            .executes(ctx -> executeException(ctx, true))))

                    .then(class_2170.method_9247("hide")
                        .then(class_2170.method_9244("target", class_2186.method_9305())
                            .executes(ctx -> executeException(ctx, false))))

                    .then(class_2170.method_9247("clearexceptions").executes(ACVanishCommands::executeClear))

                    .then(class_2170.method_9247("status").executes(ACVanishCommands::executeStatus))
                )
        );

        Constants.LOG.info("[AbyssCore] Registered: /abysscore vanish <on|off|toggle|list|option|teamvisibility|show|hide|clearexceptions|status>");
    }

    // ── Toggle ────────────────────────────────────────────────────────────────

    /** value null = toggle. The player gets the CHAT_NOTICE message from VanishManager. */
    private static int setSelf(CommandContext<class_2168> ctx, Boolean value) {
        class_3222 self = playerOrFail(ctx.getSource());
        if (self == null) return 0;
        boolean target = value != null ? value : !VanishManager.isVanished(self.method_5667());
        VanishManager.setVanished(self, target);
        return 1;
    }

    private static int executeToggleOthers(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        Collection<class_3222> targets = class_2186.method_9312(ctx, "targets");
        for (class_3222 target : targets) {
            boolean nowVanished = VanishManager.toggle(target);
            ctx.getSource().method_9226(() -> class_2561.method_43469(
                    nowVanished ? "message.abysscore.vanish.other_vanished" : "message.abysscore.vanish.other_visible",
                    target.method_5477().getString()), true);
        }
        return targets.size();
    }

    // ── List ──────────────────────────────────────────────────────────────────

    private static int executeList(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        var vanished = VanishManager.getVanished();
        if (vanished.isEmpty()) {
            source.method_9226(() -> class_2561.method_43471("message.abysscore.vanish.list_empty"), false);
            return 0;
        }
        source.method_9226(() -> class_2561.method_43469("message.abysscore.vanish.list_header", vanished.size()), false);
        for (UUID uuid : vanished) {
            class_3222 p = source.method_9211().method_3760().method_14602(uuid);
            class_2561 line = p != null
                    ? class_2561.method_43470("  - ").method_10852(class_2561.method_43470(p.method_5477().getString()).method_27692(class_124.field_1068))
                    : class_2561.method_43470("  - " + uuid + " ").method_10852(class_2561.method_43471("message.abysscore.vanish.offline").method_27692(class_124.field_1063));
            source.method_9226(() -> line, false);
        }
        return vanished.size();
    }

    // ── Options ───────────────────────────────────────────────────────────────

    private static int executeListOptions(CommandContext<class_2168> ctx) {
        class_3222 self = playerOrFail(ctx.getSource());
        if (self == null) return 0;
        ctx.getSource().method_9226(() -> class_2561.method_43471("message.abysscore.vanish.options_header"), false);
        for (VanishOption option : VanishOption.values()) {
            boolean on = VanishManager.getOption(self.method_5667(), option);
            class_2561 line = class_2561.method_43470("  " + option.id() + ": ").method_27692(class_124.field_1080)
                    .method_10852(onOff(on))
                    .method_10852(class_2561.method_43470("  ").method_10852(class_2561.method_43471(option.descriptionKey())).method_27692(class_124.field_1063));
            ctx.getSource().method_9226(() -> line, false);
        }
        return 1;
    }

    /** value null = flip the current value. */
    private static int executeOption(CommandContext<class_2168> ctx, Boolean value) {
        class_3222 self = playerOrFail(ctx.getSource());
        if (self == null) return 0;

        String name = StringArgumentType.getString(ctx, "name");
        VanishOption option = VanishOption.byId(name);
        if (option == null) {
            ctx.getSource().method_9213(class_2561.method_43469("message.abysscore.vanish.option_unknown", name));
            return 0;
        }
        boolean newValue = value != null ? value : !VanishManager.getOption(self.method_5667(), option);
        VanishManager.setOption(self, option, newValue);
        ctx.getSource().method_9226(() -> class_2561.method_43469("message.abysscore.vanish.option_set",
                class_2561.method_43471(option.labelKey()), onOff(newValue)), false);
        return 1;
    }

    // ── Team visibility ───────────────────────────────────────────────────────

    private static int executeTeamVisibility(CommandContext<class_2168> ctx) {
        boolean nowEnabled = ACVanishExtras.toggleTeamVisibility(ctx.getSource().method_9211());
        ctx.getSource().method_9226(() -> class_2561.method_43471(
                nowEnabled ? "message.abysscore.vanish.team_visible" : "message.abysscore.vanish.team_hidden"), true);
        return 1;
    }

    // ── Exceptions ────────────────────────────────────────────────────────────

    /** show = true → /vanish show, false → /vanish hide. Both are about YOU (the sender). */
    private static int executeException(CommandContext<class_2168> ctx, boolean show) {
        class_2168 source = ctx.getSource();
        class_3222 self = playerOrFail(source);
        if (self == null) return 0;
        try {
            class_3222 target = class_2186.method_9315(ctx, "target");
            if (target.equals(self)) {
                source.method_9213(class_2561.method_43471("message.abysscore.vanish.cannot_target_self"));
                return 0;
            }
            if (show) ACVanishExtras.showTo(self.method_5667(), target.method_5667(), source.method_9211());
            else ACVanishExtras.hideTo(self.method_5667(), target.method_5667(), source.method_9211());
            source.method_9226(() -> class_2561.method_43469(
                    show ? "message.abysscore.vanish.shown_to" : "message.abysscore.vanish.hidden_from",
                    target.method_5477().getString()), false);
            return 1;
        } catch (CommandSyntaxException e) {
            source.method_9213(class_2561.method_43471("message.abysscore.vanish.player_not_found"));
            return 0;
        }
    }

    private static int executeClear(CommandContext<class_2168> ctx) {
        class_3222 self = playerOrFail(ctx.getSource());
        if (self == null) return 0;
        ACVanishExtras.clearExceptions(self.method_5667(), ctx.getSource().method_9211());
        ctx.getSource().method_9226(() -> class_2561.method_43471("message.abysscore.vanish.exceptions_cleared"), false);
        return 1;
    }

    private static int executeStatus(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        class_3222 self = playerOrFail(source);
        if (self == null) return 0;

        source.method_9226(() -> class_2561.method_43471(VanishManager.isVanished(self.method_5667())
                ? "message.abysscore.vanish.status_vanished" : "message.abysscore.vanish.status_visible"), false);
        source.method_9226(() -> class_2561.method_43471(ACVanishExtras.isTeamVisibilityEnabled()
                ? "message.abysscore.vanish.team_status_on" : "message.abysscore.vanish.team_status_off"), false);

        var shownTo    = ACVanishExtras.getShownTo(self.method_5667());
        var hiddenFrom = ACVanishExtras.getHiddenFrom(self.method_5667());
        if (shownTo.isEmpty() && hiddenFrom.isEmpty()) {
            source.method_9226(() -> class_2561.method_43471("message.abysscore.vanish.no_exceptions"), false);
            return 1;
        }
        shownTo.forEach(uuid -> source.method_9226(() -> class_2561.method_43469(
                "message.abysscore.vanish.status_shown", name(source, uuid)), false));
        hiddenFrom.forEach(uuid -> source.method_9226(() -> class_2561.method_43469(
                "message.abysscore.vanish.status_hidden", name(source, uuid)), false));
        return 1;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static class_3222 playerOrFail(class_2168 source) {
        if (source.method_9228() instanceof class_3222 player) return player;
        source.method_9213(class_2561.method_43471("message.abysscore.vanish.player_only"));
        return null;
    }

    private static String name(class_2168 source, UUID uuid) {
        class_3222 p = source.method_9211().method_3760().method_14602(uuid);
        return p != null ? p.method_5477().getString() : uuid.toString();
    }

    private static class_2561 onOff(boolean on) {
        return class_2561.method_43470(on ? "ON" : "OFF").method_27692(on ? class_124.field_1060 : class_124.field_1061);
    }
}
