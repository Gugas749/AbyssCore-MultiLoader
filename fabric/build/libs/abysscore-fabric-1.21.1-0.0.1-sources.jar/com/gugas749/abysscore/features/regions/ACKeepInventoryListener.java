package com.gugas749.abysscore.features.regions;

import com.gugas749.abysscore.Constants;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1309;
import net.minecraft.class_1928;
import net.minecraft.class_2499;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * "keep_inventory" region tag: players who die inside one of these regions keep
 * their inventory and XP, regardless of the world's keepInventory gamerule.
 *
 * How it works (three events, in the order Minecraft fires them):
 *  1. onDeath — save inventory to NBT and clear it (nothing left to drop).
 *  2. onExperienceDrop — return true to cancel XP orb drops.
 *  3. onClone — restore saved inventory and XP to the newly-created player object.
 *
 * Event wiring (NeoForge, LOWEST priority) lives in NeoForgeEventListeners.
 */
public class ACKeepInventoryListener {

    private static final Map<UUID, class_2499> PENDING = new HashMap<>();

    /**
     * Called when a player dies. Should run at LOWEST priority so other mods
     * that cancel death (e.g. PlayerRevive) run first.
     */
    public void onDeath(class_3222 player) {
        if (!(player.method_37908() instanceof class_3218 level)) return;

        if (level.method_8450().method_8355(class_1928.field_19389)) return;

        String dimension = level.method_27983().method_29177().toString();
        if (!ACRegionSavedData.get(level).isRestrictedAt(
                dimension, player.method_24515(), ACBlockProtectionListener.KEEP_INVENTORY_TAG)) return;

        PENDING.put(player.method_5667(), player.method_31548().method_7384(new class_2499()));
        player.method_31548().method_5448();

        Constants.LOG.debug("[AbyssCore] {} died in a keep_inventory region — inventory kept.",
                player.method_5477().getString());
    }

    /** Returns true if XP drop should be cancelled. */
    public boolean onExperienceDrop(class_1309 entity) {
        return entity instanceof class_3222 player && PENDING.containsKey(player.method_5667());
    }

    /** Called on player clone (respawn). wasDeath must be true, else skip. */
    public void onClone(class_3222 newPlayer, class_3222 original, boolean wasDeath) {
        if (!wasDeath) return;

        class_2499 saved = PENDING.remove(newPlayer.method_5667());
        if (saved == null) return;

        newPlayer.method_31548().method_7397(saved);

        newPlayer.method_14252(original.field_7520);
        newPlayer.field_7510 = original.field_7510;
        newPlayer.field_7495    = original.field_7495;
    }
}
