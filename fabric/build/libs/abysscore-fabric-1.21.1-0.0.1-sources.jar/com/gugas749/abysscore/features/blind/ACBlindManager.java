package com.gugas749.abysscore.features.blind;

import com.gugas749.abysscore.network.AbyssNetwork;
import com.gugas749.abysscore.network.blind.BlindSyncPacket;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_3222;

public class ACBlindManager {

    private static final Set<UUID> blindedPlayers = new HashSet<>();

    public static void blind(class_3222 player) {
        blindedPlayers.add(player.method_5667());
        AbyssNetwork.sendToPlayer(player, new BlindSyncPacket(true));
    }

    public static void unblind(class_3222 player) {
        blindedPlayers.remove(player.method_5667());
        AbyssNetwork.sendToPlayer(player, new BlindSyncPacket(false));
    }

    public static boolean isBlinded(UUID uuid) {
        return blindedPlayers.contains(uuid);
    }

    /** Called on player join — re-syncs their blind state. */
    public static void onPlayerJoin(class_3222 player) {
        AbyssNetwork.sendToPlayer(player,
            new BlindSyncPacket(blindedPlayers.contains(player.method_5667())));
    }

    /** Called on player leave — keep state so it persists on reconnect. */
    // We intentionally do NOT remove on leave so the blind persists.

    public static Set<UUID> getBlindedPlayers() {
        return Collections.unmodifiableSet(blindedPlayers);
    }
}
