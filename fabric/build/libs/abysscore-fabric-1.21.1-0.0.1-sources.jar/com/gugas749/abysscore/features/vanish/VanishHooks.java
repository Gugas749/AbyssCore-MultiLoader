package com.gugas749.abysscore.features.vanish;

import com.mojang.authlib.GameProfile;
import javax.annotation.Nullable;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2596;
import net.minecraft.class_2703;
import net.minecraft.class_2926;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_5321;
import java.util.ArrayList;
import java.util.List;

/**
 * The logic behind the vanish mixins. Each mixin is one line that calls a method here, so
 * all decisions stay readable in one place (same idea as "loader listeners only forward").
 */
public final class VanishHooks {

    private VanishHooks() {}

    //-----------------------------------------------------------------------------------
    //                         TAB LIST (outgoing packet filter)
    //-----------------------------------------------------------------------------------

    /**
     * Called for EVERY packet sent to {@code receiver}.
     * Returns the same packet (send it), a new packet (send that instead) or null (send nothing).
     *
     * Only player-info packets are touched: they put players in the tab list and are sent
     * on join, every 30s (ping), on game mode / display name changes...
     */
    @Nullable
    public static class_2596<?> filterOutgoing(class_3222 receiver, class_2596<?> packet) {
        if (VanishManager.nobodyVanished()) return packet;
        if (!(packet instanceof class_2703 info)) return packet;

        class_3324 playerList = receiver.method_5682().method_3760();
        List<class_3222> keep = new ArrayList<>();
        boolean removedSomeone = false;

        for (class_2703.class_2705 entry : info.method_46329()) {
            class_3222 player = playerList.method_14602(entry.comp_1106());
            if (player == null) continue;   // not online anymore, nothing to show
            if (VanishManager.canSee(receiver, player)) keep.add(player);
            else removedSomeone = true;
        }

        if (!removedSomeone) return packet;
        if (keep.isEmpty()) return null;
        // The entries' fields are private, so rebuild the packet from the players that stay.
        // Same tick, same players → the same data vanilla would have sent.
        return new class_2703(info.method_46327(), keep);
    }

    //-----------------------------------------------------------------------------------
    //                        SOUNDS & BLOCK EFFECTS (SILENT_SOUNDS)
    //-----------------------------------------------------------------------------------

    /**
     * PlayerList.broadcast(except, x, y, z, radius, dimension, packet) sends sounds and
     * level events (block break particles...) caused by {@code except} to everyone near.
     * If {@code except} is a vanished player, we send it only to who can see them.
     * True = we handled it, cancel vanilla.
     */
    public static boolean broadcastNear(class_3324 list, @Nullable class_1657 except, double x, double y, double z,
                                        double radius, class_5321<class_1937> dimension, class_2596<?> packet) {
        if (!VanishManager.isActive(except, VanishOption.SILENT_SOUNDS)) return false;

        for (class_3222 player : list.method_14571()) {
            if (player == except || player.method_37908().method_27983() != dimension) continue;
            double dx = x - player.method_23317();
            double dy = y - player.method_23318();
            double dz = z - player.method_23321();
            if (dx * dx + dy * dy + dz * dz < radius * radius && VanishManager.canSee(player, except)) {
                player.field_13987.method_14364(packet);
            }
        }
        return true;
    }

    //-----------------------------------------------------------------------------------
    //                               SERVER LIST (ping)
    //-----------------------------------------------------------------------------------

    /** Removes online vanished players from the player count and the hover list. Null = unchanged. */
    @Nullable
    public static class_2926.class_2927 filterStatus(class_3324 list, class_2926.class_2927 players) {
        if (VanishManager.nobodyVanished()) return null;

        int hiddenOnline = 0;
        for (class_3222 player : list.method_14571()) {
            if (VanishManager.isVanished(player)) hiddenOnline++;
        }
        if (hiddenOnline == 0) return null;

        List<GameProfile> sample = new ArrayList<>();
        for (GameProfile profile : players.comp_1281()) {
            if (!VanishManager.isVanished(profile.getId())) sample.add(profile);
        }
        return new class_2926.class_2927(players.comp_1279(), Math.max(0, players.comp_1280() - hiddenOnline), sample);
    }

    //-----------------------------------------------------------------------------------
    //                          COMMAND SELECTORS (@a, names)
    //-----------------------------------------------------------------------------------

    /**
     * When a PLAYER runs a command, vanished players they can't see are left out of the
     * selector result, so "/msg Name hi" or "/tp @a" doesn't give the vanished player away.
     * Console, command blocks and staff are not affected. Null = unchanged.
     */
    @Nullable
    public static <T extends class_1297> List<T> filterSelected(class_2168 source, List<T> found) {
        if (VanishManager.nobodyVanished() || found.isEmpty()) return null;
        if (!(source.method_9228() instanceof class_3222 viewer)) return null;

        List<T> visible = new ArrayList<>(found.size());
        for (T entity : found) {
            if (VanishManager.canSee(viewer, entity)) visible.add(entity);
        }
        return visible.size() == found.size() ? null : visible;
    }

    //-----------------------------------------------------------------------------------
    //                         CONTAINERS (SILENT_CONTAINERS)
    //-----------------------------------------------------------------------------------

    public static boolean isSilentOpener(class_1657 player) {
        return VanishManager.isActive(player, VanishOption.SILENT_CONTAINERS);
    }

    /** The chest's "who has me open" re-check (every 5 ticks) must not count silent openers. */
    public static List<class_1657> withoutSilentOpeners(List<class_1657> openers) {
        if (VanishManager.nobodyVanished()) return openers;
        List<class_1657> result = new ArrayList<>(openers);
        result.removeIf(VanishHooks::isSilentOpener);
        return result;
    }
}
