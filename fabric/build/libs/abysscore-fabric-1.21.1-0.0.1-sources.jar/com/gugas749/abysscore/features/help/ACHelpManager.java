package com.gugas749.abysscore.features.help;

import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ACHelpManager {

    // playerUUID → active request
    private static final Map<UUID, ACHelpRequest> activeRequests = new LinkedHashMap<>();

    // ── Submit ────────────────────────────────────────────────────────────────

    public static boolean submit(class_3222 player, String reason, MinecraftServer server) {
        if (activeRequests.containsKey(player.method_5667())) return false;

        ACHelpRequest request = new ACHelpRequest(
            player.method_5667(),
            player.method_5477().getString(),
            reason
        );
        activeRequests.put(player.method_5667(), request);

        notifyStaff(request, server);
        return true;
    }

    public static boolean cancel(class_3222 player) {
        return activeRequests.remove(player.method_5667()) != null;
    }

    public static Optional<ACHelpRequest> getRequest(UUID playerUUID) {
        return Optional.ofNullable(activeRequests.get(playerUUID));
    }

    public static Collection<ACHelpRequest> getAll() {
        return Collections.unmodifiableCollection(activeRequests.values());
    }

    public static boolean hasActiveRequest(UUID playerUUID) {
        return activeRequests.containsKey(playerUUID);
    }

    // ── Accept ────────────────────────────────────────────────────────────────

    public static boolean accept(class_3222 staff, UUID targetUUID) {
        ACHelpRequest request = activeRequests.get(targetUUID);
        if (request == null) return false;

        class_3222 target = staff.method_5682().method_3760().method_14602(targetUUID);
        if (target == null) {
            activeRequests.remove(targetUUID);
            return false;
        }

        staff.method_14251(
                target.method_51469(),
                target.method_23317(),
                target.method_23318(),
                target.method_23321(),
                staff.method_36454(),
                staff.method_36455()
        );

        target.method_43496(
                class_2561.method_43469("message.abysscore.help.accepted", staff.method_5477().getString())
        );

        staff.method_43496(
                class_2561.method_43469("message.abysscore.help.staff_accepted", request.playerName)
        );

        class_2561 broadcastMsg = class_2561.method_43469(
                "message.abysscore.help.staff_broadcast",
                staff.method_5477().getString(),
                request.playerName
        ).method_27692(class_124.field_1080);

        for (class_3222 other : staff.method_5682().method_3760().method_14571()) {
            if (other.method_5667().equals(staff.method_5667())) continue;
            if (!other.method_5687(2)) continue;
            other.method_43496(broadcastMsg);
        }

        activeRequests.remove(targetUUID);
        return true;
    }

    // ── Staff notification ────────────────────────────────────────────────────

    private static void notifyStaff(ACHelpRequest request, MinecraftServer server) {
        List<class_3222> staffOnline = server.method_3760().method_14571().stream()
            .filter(p -> p.method_5687(2))
            .toList();

        if (staffOnline.isEmpty()) return;

        // Build the notification message with clickable [TP] button
        class_5250 message = class_2561.method_43469(
            "message.abysscore.help.notification",
            request.playerName,
            request.reason
        );

        // [TP] button — clicking runs /abysscore helpaccept <playerName>
        class_5250 tpButton = class_2561.method_43471("message.abysscore.help.tp_button")
            .method_27696(class_2583.field_24360
                .method_10977(class_124.field_1060)
                .method_10982(true)
                .method_10958(new class_2558(
                    class_2558.class_2559.field_11750,
                    "/abysscore helpaccept " + request.playerName
                ))
                .method_10949(new net.minecraft.class_2568(
                    net.minecraft.class_2568.class_5247.field_24342,
                    class_2561.method_43469("message.abysscore.help.tp_hover", request.playerName)
                ))
            );

        class_5250 full = message.method_27693(" ").method_10852(tpButton);

        for (class_3222 staff : staffOnline) {
            staff.method_43496(full);
        }
    }
}
