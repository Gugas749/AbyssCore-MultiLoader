package com.gugas749.abysscore.features.regions;

import com.gugas749.abysscore.Constants;
import net.minecraft.class_1311;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/**
 * Logic for all region protection tags (no_build, no_interact, no_fly, etc.).
 *
 * All methods here take plain vanilla types and return boolean for cancellable checks.
 * The NeoForge loader wires these to events in NeoForgeEventListeners.
 */
public class ACBlockProtectionListener {

    // ── Tag constants ─────────────────────────────────────────────────────────
    public static final String NO_BUILD_TAG = "no_build";
    public static final String NO_INTERACT_TAG = "no_interact";
    public static final String NO_FLY_TAG = "no_fly";
    public static final String NO_FRIENDLYFIRE_TAG = "no_friendlyfire";
    public static final String NO_HUNGER_TAG = "no_hunger";
    public static final String NO_TP_TAG = "no_tp";
    public static final String NO_MOBSPAWNING_HOSTILE_TAG  = "no_mobspawning_hostile";
    public static final String NO_MOBSPAWNING_PACIFIC_TAG  = "no_mobspawning_pacific";
    public static final String NO_ENTRY_TAG = "no_entry";
    /** Not a restriction but a perk: deaths here keep inventory + XP (see ACKeepInventoryListener). */
    public static final String KEEP_INVENTORY_TAG = "keep_inventory";

    // ── Waystones registry names ──────────────────────────────────────────────
    private static final java.util.Set<String> WAYSTONE_BLOCK_IDS = java.util.Set.of(
            "waystones:waystone",
            "waystones:sharestone",
            "waystones:portstone",
            "waystones:warp_plate"
    );

    private static final java.util.Set<String> WAYSTONE_ITEM_IDS = java.util.Set.of(
            "waystones:warp_stone",
            "waystones:warp_scroll",
            "waystones:return_scroll",
            "waystones:bound_scroll",
            "waystones:attuned_shard"
    );

    // ── no_build ──────────────────────────────────────────────────────────────

    /** Returns true if the block change should be cancelled. */
    public boolean checkBlockChange(class_3222 player, class_3218 level, class_2338 pos) {
        if (isExempt(player)) return false;
        if (isRestrictedAt(level, pos, NO_BUILD_TAG)) {
            notify(player, "message.abysscore.no_build_blocked");
            Constants.LOG.debug("[AbyssCore] Blocked block change by {} at {}", player.method_5477().getString(), pos);
            return true;
        }
        return false;
    }

    // ── no_interact ───────────────────────────────────────────────────────────

    /** Returns true if the right-click block should be cancelled. */
    public boolean checkRightClickBlock(class_3222 player, class_3218 level, class_2338 pos) {
        if (isExempt(player)) return false;
        if (!isRestrictedAt(level, pos, NO_INTERACT_TAG)) return false;

        String blockId = class_7923.field_41175.method_10221(level.method_8320(pos).method_26204()).toString();
        if (WAYSTONE_BLOCK_IDS.contains(blockId)) return false;

        notify(player, "message.abysscore.no_interact_blocked");
        return true;
    }

    /** Returns true if the entity interaction should be cancelled. */
    public boolean checkEntityInteract(class_3222 player) {
        if (isExempt(player)) return false;
        if (!(player.method_37908() instanceof class_3218 level)) return false;
        class_2338 pos = player.method_24515();
        if (isRestrictedAt(level, pos, NO_INTERACT_TAG)) {
            notify(player, "message.abysscore.no_interact_blocked");
            return true;
        }
        return false;
    }

    // ── no_fly + no_hunger ────────────────────────────────────────────────────

    /** Called every server-side player tick by NeoForgeEventListeners. */
    public void onPlayerTick(class_3222 player) {
        if (isExempt(player)) return;
        if (!(player.method_37908() instanceof class_3218 level)) return;

        class_2338 pos = player.method_24515();
        String dimension = level.method_27983().method_29177().toString();

        if (isRestrictedAt(level, pos, NO_FLY_TAG)) {
            if (player.method_31549().field_7479) {
                player.method_31549().field_7479 = false;
                player.method_7355();
                notify(player, "message.abysscore.no_fly_blocked");
            }
            if (player.method_31549().field_7478 && !player.method_7337() && !player.method_7325()) {
                player.method_31549().field_7478 = false;
                player.method_7355();
            }
        }

        if (isRestrictedAt(level, pos, NO_HUNGER_TAG)) {
            player.method_7344().method_7580(20);
            player.method_7344().method_7581(5.0f);
        }
    }

    // ── no_friendlyfire ───────────────────────────────────────────────────────

    /** Returns true if the player-vs-player attack should be cancelled. */
    public boolean checkAttackPlayer(class_3222 attacker) {
        if (isExempt(attacker)) return false;
        if (!(attacker.method_37908() instanceof class_3218 level)) return false;
        class_2338 pos = attacker.method_24515();
        if (isRestrictedAt(level, pos, NO_FRIENDLYFIRE_TAG)) {
            notify(attacker, "message.abysscore.no_friendlyfire_blocked");
            return true;
        }
        return false;
    }

    // ── no_tp ─────────────────────────────────────────────────────────────────

    /** Returns true if the teleport should be cancelled (ender pearl, chorus fruit, others). */
    public boolean checkTeleport(class_3222 player) {
        if (isExempt(player)) return false;
        if (!(player.method_37908() instanceof class_3218 level)) return false;
        class_2338 pos = player.method_24515();
        if (isRestrictedAt(level, pos, NO_TP_TAG)) {
            notify(player, "message.abysscore.no_tp_blocked");
            return true;
        }
        return false;
    }

    /** Returns true if the waystone item use should be cancelled. */
    public boolean checkRightClickItem(class_3222 player, class_1799 stack) {
        if (isExempt(player)) return false;
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        if (!WAYSTONE_ITEM_IDS.contains(itemId)) return false;
        if (!(player.method_37908() instanceof class_3218 level)) return false;
        class_2338 pos = player.method_24515();
        if (isRestrictedAt(level, pos, NO_TP_TAG)) {
            notify(player, "message.abysscore.no_tp_blocked");
            return true;
        }
        return false;
    }

    // ── no_mobspawning ────────────────────────────────────────────────────────

    /** Returns true if the mob spawn should be cancelled. */
    public boolean checkMobSpawn(class_3218 level, class_2338 pos, class_1311 category) {
        String dimension = level.method_27983().method_29177().toString();
        if (category == class_1311.field_6302) {
            if (ACRegionSavedData.get(level).isRestrictedAt(dimension, pos, NO_MOBSPAWNING_HOSTILE_TAG)) {
                return true;
            }
        }
        if (category != class_1311.field_6302 && category != class_1311.field_17715) {
            if (ACRegionSavedData.get(level).isRestrictedAt(dimension, pos, NO_MOBSPAWNING_PACIFIC_TAG)) {
                return true;
            }
        }
        return false;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private boolean isExempt(class_3222 player) {
        return player.method_5687(2);
    }

    private boolean isRestrictedAt(class_3218 level, class_2338 pos, String tag) {
        String dimension = level.method_27983().method_29177().toString();
        return ACRegionSavedData.get(level).isRestrictedAt(dimension, pos, tag);
    }

    private void notify(class_1657 player, String translationKey) {
        player.method_43496(class_2561.method_43471(translationKey));
    }
}
