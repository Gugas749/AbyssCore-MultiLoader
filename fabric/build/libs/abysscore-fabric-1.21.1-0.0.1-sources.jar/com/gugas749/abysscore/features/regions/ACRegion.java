package com.gugas749.abysscore.features.regions;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public record ACRegion(
        String name,
        String dimension,
        int minX, int minY, int minZ,
        int maxX, int maxY, int maxZ,
        Set<String> tags,
        String entryFilterTag
) {

    public ACRegion {
        tags = new LinkedHashSet<>(tags);
        if (entryFilterTag == null) entryFilterTag = "";
    }

    // ── Constructors ──────────────────────────────────────────────────────────

    public static ACRegion fromCorners(String name, String dimension, class_2338 first, class_2338 second) {
        return new ACRegion(
                name, dimension,
                Math.min(first.method_10263(), second.method_10263()),
                Math.min(first.method_10264(), second.method_10264()),
                Math.min(first.method_10260(), second.method_10260()),
                Math.max(first.method_10263(), second.method_10263()),
                Math.max(first.method_10264(), second.method_10264()),
                Math.max(first.method_10260(), second.method_10260()),
                new LinkedHashSet<>(),
                ""
        );
    }

    // ── NBT ───────────────────────────────────────────────────────────────────

    public static ACRegion load(class_2487 tag) {
        Set<String> tags = new LinkedHashSet<>();
        class_2499 tagList = tag.method_10554("tags", class_2520.field_33258);
        for (int i = 0; i < tagList.size(); i++) tags.add(tagList.method_10608(i));

        return new ACRegion(
                tag.method_10558("name"),
                tag.method_10558("dimension"),
                tag.method_10550("minX"), tag.method_10550("minY"), tag.method_10550("minZ"),
                tag.method_10550("maxX"), tag.method_10550("maxY"), tag.method_10550("maxZ"),
                tags,
                tag.method_10545("entryFilterTag") ? tag.method_10558("entryFilterTag") : ""
        );
    }

    public class_2487 save() {
        class_2487 tag = new class_2487();
        tag.method_10582("name", name);
        tag.method_10582("dimension", dimension);
        tag.method_10569("minX", minX); tag.method_10569("minY", minY); tag.method_10569("minZ", minZ);
        tag.method_10569("maxX", maxX); tag.method_10569("maxY", maxY); tag.method_10569("maxZ", maxZ);

        class_2499 tagList = new class_2499();
        for (String t : tags) tagList.add(class_2519.method_23256(t));
        tag.method_10566("tags", tagList);

        if (entryFilterTag != null && !entryFilterTag.isBlank()) {
            tag.method_10582("entryFilterTag", entryFilterTag);
        }
        return tag;
    }

    // ── Queries ───────────────────────────────────────────────────────────────

    public boolean contains(String dimension, class_2338 pos) {
        return this.dimension.equals(dimension)
                && pos.method_10263() >= minX && pos.method_10263() <= maxX
                && pos.method_10264() >= minY && pos.method_10264() <= maxY
                && pos.method_10260() >= minZ && pos.method_10260() <= maxZ;
    }

    public boolean hasTag(String tag) { return tags.contains(tag); }

    public Set<String> tags() { return Collections.unmodifiableSet(tags); }

    public ACRegion withTag(String tag) {
        Set<String> n = new LinkedHashSet<>(tags); n.add(tag);
        return new ACRegion(name, dimension, minX, minY, minZ, maxX, maxY, maxZ, n, entryFilterTag);
    }

    public ACRegion withoutTag(String tag) {
        Set<String> n = new LinkedHashSet<>(tags); n.remove(tag);
        return new ACRegion(name, dimension, minX, minY, minZ, maxX, maxY, maxZ, n, entryFilterTag);
    }

    public ACRegion withEntryFilterTag(String filterTag) {
        return new ACRegion(name, dimension, minX, minY, minZ, maxX, maxY, maxZ, tags, filterTag);
    }
}
