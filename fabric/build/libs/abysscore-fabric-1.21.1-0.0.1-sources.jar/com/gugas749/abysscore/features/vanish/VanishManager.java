package com.gugas749.abysscore.features.vanish;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.gugas749.abysscore.AbysscoreServerConfig;
import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.network.AbyssNetwork;
import com.gugas749.abysscore.network.vanish.VanishStateSyncPacket;
import com.gugas749.abysscore.platform.Services;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_2703;
import net.minecraft.class_3222;
import net.minecraft.class_7828;
import net.minecraft.server.MinecraftServer;
import javax.annotation.Nullable;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * AbyssCore's own vanish. Holds who is vanished, each player's options, and the ONE rule
 * that decides who can see whom: {@link #canSee}.
 *
 * How hiding works (every piece asks canSee):
 *   - body        → ServerPlayerVanishMixin: vanilla asks broadcastToPlayer() before it sends
 *                   an entity to a client; we answer false.
 *   - tab list    → ServerCommonPacketListenerVanishMixin: player-info packets are filtered
 *                   per receiver.
 *   - messages    → VanishMessages + mixins (join/leave/death/advancement).
 *   - the rest    → small mixins, each behind a VanishOption (pickup, mobs, sounds, ...).
 *
 * Saved in config/abysscore/abysscore_vanish.json so vanish survives relogs and restarts.
 * Everything here runs on the server thread.
 */
public final class VanishManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path SAVE_PATH =
            Services.PLATFORM.getConfigDir().resolve("abysscore/abysscore_vanish.json");

    /*
     * Concurrent collections because Simple Voice Chat calls canSee() from ITS OWN thread
     * (VanishVoiceChatPlugin) while the server thread may be changing these. A plain
     * HashSet read during a write can throw or give garbage; these can't.
     */

    /** Players who are vanished (online or not). */
    private static final Set<UUID> vanished = ConcurrentHashMap.newKeySet();

    /** Each player's options. Missing player or missing option = the option's default. */
    private static final Map<UUID, EnumSet<VanishOption>> options = new ConcurrentHashMap<>();

    /**
     * For each online vanished player: which viewers we last told "you can see them".
     * The tick check compares this with canSee() so a change (op/deop, team change,
     * new player) is applied within a second, without spamming packets every tick.
     */
    private static final Map<UUID, Set<UUID>> lastVisibleTo = new HashMap<>();

    private VanishManager() {}

    //-----------------------------------------------------------------------------------
    //                                    QUERIES
    //-----------------------------------------------------------------------------------

    public static boolean isVanished(UUID uuid) {
        return vanished.contains(uuid);
    }

    /** True only for a SERVER player that is vanished (client entities are never "vanished"). */
    public static boolean isVanished(@Nullable class_1297 entity) {
        return entity instanceof class_3222 && vanished.contains(entity.method_5667());
    }

    /** True if nobody is vanished. Mixins check this first so they cost nothing normally. */
    public static boolean nobodyVanished() {
        return vanished.isEmpty();
    }

    public static Set<UUID> getVanished() {
        return Collections.unmodifiableSet(vanished);
    }

    /** The option's value for this player, vanished or not. */
    public static boolean getOption(UUID uuid, VanishOption option) {
        EnumSet<VanishOption> set = options.get(uuid);
        return set == null ? option.defaultValue : set.contains(option);
    }

    /** All options of a player packed into an int (one bit each) for the GUI packet. */
    public static int getOptionBits(UUID uuid) {
        int bits = 0;
        for (VanishOption option : VanishOption.values()) {
            if (getOption(uuid, option)) bits |= option.bit();
        }
        return bits;
    }

    /**
     * The check most mixins use: is this entity a vanished player WITH this option on?
     * e.g. isActive(this, VanishOption.NO_PICKUP) in the item pickup mixin.
     */
    public static boolean isActive(@Nullable class_1297 entity, VanishOption option) {
        return isVanished(entity) && getOption(entity.method_5667(), option);
    }

    /**
     * THE visibility rule. Can {@code viewer} see {@code target}?
     *
     * In order:
     *   1. target not vanished          → yes
     *   2. viewer is the target         → yes (you always see yourself)
     *   3. per-player exception         → whatever /abysscore vanish show|hide said
     *   4. viewer has the "see" level   → yes (config: vanish_see_level, default ADMIN)
     *   5. team visibility ON + same team → yes
     *   6. otherwise                    → no
     */
    public static boolean canSee(@Nullable class_1297 viewer, class_1297 target) {
        if (!isVanished(target)) return true;
        if (!(viewer instanceof class_3222 viewerPlayer)) return true;   // console, command blocks...
        if (viewer == target) return true;

        Boolean exception = ACVanishExtras.checkException(target.method_5667(), viewer.method_5667());
        if (exception != null) return exception;

        if (AbyssPermissionHandler.has(viewerPlayer, AbysscoreServerConfig.getVanishSeeLevel())) return true;

        return ACVanishExtras.isTeamVisibilityEnabled()
                && target.method_5781() != null
                && target.method_5781() == viewer.method_5781();
    }

    /** Online players that can NOT see target. */
    public static List<class_3222> hiddenFrom(class_3222 target) {
        List<class_3222> list = new ArrayList<>();
        for (class_3222 viewer : target.method_5682().method_3760().method_14571()) {
            if (!canSee(viewer, target)) list.add(viewer);
        }
        return list;
    }

    //-----------------------------------------------------------------------------------
    //                                    CHANGES
    //-----------------------------------------------------------------------------------

    public static boolean toggle(class_3222 player) {
        setVanished(player, !isVanished(player.method_5667()));
        return isVanished(player.method_5667());
    }

    public static void setVanished(class_3222 player, boolean vanish) {
        UUID uuid = player.method_5667();
        if (vanish == vanished.contains(uuid)) return;

        if (vanish) {
            vanished.add(uuid);
            // AFTER adding, so hiddenFrom() returns the players who just lost sight of them
            if (getOption(uuid, VanishOption.FAKE_MESSAGES)) {
                sendFake(player, "multiplayer.player.left", hiddenFrom(player));
            }
        } else {
            // BEFORE removing, for the same reason the other way around
            List<class_3222> couldNotSee = hiddenFrom(player);
            vanished.remove(uuid);
            lastVisibleTo.remove(uuid);
            if (getOption(uuid, VanishOption.FAKE_MESSAGES)) {
                sendFake(player, "multiplayer.player.joined", couldNotSee);
            }
        }
        save();

        refresh(player);
        applyNightVision(player);
        syncClient(player);

        if (getOption(uuid, VanishOption.CHAT_NOTICE)) {
            player.method_43496(class_2561.method_43471(
                    vanish ? "message.abysscore.vanish.now_vanished" : "message.abysscore.vanish.now_visible"));
        }
        Constants.LOG.info("[AbyssCore] {} is now {}.", player.method_5477().getString(), vanish ? "vanished" : "visible");
    }

    public static void setOption(class_3222 player, VanishOption option, boolean value) {
        EnumSet<VanishOption> set = options.computeIfAbsent(player.method_5667(), uuid -> defaults());
        if (value) set.add(option);
        else set.remove(option);
        save();

        // Options whose effect has to be applied right away
        switch (option) {
            case HUD_WARNING -> syncClient(player);
            case NIGHT_VISION -> applyNightVision(player);
            default -> { }
        }
    }

    private static EnumSet<VanishOption> defaults() {
        EnumSet<VanishOption> set = EnumSet.noneOf(VanishOption.class);
        for (VanishOption option : VanishOption.values()) {
            if (option.defaultValue) set.add(option);
        }
        return set;
    }

    //-----------------------------------------------------------------------------------
    //                                    REFRESH
    //-----------------------------------------------------------------------------------

    /**
     * Makes every client match canSee() for {@code target} RIGHT NOW. Call after anything
     * that changes visibility (toggle, show/hide exception, team visibility).
     *
     * Order matters: a client can only spawn a player entity it has in its tab list
     * (player info). So: 1) add info for whoever can see, 2) re-run entity tracking,
     * 3) remove info for whoever can't (after the entity is already gone).
     */
    public static void refresh(class_3222 target) {
        MinecraftServer server = target.method_5682();
        if (server == null) return;

        List<class_3222> canSeeList = new ArrayList<>();
        List<class_3222> cannotSeeList = new ArrayList<>();
        for (class_3222 viewer : server.method_3760().method_14571()) {
            if (viewer == target) continue;
            (canSee(viewer, target) ? canSeeList : cannotSeeList).add(viewer);
        }

        // 1. tab list entry for the ones who can see (a client ignores a duplicate add)
        if (!canSeeList.isEmpty()) {
            var addInfo = class_2703.method_43886(List.of(target));
            for (class_3222 viewer : canSeeList) viewer.field_13987.method_14364(addInfo);
        }

        // 2. entity tracking: ChunkMap.move() re-asks broadcastToPlayer() for every player
        //    (our mixin answers it) and spawns / despawns the body to match.
        target.method_51469().method_14178().method_14096(target);

        // 3. tab list entry gone for the ones who can't see
        if (!cannotSeeList.isEmpty()) {
            var removeInfo = new class_7828(List.of(target.method_5667()));
            for (class_3222 viewer : cannotSeeList) viewer.field_13987.method_14364(removeInfo);
        }

        if (isVanished(target)) {
            Set<UUID> seen = new HashSet<>();
            for (class_3222 viewer : canSeeList) seen.add(viewer.method_5667());
            lastVisibleTo.put(target.method_5667(), seen);
        }
    }

    /** refresh() for every online vanished player (team visibility toggled, config reload...). */
    public static void refreshAll(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            if (isVanished(player)) refresh(player);
        }
    }

    /** Tells the player's client whether to draw the HUD warning. */
    public static void syncClient(class_3222 player) {
        boolean isVanished = isVanished(player);
        AbyssNetwork.sendToPlayer(player, new VanishStateSyncPacket(
                isVanished, isVanished && getOption(player.method_5667(), VanishOption.HUD_WARNING)));
    }

    private static void applyNightVision(class_3222 player) {
        boolean want = isActive(player, VanishOption.NIGHT_VISION);
        class_1293 current = player.method_6112(class_1294.field_5925);
        // "Ours" = infinite + no particles. We never remove a night vision potion the player drank.
        boolean ours = current != null && current.method_48559() && !current.method_5581();

        if (want && current == null) {
            player.method_6092(new class_1293(class_1294.field_5925,
                    class_1293.field_42106, 0, false, false));
        } else if (!want && ours) {
            player.method_6016(class_1294.field_5925);
        }
    }

    private static void sendFake(class_3222 player, String langKey, List<class_3222> receivers) {
        class_2561 message = class_2561.method_43469(langKey, player.method_5476()).method_27692(class_124.field_1054);
        for (class_3222 receiver : receivers) receiver.method_43496(message);
    }

    //-----------------------------------------------------------------------------------
    //                        EVENTS (called from ACVanishStateListener)
    //-----------------------------------------------------------------------------------

    static void onJoin(class_3222 player) {
        syncClient(player);
        if (!isVanished(player)) return;

        // The tab list / body of the joiner are already hidden by the packet filter and
        // broadcastToPlayer, because the vanished set was loaded at server start.
        applyNightVision(player);
        if (getOption(player.method_5667(), VanishOption.CHAT_NOTICE)) {
            player.method_43496(class_2561.method_43471("message.abysscore.vanish.still_vanished"));
        }
    }

    static void onLeave(class_3222 player) {
        lastVisibleTo.remove(player.method_5667());
        // A viewer who left may be in someone's lastVisibleTo; the tick check fixes that.
    }

    /** Once per second per vanished player: re-apply night vision, fix visibility drift. */
    static void onTick(class_3222 player) {
        if (player.field_6012 % 20 != 0 || !isVanished(player)) return;

        applyNightVision(player);   // death / milk / another mod removed it

        Set<UUID> now = new HashSet<>();
        for (class_3222 viewer : player.method_5682().method_3760().method_14571()) {
            if (viewer != player && canSee(viewer, player)) now.add(viewer.method_5667());
        }
        if (!now.equals(lastVisibleTo.get(player.method_5667()))) {
            refresh(player);
        }
    }

    /** Returns true if the chat message must be cancelled. */
    static boolean onChat(class_3222 player) {
        if (!isActive(player, VanishOption.BLOCK_CHAT)) return false;
        player.method_43496(class_2561.method_43471("message.abysscore.vanish.chat_blocked"));
        return true;
    }

    //-----------------------------------------------------------------------------------
    //                                  LOAD / SAVE
    //-----------------------------------------------------------------------------------

    /*
     * File format:
     * {
     *   "team_visibility": true,
     *   "vanished": [ "uuid", ... ],
     *   "options": { "uuid": { "hud_warning": true, "night_vision": false, ... } }
     * }
     */

    public static void load() {
        vanished.clear();
        options.clear();
        lastVisibleTo.clear();

        if (!Files.exists(SAVE_PATH)) return;

        try (Reader reader = Files.newBufferedReader(SAVE_PATH)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null) return;

            if (root.has("team_visibility")) {
                ACVanishExtras.setTeamVisibility(root.get("team_visibility").getAsBoolean());
            }
            if (root.has("vanished")) {
                for (JsonElement e : root.getAsJsonArray("vanished")) {
                    vanished.add(UUID.fromString(e.getAsString()));
                }
            }
            if (root.has("options")) {
                for (Map.Entry<String, JsonElement> player : root.getAsJsonObject("options").entrySet()) {
                    EnumSet<VanishOption> set = defaults();
                    for (Map.Entry<String, JsonElement> opt : player.getValue().getAsJsonObject().entrySet()) {
                        VanishOption option = VanishOption.byId(opt.getKey());
                        if (option == null) continue;   // option removed in a newer version
                        if (opt.getValue().getAsBoolean()) set.add(option);
                        else set.remove(option);
                    }
                    options.put(UUID.fromString(player.getKey()), set);
                }
            }
            Constants.LOG.info("[AbyssCore] Vanish loaded: {} vanished player(s).", vanished.size());
        } catch (IOException | RuntimeException e) {
            // RuntimeException: bad JSON or bad UUID — keep the server running
            Constants.LOG.error("[AbyssCore] Failed to load vanish data: {}", e.getMessage());
        }
    }

    public static void save() {
        JsonObject root = new JsonObject();
        root.addProperty("team_visibility", ACVanishExtras.isTeamVisibilityEnabled());

        JsonArray list = new JsonArray();
        vanished.forEach(uuid -> list.add(uuid.toString()));
        root.add("vanished", list);

        JsonObject allOptions = new JsonObject();
        options.forEach((uuid, set) -> {
            JsonObject obj = new JsonObject();
            for (VanishOption option : VanishOption.values()) obj.addProperty(option.id(), set.contains(option));
            allOptions.add(uuid.toString(), obj);
        });
        root.add("options", allOptions);

        try {
            Files.createDirectories(SAVE_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(SAVE_PATH)) {
                GSON.toJson(root, writer);
            }
        } catch (IOException e) {
            Constants.LOG.error("[AbyssCore] Failed to save vanish data: {}", e.getMessage());
        }
    }
}
