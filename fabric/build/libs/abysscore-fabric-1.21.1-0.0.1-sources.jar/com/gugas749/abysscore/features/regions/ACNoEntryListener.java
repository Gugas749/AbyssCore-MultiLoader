package com.gugas749.abysscore.features.regions;

import com.gugas749.abysscore.api.network.AbyssPacketContext;
import com.gugas749.abysscore.network.AbyssNetwork;
import com.gugas749.abysscore.network.region.NoEntryPacket;
import com.gugas749.abysscore.network.region.ReadyToTeleportPacket;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class ACNoEntryListener {

    // Pending teleports: UUID → exit position + yaw, waiting for client ready signal
    private record PendingTeleport(double x, double y, double z, float yaw, class_3218 level) {}
    private static final Map<UUID, PendingTeleport> pendingTeleports = new HashMap<>();

    // Cooldown: recently ejected players won't be re-checked for 3 seconds
    private static final Map<UUID, Long> ejectCooldowns = new HashMap<>();
    private static final long COOLDOWN_MS = 3000;

    // ── Server tick — detect entry ────────────────────────────────────────────

    /** Called on every server-side player tick by NeoForgeEventListeners. */
    public void onPlayerTick(class_3222 player) {
        if (player.method_5687(2)) return;

        if (player.field_6012 % 20 != 0) return;

        // Skip if already waiting for this player's ready signal
        if (pendingTeleports.containsKey(player.method_5667())) return;

        Long lastEject = ejectCooldowns.get(player.method_5667());
        if (lastEject != null && System.currentTimeMillis() - lastEject < COOLDOWN_MS) return;

        if (!(player.method_37908() instanceof class_3218 level)) return;

        class_2338 pos = player.method_24515();
        String dimension = level.method_27983().method_29177().toString();
        ACRegionSavedData data = ACRegionSavedData.get(level);

        for (ACRegion region : data.regions()) {
            if (!region.contains(dimension, pos)) continue;
            if (!region.hasTag(ACBlockProtectionListener.NO_ENTRY_TAG)) continue;

            // Check filter tag — if set, players WITH this tag are allowed in
            String filterTag = region.entryFilterTag();
            if (filterTag != null && !filterTag.isBlank()) {
                if (player.method_5752().contains(filterTag)) {
                    // Player has the whitelist tag — allowed to enter
                    continue;
                }
            }

            // Player should not be here — calculate exit and send blackscreen
            double[] exit = calculateExitPosition(player, region);
            float exitYaw = player.method_36454() + 180.0f;

            // Store the teleport for when client signals ready
            pendingTeleports.put(player.method_5667(),
                new PendingTeleport(exit[0], exit[1], exit[2], exitYaw, level));

            // Send blackscreen packet to client
            AbyssNetwork.sendToPlayer(player,
                new NoEntryPacket(exit[0], exit[1], exit[2], exitYaw));

            ejectCooldowns.put(player.method_5667(), System.currentTimeMillis());
            break;
        }
    }

    // ── C2S: client at peak black — execute teleport now ─────────────────────

    public static void handleReadyToTeleport(ReadyToTeleportPacket packet, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof class_3222 player)) return;

            PendingTeleport pending = pendingTeleports.remove(player.method_5667());
            if (pending == null) return;

            // Teleport now — client is fully black, they won't see the world change
            player.method_14251(
                pending.level(),
                pending.x(), pending.y(), pending.z(),
                pending.yaw(), player.method_36455()
            );
        });
    }

    // ── Exit position calculation ─────────────────────────────────────────────

    private static double[] calculateExitPosition(class_3222 player, ACRegion region) {
        double px = player.method_23317();
        double py = player.method_23318();
        double pz = player.method_23321();

        double dMinX = Math.abs(px - region.minX());
        double dMaxX = Math.abs(px - region.maxX());
        double dMinZ = Math.abs(pz - region.minZ());
        double dMaxZ = Math.abs(pz - region.maxZ());

        double minDist = Math.min(Math.min(dMinX, dMaxX), Math.min(dMinZ, dMaxZ));

        double exitX = px, exitZ = pz;

        if (minDist == dMinX)      exitX = region.minX() - 2;
        else if (minDist == dMaxX) exitX = region.maxX() + 2;
        else if (minDist == dMinZ) exitZ = region.minZ() - 2;
        else                       exitZ = region.maxZ() + 2;

        double exitY = Math.max(py, region.minY() + 1);
        return new double[]{exitX, exitY, exitZ};
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────

    public static void onPlayerLeave(UUID uuid) {
        pendingTeleports.remove(uuid);
        ejectCooldowns.remove(uuid);
    }
}
