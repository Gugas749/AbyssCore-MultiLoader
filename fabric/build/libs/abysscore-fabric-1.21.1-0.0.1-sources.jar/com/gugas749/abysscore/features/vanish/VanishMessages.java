package com.gugas749.abysscore.features.vanish;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3324;

/**
 * Hides "X joined / left / died / made the advancement" messages of vanished players
 * (option SILENT_MESSAGES). Staff who can see them still get the message, with " (vanished)".
 *
 * The problem: vanilla builds these messages in different places, but they all end up in
 * PlayerList.broadcastSystemMessage(...), which doesn't know WHICH player the message is about.
 *
 * The trick, a "subject":
 *   1. Mixins on the methods that send those messages (placeNewPlayer, removePlayerFromWorld,
 *      ServerPlayer.die, PlayerAdvancements.award) call push(player) at HEAD and pop() at RETURN.
 *   2. A mixin at HEAD of broadcastSystemMessage calls handleBroadcast(). If the current subject
 *      is vanished, we send the message only to who can see them and cancel the vanilla broadcast.
 *
 * Why a stack and not one field? These methods can run INSIDE each other (an advancement
 * granted while placeNewPlayer runs). With one field the inner pop() would wipe the outer
 * subject; with a stack the outer one comes back.
 *
 * Minecraft's server logic runs on ONE thread, so no locking is needed.
 * If one of those methods throws, RETURN never runs: ACVanishStateListener.onPlayerTick
 * calls reset() as a safety net.
 */
public final class VanishMessages {

    private static final Deque<class_3222> subjects = new ArrayDeque<>();

    private VanishMessages() {}

    public static void push(class_3222 player) {
        subjects.push(player);
    }

    public static void pop() {
        subjects.poll();   // poll, not pop: no exception if it's already empty
    }

    public static void reset() {
        subjects.clear();
    }

    /** HEAD of PlayerList.broadcastSystemMessage(Component, Function, boolean). True = cancel vanilla. */
    public static boolean handleBroadcast(class_3324 list, class_2561 consoleMessage,
                                          Function<class_3222, class_2561> perPlayer, boolean bypassHiddenChat) {
        class_3222 who = subjects.peek();
        if (!VanishManager.isActive(who, VanishOption.SILENT_MESSAGES)) return false;

        list.method_14561().method_43496(withSuffix(consoleMessage));   // server log, like vanilla
        for (class_3222 viewer : list.method_14571()) {
            if (!VanishManager.canSee(viewer, who)) continue;
            class_2561 message = perPlayer.apply(viewer);
            if (message != null) viewer.method_43502(withSuffix(message), bypassHiddenChat);
        }
        return true;
    }

    /**
     * HEAD of broadcastSystemToTeam / broadcastSystemToAllExceptTeam (death messages when the
     * team's "deathMessageVisibility" rule is set). Here vanilla tells us the player directly.
     */
    public static boolean handleTeamBroadcast(class_3324 list, class_1657 who, class_2561 message, boolean onlyTeam) {
        if (!VanishManager.isActive(who, VanishOption.SILENT_MESSAGES)) return false;

        list.method_14561().method_43496(withSuffix(message));
        for (class_3222 viewer : list.method_14571()) {
            if (viewer == who || !VanishManager.canSee(viewer, who)) continue;
            boolean sameTeam = who.method_5781() != null && viewer.method_5781() == who.method_5781();
            if (sameTeam == onlyTeam) viewer.method_43496(withSuffix(message));
        }
        return true;
    }

    private static class_2561 withSuffix(class_2561 message) {
        return class_2561.method_43473().method_10852(message)
                .method_10852(class_2561.method_43471("message.abysscore.vanish.staff_suffix").method_27692(class_124.field_1080));
    }
}
