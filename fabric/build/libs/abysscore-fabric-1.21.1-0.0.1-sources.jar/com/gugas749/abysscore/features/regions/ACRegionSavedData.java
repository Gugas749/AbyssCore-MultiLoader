package com.gugas749.abysscore.features.regions;

import com.gugas749.abysscore.Constants;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public class ACRegionSavedData extends class_18 {

    private static final String DATA_NAME = Constants.MOD_ID + "_regions";
    private static final class_8645<ACRegionSavedData> FACTORY = new class_8645<>(
            ACRegionSavedData::new,
            ACRegionSavedData::load,
            null
    );

    private final Map<String, ACRegion> regions = new LinkedHashMap<>();

    public static ACRegionSavedData get(class_3218 level) {
        return level.method_17983().method_17924(FACTORY, DATA_NAME);
    }

    private static ACRegionSavedData load(class_2487 tag, class_7225.class_7874 provider) {
        ACRegionSavedData data = new ACRegionSavedData();
        class_2499 regionTags = tag.method_10554("regions", class_2520.field_33260);

        for (int i = 0; i < regionTags.size(); i++) {
            ACRegion region = ACRegion.load(regionTags.method_10602(i));
            data.regions.put(region.name(), region);
        }

        return data;
    }

    @Override
    public class_2487 method_75(class_2487 tag, class_7225.class_7874 provider) {
        class_2499 regionTags = new class_2499();

        for (ACRegion region : regions.values()) {
            regionTags.add(region.save());
        }

        tag.method_10566("regions", regionTags);
        return tag;
    }

    // ── Region CRUD ───────────────────────────────────────────────────────────

    public boolean addRegion(String name, String dimension, class_2338 first, class_2338 second) {
        if (regions.containsKey(name)) return false;
        regions.put(name, ACRegion.fromCorners(name, dimension, first, second));
        method_80();
        return true;
    }

    public boolean removeRegion(String name) {
        if (regions.remove(name) == null) return false;
        method_80();
        return true;
    }

    public Optional<ACRegion> getRegion(String name) {
        return Optional.ofNullable(regions.get(name));
    }

    // ── Tag management ────────────────────────────────────────────────────────

    public boolean addTagToRegion(String regionName, String tag) {
        ACRegion region = regions.get(regionName);
        if (region == null) return false;
        if (region.hasTag(tag)) return false;

        // Records are immutable — replace with a new instance that has the tag
        regions.put(regionName, region.withTag(tag));
        method_80();
        return true;
    }

    public boolean removeTagFromRegion(String regionName, String tag) {
        ACRegion region = regions.get(regionName);
        if (region == null) return false;
        if (!region.hasTag(tag)) return false;

        regions.put(regionName, region.withoutTag(tag));
        method_80();
        return true;
    }

    // ── Protection queries ────────────────────────────────────────────────────

    public boolean isRestrictedAt(String dimension, class_2338 pos, String tag) {
        for (ACRegion region : regions.values()) {
            if (region.contains(dimension, pos) && region.hasTag(tag)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Legacy method — kept for backward compatibility.
     * Returns true if the position is inside ANY region (regardless of tags).
     */
    public boolean isProtected(String dimension, class_2338 pos) {
        for (ACRegion region : regions.values()) {
            if (region.contains(dimension, pos)) return true;
        }
        return false;
    }

    public Collection<ACRegion> regions() {
        return regions.values();
    }

    public boolean setEntryFilterTag(String regionName, String filterTag) {
        ACRegion region = regions.get(regionName);
        if (region == null) return false;
        regions.put(regionName, region.withEntryFilterTag(filterTag != null ? filterTag : ""));
        method_80();
        return true;
    }
}
