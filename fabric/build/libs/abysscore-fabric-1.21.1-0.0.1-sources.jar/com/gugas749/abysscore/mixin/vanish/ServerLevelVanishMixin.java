package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishManager;
import com.gugas749.abysscore.features.vanish.VanishOption;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5712;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * NO_TRIGGERS (part 2). Every "game event" (step, block placed, item used, container opened...)
 * goes through ServerLevel.gameEvent(). Sculk sensors, shriekers, wardens and allays listen to
 * them. Dropping the ones caused by a vanished player makes them all ignore you.
 *
 * 1.20.1 note: the first parameter is GameEvent there, not Holder<GameEvent>.
 */
@Mixin(class_3218.class)
public abstract class ServerLevelVanishMixin {

    @Inject(method = "gameEvent(Lnet/minecraft/core/Holder;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/level/gameevent/GameEvent$Context;)V",
            at = @At("HEAD"), cancellable = true)
    private void abysscore$noVibrations(class_6880<class_5712> event, class_243 pos, class_5712.class_7397 context, CallbackInfo ci) {
        if (VanishManager.isActive(context.comp_713(), VanishOption.NO_TRIGGERS)) {
            ci.cancel();
        }
    }
}
