package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishManager;
import com.gugas749.abysscore.features.vanish.VanishMessages;
import net.minecraft.class_1282;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3222.class)
public abstract class ServerPlayerVanishMixin {

    /**
     * THE core of vanish. Before the server sends an entity to a client (spawn, movement,
     * equipment...), ChunkMap asks entity.broadcastToPlayer(viewer). Answering false means
     * that client never gets the body. VanishManager.refresh() re-runs this check on toggle.
     */
    @Inject(method = "broadcastToPlayer", at = @At("HEAD"), cancellable = true)
    private void abysscore$hideFromViewer(class_3222 viewer, CallbackInfoReturnable<Boolean> cir) {
        if (!VanishManager.canSee(viewer, (class_3222) (Object) this)) {
            cir.setReturnValue(false);
        }
    }

    /** Death message → only staff, see VanishMessages. */
    @Inject(method = "die", at = @At("HEAD"))
    private void abysscore$deathStart(class_1282 source, CallbackInfo ci) {
        VanishMessages.push((class_3222) (Object) this);
    }

    @Inject(method = "die", at = @At("RETURN"))
    private void abysscore$deathEnd(class_1282 source, CallbackInfo ci) {
        VanishMessages.pop();
    }
}
