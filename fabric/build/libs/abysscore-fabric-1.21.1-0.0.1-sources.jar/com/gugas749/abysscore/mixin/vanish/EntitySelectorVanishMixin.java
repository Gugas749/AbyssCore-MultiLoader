package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2300;
import net.minecraft.class_3222;

/**
 * Command targets (@a, @p, @e, player names). findSinglePlayer() calls findPlayers(), so
 * "/msg VanishedGuy hi" answers "No player was found" like they are offline.
 */
@Mixin(class_2300.class)
public abstract class EntitySelectorVanishMixin {

    @Inject(method = "findPlayers", at = @At("RETURN"), cancellable = true)
    private void abysscore$hidePlayers(class_2168 source, CallbackInfoReturnable<List<class_3222>> cir) {
        List<class_3222> filtered = VanishHooks.filterSelected(source, cir.getReturnValue());
        if (filtered != null) cir.setReturnValue(filtered);
    }

    @Inject(method = "findEntities", at = @At("RETURN"), cancellable = true)
    private void abysscore$hideEntities(class_2168 source, CallbackInfoReturnable<List<? extends class_1297>> cir) {
        List<? extends class_1297> filtered = VanishHooks.filterSelected(source, cir.getReturnValue());
        if (filtered != null) cir.setReturnValue(filtered);
    }
}
