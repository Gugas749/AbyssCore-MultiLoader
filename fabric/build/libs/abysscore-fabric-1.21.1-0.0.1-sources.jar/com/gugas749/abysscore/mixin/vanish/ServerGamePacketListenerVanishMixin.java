package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishMessages;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Leave message → only staff, see VanishMessages. removePlayerFromWorld sends "X left the game". */
@Mixin(class_3244.class)
public abstract class ServerGamePacketListenerVanishMixin {

    @Shadow public class_3222 player;

    @Inject(method = "removePlayerFromWorld", at = @At("HEAD"))
    private void abysscore$leaveStart(CallbackInfo ci) {
        VanishMessages.push(this.player);
    }

    @Inject(method = "removePlayerFromWorld", at = @At("RETURN"))
    private void abysscore$leaveEnd(CallbackInfo ci) {
        VanishMessages.pop();
    }
}
