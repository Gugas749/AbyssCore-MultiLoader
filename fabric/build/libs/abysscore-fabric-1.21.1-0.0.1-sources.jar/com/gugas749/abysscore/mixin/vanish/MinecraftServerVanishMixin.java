package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishHooks;
import net.minecraft.class_2926;
import net.minecraft.class_3324;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Server list: vanished players don't count in "5/20" and aren't in the hover list. */
@Mixin(MinecraftServer.class)
public abstract class MinecraftServerVanishMixin {

    @Shadow
    public abstract class_3324 getPlayerList();

    @Inject(method = "buildPlayerStatus", at = @At("RETURN"), cancellable = true)
    private void abysscore$hideFromServerList(CallbackInfoReturnable<class_2926.class_2927> cir) {
        class_2926.class_2927 filtered = VanishHooks.filterStatus(this.getPlayerList(), cir.getReturnValue());
        if (filtered != null) cir.setReturnValue(filtered);
    }
}
