package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishHooks;
import com.gugas749.abysscore.features.vanish.VanishMessages;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import javax.annotation.Nullable;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_5321;
import java.util.function.Function;

@Mixin(class_3324.class)
public abstract class PlayerListVanishMixin {

    // ── Join message: the joining player is the "subject" while placeNewPlayer runs ──
    //
    // placeNewPlayer's parameters differ between versions (1.21.1 has an extra
    // CommonListenerCookie, 1.20.1 doesn't), and an @Inject handler must list ALL of them.
    // So we grab the player with @ModifyVariable instead: argsOnly = true + the type
    // ServerPlayer finds "the ServerPlayer parameter" in both versions. We return it
    // unchanged; we only wanted to see it. The RETURN handler takes only CallbackInfo
    // (allowed when you list no parameters at all).

    @ModifyVariable(method = "placeNewPlayer", at = @At("HEAD"), argsOnly = true)
    private class_3222 abysscore$joinStart(class_3222 player) {
        VanishMessages.push(player);
        return player;
    }

    @Inject(method = "placeNewPlayer", at = @At("RETURN"))
    private void abysscore$joinEnd(CallbackInfo ci) {
        VanishMessages.pop();
    }

    // ── Every system broadcast (join/leave/death/advancement) passes here ──
    // The 2-argument broadcastSystemMessage(Component, boolean) calls this one, so one hook covers both.

    @Inject(method = "broadcastSystemMessage(Lnet/minecraft/network/chat/Component;Ljava/util/function/Function;Z)V",
            at = @At("HEAD"), cancellable = true)
    private void abysscore$silentMessages(class_2561 message, Function<class_3222, class_2561> perPlayer,
                                          boolean bypassHiddenChat, CallbackInfo ci) {
        if (VanishMessages.handleBroadcast((class_3324) (Object) this, message, perPlayer, bypassHiddenChat)) {
            ci.cancel();
        }
    }

    @Inject(method = "broadcastSystemToTeam", at = @At("HEAD"), cancellable = true)
    private void abysscore$silentTeamMessage(class_1657 player, class_2561 message, CallbackInfo ci) {
        if (VanishMessages.handleTeamBroadcast((class_3324) (Object) this, player, message, true)) {
            ci.cancel();
        }
    }

    @Inject(method = "broadcastSystemToAllExceptTeam", at = @At("HEAD"), cancellable = true)
    private void abysscore$silentNonTeamMessage(class_1657 player, class_2561 message, CallbackInfo ci) {
        if (VanishMessages.handleTeamBroadcast((class_3324) (Object) this, player, message, false)) {
            ci.cancel();
        }
    }

    // ── Sounds and block effects caused by a player (steps, breaking, placing, eating...) ──

    @Inject(method = "broadcast", at = @At("HEAD"), cancellable = true)
    private void abysscore$silentSounds(@Nullable class_1657 except, double x, double y, double z, double radius,
                                        class_5321<class_1937> dimension, class_2596<?> packet, CallbackInfo ci) {
        if (VanishHooks.broadcastNear((class_3324) (Object) this, except, x, y, z, radius, dimension, packet)) {
            ci.cancel();
        }
    }
}
