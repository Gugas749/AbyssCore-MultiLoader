package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import javax.annotation.Nullable;
import net.minecraft.class_2596;
import net.minecraft.class_3244;
import net.minecraft.class_7648;
import net.minecraft.class_8609;

/**
 * Every packet the server sends to a player goes through send(packet, listener).
 * We let VanishHooks.filterOutgoing look at it first (it only changes tab-list packets).
 *
 * 1.20.1 note: ServerCommonPacketListenerImpl doesn't exist yet (added in 1.20.2);
 * there the same method is ServerGamePacketListenerImpl.send(Packet, PacketSendListener).
 */
@Mixin(class_8609.class)
public abstract class ServerCommonPacketListenerVanishMixin {

    @Shadow
    public abstract void send(class_2596<?> packet, @Nullable class_7648 listener);

    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;Lnet/minecraft/network/PacketSendListener;)V",
            at = @At("HEAD"), cancellable = true)
    private void abysscore$filterVanished(class_2596<?> packet, @Nullable class_7648 listener, CallbackInfo ci) {
        // Only the "play" phase has a player (configuration phase listeners don't)
        if (!((Object) this instanceof class_3244 game)) return;

        class_2596<?> filtered = VanishHooks.filterOutgoing(game.field_14140, packet);
        if (filtered == packet) return;          // untouched → vanilla continues

        ci.cancel();                             // drop the original...
        if (filtered != null) {
            this.send(filtered, listener);       // ...and send the filtered copy (passes here again, unchanged)
        }
    }
}
