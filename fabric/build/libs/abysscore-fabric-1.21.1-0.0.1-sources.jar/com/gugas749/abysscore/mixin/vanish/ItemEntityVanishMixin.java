package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishManager;
import com.gugas749.abysscore.features.vanish.VanishOption;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NO_PICKUP: playerTouch() is where an item on the ground goes into the touching player's inventory. */
@Mixin(class_1542.class)
public abstract class ItemEntityVanishMixin {

    @Inject(method = "playerTouch", at = @At("HEAD"), cancellable = true)
    private void abysscore$noPickup(class_1657 player, CallbackInfo ci) {
        if (VanishManager.isActive(player, VanishOption.NO_PICKUP)) {
            ci.cancel();
        }
    }
}
