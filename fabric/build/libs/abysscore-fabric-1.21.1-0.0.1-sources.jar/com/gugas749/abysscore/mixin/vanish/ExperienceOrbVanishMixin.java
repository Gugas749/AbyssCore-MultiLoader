package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishManager;
import com.gugas749.abysscore.features.vanish.VanishOption;
import net.minecraft.class_1303;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * NO_PICKUP for XP orbs. Two parts:
 *
 *   1. Following: once a second an orb runs scanForEntities() and stores the player it will
 *      fly to in followingPlayer. Orbs flying towards "nothing" give a vanished player away,
 *      so if the chosen player is a vanished one we pick the nearest player that ISN'T
 *      (or nobody, and the orb just stays on the ground).
 *   2. Touching: playerTouch() is where the XP goes into the player; we skip it.
 */
@Mixin(class_1303.class)
public abstract class ExperienceOrbVanishMixin {

    @Shadow private class_1657 followingPlayer;

    @Inject(method = "scanForEntities", at = @At("TAIL"))
    private void abysscore$dontFollowVanished(CallbackInfo ci) {
        if (!VanishManager.isActive(this.followingPlayer, VanishOption.NO_PICKUP)) return;

        class_1303 self = (class_1303) (Object) this;
        // 8 blocks = the same range vanilla uses to find a player
        this.followingPlayer = self.method_37908().method_8604(self.method_23317(), self.method_23318(), self.method_23321(), 8.0,
                entity -> !entity.method_7325() && !VanishManager.isActive(entity, VanishOption.NO_PICKUP));
    }

    @Inject(method = "playerTouch", at = @At("HEAD"), cancellable = true)
    private void abysscore$noPickup(class_1657 player, CallbackInfo ci) {
        if (VanishManager.isActive(player, VanishOption.NO_PICKUP)) {
            ci.cancel();
        }
    }
}
