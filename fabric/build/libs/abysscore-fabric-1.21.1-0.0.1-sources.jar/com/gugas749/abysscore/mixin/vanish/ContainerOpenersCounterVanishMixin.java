package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5561;

/**
 * SILENT_CONTAINERS. Chests, trapped chests, barrels and ender chests count their viewers
 * here. The lid animation + sound play when the count goes 0 → 1 (and 1 → 0 on close).
 * A silent opener is simply never counted. (Shulker boxes don't use this class: see
 * ShulkerBoxBlockEntityVanishMixin.)
 */
@Mixin(class_5561.class)
public abstract class ContainerOpenersCounterVanishMixin {

    @Shadow private int openCount;

    @Inject(method = "incrementOpeners", at = @At("HEAD"), cancellable = true)
    private void abysscore$silentOpen(class_1657 player, class_1937 level, class_2338 pos, class_2680 state, CallbackInfo ci) {
        if (VanishHooks.isSilentOpener(player)) ci.cancel();
    }

    @Inject(method = "decrementOpeners", at = @At("HEAD"), cancellable = true)
    private void abysscore$silentClose(class_1657 player, class_1937 level, class_2338 pos, class_2680 state, CallbackInfo ci) {
        // openCount <= 0: the player opened it silently, then unvanished before closing.
        // Without this guard the count would go to -1 and the chest would stop animating.
        if (VanishHooks.isSilentOpener(player) || this.openCount <= 0) ci.cancel();
    }

    /** The re-check every 5 ticks recounts players looking inside; don't count silent ones. */
    @Inject(method = "getPlayersWithContainerOpen", at = @At("RETURN"), cancellable = true)
    private void abysscore$hideSilentOpeners(class_1937 level, class_2338 pos, CallbackInfoReturnable<List<class_1657>> cir) {
        cir.setReturnValue(VanishHooks.withoutSilentOpeners(cir.getReturnValue()));
    }
}
