package com.gugas749.abysscore.network.region;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record NoEntryPacket(
    double exitX,
    double exitY,
    double exitZ,
    float  exitYaw  // 180° from entry direction — player faces away from the region
) implements class_8710 {

    public static final class_9154<NoEntryPacket> TYPE =
        new class_9154<>(class_2960.method_60655("abysscore", "no_entry"));

    public static final class_9139<class_2540, NoEntryPacket> CODEC = class_9139.method_56437(
        (buf, pkt) -> {
            buf.method_52940(pkt.exitX());
            buf.method_52940(pkt.exitY());
            buf.method_52940(pkt.exitZ());
            buf.method_52941(pkt.exitYaw());
        },
        buf -> new NoEntryPacket(
            buf.readDouble(),
            buf.readDouble(),
            buf.readDouble(),
            buf.readFloat()
        )
    );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
