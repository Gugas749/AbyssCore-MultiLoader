package com.gugas749.abysscore.network.bulk;

import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client → Server: submits a new bulk command definition from the GUI screen.
 */
public record SubmitBulkCommandPacket(
    String name,
    int permLevel,
    List<String> commands
) implements class_8710 {

    public static final class_9154<SubmitBulkCommandPacket> TYPE =
        new class_9154<>(class_2960.method_60655("abysscore", "submit_bulk_command"));

    public static final class_9139<class_9129, SubmitBulkCommandPacket> CODEC =
        class_9139.method_56436(
            class_9135.field_48554,
            SubmitBulkCommandPacket::name,
            class_9135.field_49675,
            SubmitBulkCommandPacket::permLevel,
            class_9135.method_56376(java.util.ArrayList::new, class_9135.field_48554),
            SubmitBulkCommandPacket::commands,
            SubmitBulkCommandPacket::new
        );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
