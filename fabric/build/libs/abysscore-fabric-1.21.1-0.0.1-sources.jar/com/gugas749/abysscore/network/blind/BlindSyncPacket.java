package com.gugas749.abysscore.network.blind;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Server → Client: enables or disables the blind screen overlay. */
public record BlindSyncPacket(boolean blinded) implements class_8710 {

    public static final class_9154<BlindSyncPacket> TYPE =
        new class_9154<>(class_2960.method_60655("abysscore", "blind_sync"));

    public static final class_9139<ByteBuf, BlindSyncPacket> CODEC =
        class_9135.field_48547.method_56432(BlindSyncPacket::new, BlindSyncPacket::blinded);

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
