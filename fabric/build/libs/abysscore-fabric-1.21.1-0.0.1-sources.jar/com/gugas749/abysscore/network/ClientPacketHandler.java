package com.gugas749.abysscore.network;

import com.gugas749.abysscore.api.network.AbyssPacketContext;
import com.gugas749.abysscore.client.ui.AbyssCoreMenuScreen;
import com.gugas749.abysscore.client.ui.screens.DimenCreateScreen;
import com.gugas749.abysscore.client.ui.screens.RegionManagerScreen;
import com.gugas749.abysscore.network.dimen.OpenDimenCreateScreenPacket;
import com.gugas749.abysscore.network.menu.packets.OpenMainMenuPacket;
import com.gugas749.abysscore.network.region.OpenRegionScreenPacket;
import net.minecraft.class_310;

/**
 * CLIENT-side packet handlers for S2C packets that open screens.
 * Event wiring (NeoForge) lives in NeoForgeClientEventListeners.
 */
public class ClientPacketHandler {

    public static void handleOpenDimenCreate(OpenDimenCreateScreenPacket pkt, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> class_310.method_1551().method_1507(new DimenCreateScreen()));
    }

    public static void handleOpenRegionScreen(OpenRegionScreenPacket pkt, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> class_310.method_1551().method_1507(new RegionManagerScreen(pkt.regions())));
    }

    public static void handleOpenMainMenu(OpenMainMenuPacket pkt, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> class_310.method_1551().method_1507(new AbyssCoreMenuScreen(pkt)));
    }
}
