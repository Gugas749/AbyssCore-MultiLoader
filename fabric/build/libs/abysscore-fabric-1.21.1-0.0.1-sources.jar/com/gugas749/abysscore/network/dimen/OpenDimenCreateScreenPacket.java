package com.gugas749.abysscore.network.dimen;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record OpenDimenCreateScreenPacket() implements class_8710 {

    public static final class_9154<OpenDimenCreateScreenPacket> TYPE =
        new class_9154<>(class_2960.method_60655("abysscore", "open_dimen_create"));

    public static final class_9139<ByteBuf, OpenDimenCreateScreenPacket> CODEC =
        class_9139.method_56431(new OpenDimenCreateScreenPacket());

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
