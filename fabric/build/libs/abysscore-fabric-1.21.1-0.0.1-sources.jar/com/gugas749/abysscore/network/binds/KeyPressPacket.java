package com.gugas749.abysscore.network.binds;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client → Server: a keybind slot was pressed.
 * slot: 1-9
 */
public record KeyPressPacket(int slot) implements class_8710 {

    public static final class_9154<KeyPressPacket> TYPE =
            new class_9154<>(class_2960.method_60655("abysscore", "key_press"));

    public static final class_9139<ByteBuf, KeyPressPacket> CODEC =
            class_9135.field_49675.method_56432(KeyPressPacket::new, KeyPressPacket::slot);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
