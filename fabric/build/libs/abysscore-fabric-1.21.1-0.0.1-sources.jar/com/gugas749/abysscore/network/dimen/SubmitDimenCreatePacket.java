package com.gugas749.abysscore.network.dimen;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SubmitDimenCreatePacket(
        String name,
        String displayName,
        String style,     // "NORMAL", "SUPERFLAT", or "VOID"
        long   seed       // only used when style is NORMAL
) implements class_8710 {

    public static final class_9154<SubmitDimenCreatePacket> TYPE =
            new class_9154<>(class_2960.method_60655("abysscore", "submit_dimen_create"));

    public static final class_9139<class_9129, SubmitDimenCreatePacket> CODEC =
            class_9139.method_56905(
                    class_9135.field_48554, SubmitDimenCreatePacket::name,
                    class_9135.field_48554, SubmitDimenCreatePacket::displayName,
                    class_9135.field_48554, SubmitDimenCreatePacket::style,
                    class_9135.field_48551,    SubmitDimenCreatePacket::seed,
                    SubmitDimenCreatePacket::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
