package com.gugas749.abysscore.network.menu.packets;

import com.gugas749.abysscore.Constants;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SaveTitlePacket(
    String id,           // empty = create new
    String name,
    String titleText,
    String subtitleText,
    int fadeIn,
    int stay,
    int fadeOut
) implements class_8710 {

    public static final class_9154<SaveTitlePacket> TYPE =
        new class_9154<>(class_2960.method_60655(Constants.MOD_ID, "save_title"));

    public static final class_9139<class_9129, SaveTitlePacket> CODEC = class_9139.method_56437(
            (buf, pkt) -> {
                buf.method_10814(pkt.id());
                buf.method_10814(pkt.name());
                buf.method_10814(pkt.titleText());
                buf.method_10814(pkt.subtitleText());
                buf.method_53002(pkt.fadeIn());
                buf.method_53002(pkt.stay());
                buf.method_53002(pkt.fadeOut());
            },
            buf -> new SaveTitlePacket(
                    buf.method_19772(), buf.method_19772(), buf.method_19772(), buf.method_19772(),
                    buf.readInt(), buf.readInt(), buf.readInt()
            )
    );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
