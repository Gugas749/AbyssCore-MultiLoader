package com.gugas749.abysscore.network;

import com.gugas749.abysscore.platform.Services;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

/**
 * Static helpers for sending packets from common code.
 *
 * Previously common files called PacketDistributor.sendToX() directly, which is a
 * NeoForge type.  Now they call AbyssNetwork.sendToX(), which delegates to the
 * INetworkPlatform service that each loader implements.
 */
public class AbyssNetwork {

    public static void sendToPlayer(class_3222 player, class_8710 packet) {
        Services.NETWORK.sendToPlayer(player, packet);
    }

    public static void sendToServer(class_8710 packet) {
        Services.NETWORK.sendToServer(packet);
    }
}
