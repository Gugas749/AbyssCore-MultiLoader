package com.gugas749.abysscore.network.menu.packets;

import com.gugas749.abysscore.Constants;
import java.util.*;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record OpenMainMenuPacket(
        List<PlayerState>   players,
        List<TitleEntry>    titles,
        List<DimEntry>      dims,
        List<HelpEntry>     helpRequests,
        List<BulkEntry>     bulkCommands,
        Map<Integer, String> bindSlots,    // slot (1-9) → bulk command name
        boolean             teamVisibility, // vanish team visibility state
        VanishInfo          vanish          // the VIEWER's own vanish options + exceptions
) implements class_8710 {

    /**
     * options    = VanishManager.getOptionBits(viewer): bit N on = VanishOption.values()[N] on
     * shownTo    = players the viewer is forced VISIBLE to   (/abysscore vanish show)
     * hiddenFrom = players the viewer is forced HIDDEN from  (/abysscore vanish hide)
     */
    public record VanishInfo(int options, List<UUID> shownTo, List<UUID> hiddenFrom) {}

    public record PlayerState(UUID uuid, String name,
                              boolean vanished, boolean godMode, boolean blinded) {}

    public record TitleEntry(String id, String name, String titleText,
                             String subtitleText, int fadeIn, int stay, int fadeOut) {}

    public record DimEntry(String name, String state) {}  // state = LOADED/PENDING/UNLOADED

    public record HelpEntry(UUID playerUUID, String playerName, String reason) {}

    public record BulkEntry(String name) {}

    public static final class_9154<OpenMainMenuPacket> TYPE =
            new class_9154<>(class_2960.method_60655(Constants.MOD_ID, "open_main_menu"));

    public static final class_9139<class_9129, OpenMainMenuPacket> CODEC = class_9139.method_56437(
            (buf, pkt) -> {
                // Players
                buf.method_53002(pkt.players().size());
                for (var p : pkt.players()) {
                    buf.method_10797(p.uuid()); buf.method_10814(p.name());
                    buf.method_52964(p.vanished()); buf.method_52964(p.godMode()); buf.method_52964(p.blinded());
                }
                // Titles
                buf.method_53002(pkt.titles().size());
                for (var t : pkt.titles()) {
                    buf.method_10814(t.id()); buf.method_10814(t.name());
                    buf.method_10814(t.titleText()); buf.method_10814(t.subtitleText());
                    buf.method_53002(t.fadeIn()); buf.method_53002(t.stay()); buf.method_53002(t.fadeOut());
                }
                // Dims
                buf.method_53002(pkt.dims().size());
                for (var d : pkt.dims()) { buf.method_10814(d.name()); buf.method_10814(d.state()); }
                // Help requests
                buf.method_53002(pkt.helpRequests().size());
                for (var h : pkt.helpRequests()) {
                    buf.method_10797(h.playerUUID()); buf.method_10814(h.playerName()); buf.method_10814(h.reason());
                }
                // Bulk commands
                buf.method_53002(pkt.bulkCommands().size());
                for (var b : pkt.bulkCommands()) {
                    buf.method_10814(b.name());
                }
                // Bind slots
                buf.method_53002(pkt.bindSlots().size());
                pkt.bindSlots().forEach((slot, name) -> { buf.method_53002(slot); buf.method_10814(name); });
                // Team visibility
                buf.method_52964(pkt.teamVisibility());
                // Vanish (viewer)
                buf.method_53002(pkt.vanish().options());
                writeUuids(buf, pkt.vanish().shownTo());
                writeUuids(buf, pkt.vanish().hiddenFrom());
            },
            buf -> {
                int pc = buf.readInt();
                List<PlayerState> players = new ArrayList<>();
                for (int i = 0; i < pc; i++) players.add(new PlayerState(
                        buf.method_10790(), buf.method_19772(),
                        buf.readBoolean(), buf.readBoolean(), buf.readBoolean()));

                int tc = buf.readInt();
                List<TitleEntry> titles = new ArrayList<>();
                for (int i = 0; i < tc; i++) titles.add(new TitleEntry(
                        buf.method_19772(), buf.method_19772(), buf.method_19772(), buf.method_19772(),
                        buf.readInt(), buf.readInt(), buf.readInt()));

                int dc = buf.readInt();
                List<DimEntry> dims = new ArrayList<>();
                for (int i = 0; i < dc; i++) dims.add(new DimEntry(buf.method_19772(), buf.method_19772()));

                int hc = buf.readInt();
                List<HelpEntry> help = new ArrayList<>();
                for (int i = 0; i < hc; i++) help.add(new HelpEntry(
                        buf.method_10790(), buf.method_19772(), buf.method_19772()));

                int bc = buf.readInt();
                List<BulkEntry> bulk = new ArrayList<>();
                for (int i = 0; i < bc; i++) bulk.add(new BulkEntry(buf.method_19772()));

                int bindCount = buf.readInt();
                Map<Integer, String> binds = new LinkedHashMap<>();
                for (int i = 0; i < bindCount; i++) binds.put(buf.readInt(), buf.method_19772());

                boolean teamVis = buf.readBoolean();

                VanishInfo vanish = new VanishInfo(buf.readInt(), readUuids(buf), readUuids(buf));

                return new OpenMainMenuPacket(players, titles, dims, help, bulk, binds, teamVis, vanish);
            }
    );

    private static void writeUuids(class_9129 buf, List<UUID> uuids) {
        buf.method_53002(uuids.size());
        for (UUID uuid : uuids) buf.method_10797(uuid);
    }

    private static List<UUID> readUuids(class_9129 buf) {
        int count = buf.readInt();
        List<UUID> list = new ArrayList<>(count);
        for (int i = 0; i < count; i++) list.add(buf.method_10790());
        return list;
    }

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}