package com.gugas749.abysscore.network.menu.packets;

import com.gugas749.abysscore.Constants;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record RequestRegionScreenPacket() implements class_8710 {
    public static final class_9154<RequestRegionScreenPacket> TYPE =
            new class_9154<>(class_2960.method_60655(Constants.MOD_ID, "request_region_screen"));
    public static final class_9139<ByteBuf, RequestRegionScreenPacket> CODEC =
            class_9139.method_56431(new RequestRegionScreenPacket());
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
