package com.gugas749.abysscore.network.region;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Client → Server: blackscreen is at peak opacity, safe to teleport now.
 * Server teleports the player on receiving this — the world change is
 * hidden by the black overlay.
 */
public record ReadyToTeleportPacket() implements class_8710 {

    public static final class_9154<ReadyToTeleportPacket> TYPE =
        new class_9154<>(class_2960.method_60655("abysscore", "ready_to_tp"));

    public static final class_9139<class_9129, ReadyToTeleportPacket> CODEC =
            class_9139.method_56431(new ReadyToTeleportPacket());

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
