package com.gugas749.abysscore.network.dimen;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.network.AbyssPacketContext;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.gugas749.abysscore.features.dimen.ACDimensionData;
import com.gugas749.abysscore.features.dimen.ACDimensionManager;
import java.util.Random;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class DimenPacketHandlers {

    public static void handleCreate(SubmitDimenCreatePacket packet, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof class_3222 player)) return;
            if (!AbyssPermissionHandler.require(player, AbyssPermissionLevel.ADMIN)) return;   // same as /abysscore dimen

            String name = packet.name().trim().toLowerCase().replaceAll("[^a-z0-9_]", "_");
            if (name.isEmpty()) {
                player.method_43496(class_2561.method_43471("message.abysscore.dimen.invalid_name"));
                return;
            }

            if (ACDimensionManager.exists(name)) {
                player.method_43496(
                        class_2561.method_43469("message.abysscore.dimen.already_exists", name));
                return;
            }

            // Use a random seed if the user left it at 0
            long seed = packet.seed() == 0 ? new Random().nextLong() : packet.seed();

            String displayName = packet.displayName().isBlank() ? name : packet.displayName().trim();

            ACDimensionData data = new ACDimensionData(
                    name,
                    displayName,
                    ACDimensionData.Style.fromString(packet.style()),
                    seed
            );

            boolean success = ACDimensionManager.create(data, player.method_5682());

            if (success) {
                player.method_43496(
                        class_2561.method_43469("message.abysscore.dimen.created_pending", name));
                Constants.LOG.info("[AbyssCore] {} created dimension '{}'.",
                        player.method_5477().getString(), name);
            } else {
                player.method_43496(
                        class_2561.method_43469("message.abysscore.dimen.create_failed", name));
            }
        });
    }
}
