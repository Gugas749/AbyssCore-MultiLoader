package com.gugas749.abysscore.network.vanish;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → Client: are you vanished, and should the HUD warning be drawn
 * (false when you turned the HUD_WARNING option off).
 */
public record VanishStateSyncPacket(boolean vanished, boolean showHud) implements class_8710 {

    public static final class_9154<VanishStateSyncPacket> TYPE =
        new class_9154<>(class_2960.method_60655("abysscore", "vanish_state"));

    // composite(codec1, getter1, codec2, getter2, constructor): writes/reads the fields in order
    public static final class_9139<ByteBuf, VanishStateSyncPacket> CODEC = class_9139.method_56435(
            class_9135.field_48547, VanishStateSyncPacket::vanished,
            class_9135.field_48547, VanishStateSyncPacket::showHud,
            VanishStateSyncPacket::new);

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
