package com.gugas749.abysscore.network.bulk;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.network.AbyssPacketContext;
import com.gugas749.abysscore.api.permission.AbyssPermissionHandler;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.gugas749.abysscore.features.bulk.BulkCommandData;
import com.gugas749.abysscore.features.bulk.BulkCommandManager;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Handles SubmitBulkCommandPacket on the SERVER side.
 * Validates the sender is MODERATOR+ (same as /abysscore bulk), then saves the new bulk command.
 */
public class SubmitBulkCommandHandler {

    public static void handle(SubmitBulkCommandPacket packet, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof class_3222 player)) return;

            // Security: MODERATOR+ can create bulk commands
            if (!AbyssPermissionHandler.require(player, AbyssPermissionLevel.MODERATOR)) {
                Constants.LOG.warn(
                    "[AbyssCore] Player {} tried to create a bulk command without MODERATOR permissions!",
                    player.method_5477().getString()
                );
                return;
            }
            String name = packet.name().trim().toLowerCase();

            // Validate name
            if (name.isEmpty() || !name.matches("[a-z0-9_]+")) {
                player.method_43496(
                    class_2561.method_43471("message.abysscore.bulk.invalid_name")
                );
                return;
            }

            // Validate commands list
            if (packet.commands().isEmpty()) {
                player.method_43496(
                    class_2561.method_43471("message.abysscore.bulk.no_commands")
                );
                return;
            }

            // Save
            BulkCommandData data = new BulkCommandData(name, packet.permLevel(), packet.commands());
            boolean added = BulkCommandManager.add(data);

            if (!added) {
                player.method_43496(
                    class_2561.method_43469("message.abysscore.bulk.already_exists", name)
                );
                return;
            }

            player.method_43496(
                class_2561.method_43469("message.abysscore.bulk.created", name, packet.commands().size())
            );

            Constants.LOG.info(
                "[AbyssCore] {} created bulk command '{}' with {} sub-command(s).",
                player.method_5477().getString(), name, packet.commands().size()
            );
        });
    }
}
