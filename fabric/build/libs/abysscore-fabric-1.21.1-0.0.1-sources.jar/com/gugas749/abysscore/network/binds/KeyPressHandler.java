package com.gugas749.abysscore.network.binds;

import com.gugas749.abysscore.Constants;
import com.gugas749.abysscore.api.network.AbyssPacketContext;
import com.gugas749.abysscore.features.bind.BindManager;
import com.gugas749.abysscore.features.bulk.BulkCommandData;
import com.gugas749.abysscore.features.bulk.BulkCommandManager;
import java.util.Optional;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Handles KeyPressPacket on the SERVER side.
 * Looks up what the player has bound to that slot and executes it.
 */
public class KeyPressHandler {
    public static void handle(KeyPressPacket packet, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof class_3222 player)) return;

            int slot = packet.slot();
            if (slot < 1 || slot > 9) return;

            String binding = BindManager.getBinding(player.method_5667(), slot);
            if (binding == null) return; // slot not bound, do nothing silently

            class_2168 source = player.method_5671();

            // Check if the binding matches a bulk command name first
            Optional<BulkCommandData> bulk = BulkCommandManager.get(binding);

            if (bulk.isPresent()) {
                // It's a bulk command — check its permission level
                BulkCommandData data = bulk.get();
                if (!player.method_5687(data.permLevel)) {
                    player.method_43496(
                            class_2561.method_43471("message.abysscore.bulk.no_permission")
                    );
                    return;
                }

                // Execute each sub-command
                for (String cmd : data.commands) {
                    try {
                        player.method_5682().method_3734().method_9235().execute(cmd, source);
                    } catch (Exception e) {
                        Constants.LOG.warn(
                                "[AbyssCore] Bind slot {} bulk sub-command failed for {}: {}",
                                slot, player.method_5477().getString(), e.getMessage()
                        );
                    }
                }
            } else {
                // It's a raw command — execute directly
                try {
                    player.method_5682().method_3734().method_9235().execute(binding, source);
                } catch (Exception e) {
                    Constants.LOG.warn(
                            "[AbyssCore] Bind slot {} raw command failed for {}: {}",
                            slot, player.method_5477().getString(), e.getMessage()
                    );
                    player.method_43496(
                            class_2561.method_43469("message.abysscore.bind.exec_failed", binding)
                    );
                }
            }
        });
    }
}
