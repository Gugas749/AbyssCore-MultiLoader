package com.gugas749.abysscore.network.region;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record OpenRegionScreenPacket(List<RegionEntry> regions) implements class_8710 {

    public record RegionEntry(
        String name,
        String dimension,
        int minX, int minY, int minZ,
        int maxX, int maxY, int maxZ,
        Set<String> tags,
        String entryFilterTag   // empty = no filter (nobody enters)
    ) {}

    public static final class_9154<OpenRegionScreenPacket> TYPE =
        new class_9154<>(class_2960.method_60655("abysscore", "open_region_screen"));

    public static final class_9139<class_2540, OpenRegionScreenPacket> CODEC = class_9139.method_56437(
        (buf, pkt) -> {
            buf.method_53002(pkt.regions().size());
            for (RegionEntry r : pkt.regions()) {
                buf.method_10814(r.name());
                buf.method_10814(r.dimension());
                buf.method_53002(r.minX()); buf.method_53002(r.minY()); buf.method_53002(r.minZ());
                buf.method_53002(r.maxX()); buf.method_53002(r.maxY()); buf.method_53002(r.maxZ());
                buf.method_53002(r.tags().size());
                r.tags().forEach(buf::method_10814);
                buf.method_10814(r.entryFilterTag() != null ? r.entryFilterTag() : "");
            }
        },
        buf -> {
            int count = buf.readInt();
            List<RegionEntry> regions = new ArrayList<>();
            for (int i = 0; i < count; i++) {
                String name = buf.method_19772(), dim = buf.method_19772();
                int minX = buf.readInt(), minY = buf.readInt(), minZ = buf.readInt();
                int maxX = buf.readInt(), maxY = buf.readInt(), maxZ = buf.readInt();
                int tagCount = buf.readInt();
                Set<String> tags = new LinkedHashSet<>();
                for (int t = 0; t < tagCount; t++) tags.add(buf.method_19772());
                String filterTag = buf.method_19772();
                regions.add(new RegionEntry(name, dim, minX, minY, minZ, maxX, maxY, maxZ, tags, filterTag));
            }
            return new OpenRegionScreenPacket(regions);
        }
    );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
