package com.gugas749.abysscore.network.menu.packets;

import com.gugas749.abysscore.Constants;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record MenuActionPacket(
        Action action,
        UUID   targetUUID,
        String stringArg1,
        String stringArg2,
        int    intArg
) implements class_8710 {

    public enum Action {
        // Player actions
        TOGGLE_STAFF, TOGGLE_VANISH, TOGGLE_GOD, TOGGLE_BLIND,
        // Title actions
        DELETE_TITLE, SEND_TITLE_ALL, SEND_TITLE_TAG, SEND_TITLE_TEAM, SEND_TITLE_PLAYER,
        // Vanish actions
        TOGGLE_TEAM_VISIBILITY,
        VANISH_SHOW_TO,   // stringArg1 = vanished player UUID str, targetUUID = viewer
        VANISH_HIDE_FROM, // stringArg1 = vanished player UUID str, targetUUID = viewer
        VANISH_CLEAR,     // stringArg1 = vanished player UUID str
        // Dimen actions
        DIMEN_TP,         // stringArg1 = dim key
        DIMEN_CREATE,     // opens create screen — handled client-side
        // Help actions
        HELP_ACCEPT,      // targetUUID = requester UUID
        // Bulk actions
        BULK_RUN,         // stringArg1 = bulk name
        BULK_BIND,        // stringArg1 = bulk name, intArg = slot (1-9)
        BULK_UNBIND,      // intArg = slot
        // Vanish options (added at the END so the ordinals above keep their numbers)
        VANISH_SET_OPTION, // stringArg1 = VanishOption id, intArg = 1 (on) / 0 (off); always the sender's own
    }

    public static MenuActionPacket of(Action action) {
        return new MenuActionPacket(action, null, "", "", 0);
    }
    public static MenuActionPacket playerAction(Action action, UUID uuid) {
        return new MenuActionPacket(action, uuid, "", "", 0);
    }
    public static MenuActionPacket stringAction(Action action, String a1, String a2) {
        return new MenuActionPacket(action, null, a1, a2, 0);
    }
    public static MenuActionPacket intAction(Action action, String a1, int intArg) {
        return new MenuActionPacket(action, null, a1, "", intArg);
    }

    public static final class_9154<MenuActionPacket> TYPE =
            new class_9154<>(class_2960.method_60655(Constants.MOD_ID, "menu_action"));

    public static final class_9139<class_9129, MenuActionPacket> CODEC = class_9139.method_56437(
            (buf, pkt) -> {
                buf.method_53002(pkt.action().ordinal());
                buf.method_52964(pkt.targetUUID() != null);
                if (pkt.targetUUID() != null) buf.method_10797(pkt.targetUUID());
                buf.method_10814(pkt.stringArg1() != null ? pkt.stringArg1() : "");
                buf.method_10814(pkt.stringArg2() != null ? pkt.stringArg2() : "");
                buf.method_53002(pkt.intArg());
            },
            buf -> {
                Action action = Action.values()[buf.readInt()];
                UUID uuid = buf.readBoolean() ? buf.method_10790() : null;
                return new MenuActionPacket(action, uuid, buf.method_19772(), buf.method_19772(), buf.readInt());
            }
    );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}