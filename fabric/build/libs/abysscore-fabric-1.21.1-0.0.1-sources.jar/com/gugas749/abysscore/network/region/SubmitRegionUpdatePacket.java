package com.gugas749.abysscore.network.region;

import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record SubmitRegionUpdatePacket(
    String regionName,
    boolean delete,
    Set<String> tags,
    String entryFilterTag   // empty = no filter
) implements class_8710 {

    public static final class_9154<SubmitRegionUpdatePacket> TYPE =
        new class_9154<>(class_2960.method_60655("abysscore", "submit_region_update"));

    public static final class_9139<class_2540, SubmitRegionUpdatePacket> CODEC = class_9139.method_56437(
        (buf, pkt) -> {
            buf.method_10814(pkt.regionName());
            buf.method_52964(pkt.delete());
            buf.method_53002(pkt.tags().size());
            pkt.tags().forEach(buf::method_10814);
            buf.method_10814(pkt.entryFilterTag() != null ? pkt.entryFilterTag() : "");
        },
        buf -> {
            String name = buf.method_19772();
            boolean delete = buf.readBoolean();
            int tagCount = buf.readInt();
            Set<String> tags = new LinkedHashSet<>();
            for (int i = 0; i < tagCount; i++) tags.add(buf.method_19772());
            String filterTag = buf.method_19772();
            return new SubmitRegionUpdatePacket(name, delete, tags, filterTag);
        }
    );

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
