package com.gugas749.abysscore;

import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Constants {

    public static final String MOD_ID = "abysscore";
    public static final String MOD_NAME = "AbyssCore";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_NAME);

    public static class_2960 asResource(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}
