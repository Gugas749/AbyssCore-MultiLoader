package com.gugas749.abysscore.client.gui.demo;

import com.gugas749.abysscore.api.permission.AbyssClientPermission;
import com.gugas749.abysscore.api.permission.AbyssPermissionLevel;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * /abyssgui — a CLIENT command (runs on the player's own game, the server never sees it).
 * Opens the GUI demo for staff.
 * Called from NeoForgeClientEventListeners on RegisterClientCommandsEvent.
 */
public final class AbyssGuiDemoCommand {

    private AbyssGuiDemoCommand() {}

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("abyssgui").executes(ctx -> {
            if (!AbyssClientPermission.has(AbyssPermissionLevel.MODERATOR)) {
                ctx.getSource().method_9213(class_2561.method_43471("gui.abysscore.no_permission"));
                return 0;
            }
            // The chat screen closes itself AFTER running the command, which would close our
            // screen immediately. tell() runs it on the next frame, after chat has closed.
            class_310 mc = class_310.method_1551();
            mc.method_18858(() -> mc.method_1507(new AbyssGuiDemoScreen()));
            return 1;
        }));
    }
}
