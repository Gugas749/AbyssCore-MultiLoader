package com.gugas749.abysscore.client.ui.screens;

import com.gugas749.abysscore.api.network.AbyssPacketContext;
import com.gugas749.abysscore.network.blind.BlindSyncPacket;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Renders a full opaque black overlay when the player is blinded.
 *
 * Rendered in BOTH Pre and Post events to cover everything —
 * including chat message backgrounds which are transparent in Post only.
 * Event wiring (NeoForge) lives in NeoForgeClientEventListeners; only plain methods here.
 */
public class BlindScreen {

    private static boolean blinded = false;

    public static void handleSync(BlindSyncPacket packet, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> blinded = packet.blinded());
    }

    public static boolean isBlinded() { return blinded; }

    /** Called on both Pre and Post render GUI events by NeoForgeClientEventListeners. */
    public static void renderBlack(class_332 g) {
        if (!blinded) return;
        if (class_310.method_1551().field_1724 == null) return;
        class_310 mc = class_310.method_1551();
        // 0xFF000000 — alpha MUST be FF (fully opaque), 0x000000 alone is transparent
        g.method_25294(0, 0,
            mc.method_22683().method_4486(),
            mc.method_22683().method_4502(),
            0xFF000000
        );
    }
}
