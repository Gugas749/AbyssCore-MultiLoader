package com.gugas749.abysscore.client;

import com.gugas749.abysscore.network.AbyssNetwork;
import com.gugas749.abysscore.network.binds.KeyPressPacket;
import net.minecraft.class_310;

/**
 * Fires key bindings every client tick.
 * Event wiring (NeoForge) lives in NeoForgeClientEventListeners; only plain logic here.
 */
public class ClientTickHandler {

    /** Called by NeoForgeClientEventListeners on ClientTickEvent.Post. */
    public void onClientTick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;

        for (int i = 0; i < KeyBindings.SLOT_COUNT; i++) {
            if (KeyBindings.SLOTS[i].method_1436()) {
                AbyssNetwork.sendToServer(new KeyPressPacket(i + 1));
            }
        }
    }
}
