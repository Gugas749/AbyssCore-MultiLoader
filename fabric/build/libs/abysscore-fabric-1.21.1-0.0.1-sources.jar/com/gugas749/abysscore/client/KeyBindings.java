package com.gugas749.abysscore.client;

import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {
    public static final String CATEGORY = "key.categories.abysscore";
    public static final int SLOT_COUNT  = 9;

    public static final class_304[] SLOTS = new class_304[SLOT_COUNT];

    static {
        for (int i = 0; i < SLOT_COUNT; i++) {
            SLOTS[i] = new class_304(
                    "key.abysscore.bind_" + (i + 1),          // translation key
                    class_3675.class_307.field_1668,
                    GLFW.GLFW_KEY_UNKNOWN,                      // unbound by default
                    CATEGORY
            );
        }
    }

    /** Called by the NeoForge loader on RegisterKeyMappingsEvent to register all slots. */
    public static class_304[] getAll() {
        return SLOTS;
    }
}
