package com.gugas749.abysscore.client;

import com.gugas749.abysscore.api.network.AbyssPacketContext;
import com.gugas749.abysscore.network.vanish.VanishStateSyncPacket;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * CLIENT: renders the vanish HUD warning and handles VanishStateSyncPacket.
 * The loader calls render() after the HUD is drawn (NeoForge/Forge: RenderGuiEvent.Post,
 * wired in each Abysscore.java). Only plain methods here.
 */
public class ACVanishHudHandler {

    private static boolean isVanished = false;
    private static boolean showHud = true;     // the player's HUD_WARNING option
    private static long vanishedSince = 0;

    public static void handleSync(VanishStateSyncPacket packet, AbyssPacketContext ctx) {
        ctx.enqueueWork(() -> {
            boolean wasVanished = isVanished;
            isVanished = packet.vanished();
            showHud = packet.showHud();
            if (!wasVanished && isVanished) {
                vanishedSince = System.currentTimeMillis();
            }
        });
    }

    /** Called by the loader on RenderGuiEvent.Post. */
    public void render(class_332 graphics, class_310 mc) {
        if (!isVanished || !showHud) return;
        if (mc.field_1724 == null || mc.field_1690.field_1842) return;
        if (mc.field_1755 != null) return;

        int screenWidth  = mc.method_22683().method_4486();
        int screenHeight = mc.method_22683().method_4502();

        class_2561 text = class_2561.method_43471("message.abysscore.vanish.hud_warning");
        int textWidth = mc.field_1772.method_27525(text);

        int x = (screenWidth - textWidth) / 2;
        int y = screenHeight - 52;

        long elapsed = System.currentTimeMillis() - vanishedSince;
        float pulse = (float) Math.sin(elapsed / 600.0) * 0.5f + 0.5f;
        int alpha = (int) (180 + pulse * 75);

        int padding = 4;
        graphics.method_25294(
            x - padding,
            y - padding,
            x + textWidth + padding,
            y + mc.field_1772.field_2000 + padding,
            (alpha / 2) << 24
        );

        int color = (alpha << 24) | 0xFF4444;
        graphics.method_51439(mc.field_1772, text, x, y, color, false);
    }

    public static boolean isVanished() { return isVanished; }
}
