package com.gugas749.abysscore.client.ui.screens;

import com.gugas749.abysscore.api.gui.layout.AbyssLayout;
import com.gugas749.abysscore.api.gui.layout.AbyssLayout.Flow;
import com.gugas749.abysscore.api.gui.screen.AbyssPanelScreen;
import com.gugas749.abysscore.api.gui.screen.AbyssTab;
import com.gugas749.abysscore.api.gui.screen.TabContext;
import com.gugas749.abysscore.api.gui.theme.AbyssTheme;
import com.gugas749.abysscore.api.gui.widget.AbyssButton;
import com.gugas749.abysscore.api.gui.widget.AbyssTextField;
import com.gugas749.abysscore.network.AbyssNetwork;
import com.gugas749.abysscore.network.dimen.SubmitDimenCreatePacket;
import javax.annotation.Nullable;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.util.List;
import java.util.Random;

/**
 * Create a new dimension. Opened from the menu's Dimensions tab (or by the server).
 * One tab → no sidebar, the form uses the whole panel.
 */
public class DimenCreateScreen extends AbyssPanelScreen {

    private static final String[] STYLES = {"NORMAL", "SUPERFLAT", "VOID"};

    // Form state — fields, so resizing the window keeps what was typed
    private String name = "", displayName = "", seed = "0";
    private int style = 0;

    public DimenCreateScreen(@Nullable class_437 parent) {
        super(class_2561.method_43470("\u2318  CREATE DIMENSION"), parent);
    }

    /** Used when the server opens this screen directly. */
    public DimenCreateScreen() { this(null); }

    @Override protected int panelWidth()  { return 270; }
    @Override protected int panelHeight() { return 210; }

    @Override
    protected void addTabs(List<AbyssTab> tabs) {
        tabs.add(new FormTab());
    }

    private class FormTab implements AbyssTab {
        private AbyssButton createButton;

        @Override public class_2561 title() { return class_2561.method_43470("Create"); }

        @Override
        public void init(TabContext ctx) {
            int w = ctx.width;

            var nameField = ctx.add(new AbyssTextField(ctx.x, ctx.y + 10, w, class_2561.method_43470("e.g. my_world")));
            nameField.method_1880(64);
            nameField.method_1852(name);
            nameField.method_1863(v -> { name = v; updateCreate(); });

            var displayField = ctx.add(new AbyssTextField(ctx.x, ctx.y + 42, w, class_2561.method_43470("e.g. My World")));
            displayField.method_1880(64);
            displayField.method_1852(displayName);
            displayField.method_1863(v -> displayName = v);

            // Style: one button that cycles NORMAL → SUPERFLAT → VOID
            ctx.add(new AbyssButton(ctx.x, ctx.y + 74, w, styleLabel(), b -> {
                style = (style + 1) % STYLES.length;
                ctx.rebuild();   // the seed row only exists for NORMAL
            }));

            if (STYLES[style].equals("NORMAL")) {
                int half = (w - 4) / 2;
                var seedField = ctx.add(new AbyssTextField(ctx.x, ctx.y + 110, half, class_2561.method_43470("0 = random")));
                seedField.method_1880(20);
                seedField.method_1890(s -> s.matches("-?\\d*"));   // a (possibly negative) whole number
                seedField.method_1852(seed);
                seedField.method_1863(v -> seed = v);
                ctx.add(new AbyssButton(ctx.x + half + 4, ctx.y + 110, half, class_2561.method_43470("\u21BA Random"), b -> {
                    seed = String.valueOf(new Random().nextLong());
                    ctx.rebuild();
                }));
            }

            var row = AbyssLayout.row(ctx.x, ctx.y + ctx.height - AbyssButton.HEIGHT, 4);
            createButton = row.add(ctx.add(new AbyssButton(0, 0, 90, class_2561.method_43470("Create"), b -> create())));
            row.add(ctx.add(new AbyssButton(0, 0, 90, class_2561.method_43470("Cancel"), b -> method_25419())));
            updateCreate();
        }

        private class_2561 styleLabel() {
            String s = STYLES[style];
            return class_2561.method_43470("Style: " + s.charAt(0) + s.substring(1).toLowerCase());
        }

        private void updateCreate() {
            if (createButton != null) createButton.field_22763 = !sanitized().isEmpty();
        }

        @Override
        public void render(class_332 g, TabContext ctx, int mouseX, int mouseY, float partialTick) {
            var font = ctx.font();
            g.method_51433(font, "Internal name", ctx.x, ctx.y + 1, AbyssTheme.TEXT_DIM, false);
            // Show what the id will really be (lowercase, a–z 0–9 _)
            String id = sanitized();
            if (!id.isEmpty() && !id.equals(name)) {
                String preview = "\u2192 " + id;
                g.method_51433(font, preview, ctx.x + ctx.width - font.method_1727(preview), ctx.y + 1, AbyssTheme.ACCENT, false);
            }
            g.method_51433(font, "Display name", ctx.x, ctx.y + 33, AbyssTheme.TEXT_DIM, false);
            if (STYLES[style].equals("NORMAL")) {
                g.method_51433(font, "Seed", ctx.x, ctx.y + 101, AbyssTheme.TEXT_DIM, false);
            }
        }
    }

    /** Dimension ids may only contain a–z, 0–9 and _ . */
    private String sanitized() {
        return name.trim().toLowerCase().replaceAll("[^a-z0-9_]", "_");
    }

    private void create() {
        long seedValue = 0;
        try { seedValue = Long.parseLong(seed.trim()); } catch (NumberFormatException ignored) {}
        AbyssNetwork.sendToServer(new SubmitDimenCreatePacket(sanitized(), displayName.trim(), STYLES[style], seedValue));
        method_25419();
    }
}
