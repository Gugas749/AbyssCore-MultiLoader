package com.gugas749.abysscore.features.help;

import java.util.UUID;

public class ACHelpRequest {

    public final UUID playerUUID;
    public final String playerName;
    public final String reason;
    public final long createdAt;
    public boolean accepted = false;

    public ACHelpRequest(UUID playerUUID, String playerName, String reason) {
        this.playerUUID = playerUUID;
        this.playerName = playerName;
        this.reason     = reason;
        this.createdAt  = System.currentTimeMillis();
    }
}
