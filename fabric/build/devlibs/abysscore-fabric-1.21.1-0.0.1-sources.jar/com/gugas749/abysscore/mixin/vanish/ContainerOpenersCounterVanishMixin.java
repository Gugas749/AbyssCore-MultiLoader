package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.ContainerOpenersCounter;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/**
 * SILENT_CONTAINERS. Chests, trapped chests, barrels and ender chests count their viewers
 * here. The lid animation + sound play when the count goes 0 → 1 (and 1 → 0 on close).
 * A silent opener is simply never counted. (Shulker boxes don't use this class: see
 * ShulkerBoxBlockEntityVanishMixin.)
 */
@Mixin(ContainerOpenersCounter.class)
public abstract class ContainerOpenersCounterVanishMixin {

    @Shadow private int openCount;

    @Inject(method = "incrementOpeners", at = @At("HEAD"), cancellable = true)
    private void abysscore$silentOpen(Player player, Level level, BlockPos pos, BlockState state, CallbackInfo ci) {
        if (VanishHooks.isSilentOpener(player)) ci.cancel();
    }

    @Inject(method = "decrementOpeners", at = @At("HEAD"), cancellable = true)
    private void abysscore$silentClose(Player player, Level level, BlockPos pos, BlockState state, CallbackInfo ci) {
        // openCount <= 0: the player opened it silently, then unvanished before closing.
        // Without this guard the count would go to -1 and the chest would stop animating.
        if (VanishHooks.isSilentOpener(player) || this.openCount <= 0) ci.cancel();
    }

    /** The re-check every 5 ticks recounts players looking inside; don't count silent ones. */
    @Inject(method = "getPlayersWithContainerOpen", at = @At("RETURN"), cancellable = true)
    private void abysscore$hideSilentOpeners(Level level, BlockPos pos, CallbackInfoReturnable<List<Player>> cir) {
        cir.setReturnValue(VanishHooks.withoutSilentOpeners(cir.getReturnValue()));
    }
}
