package com.gugas749.abysscore.mixin.vanish;

import com.gugas749.abysscore.features.vanish.VanishMessages;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Leave message → only staff, see VanishMessages. removePlayerFromWorld sends "X left the game". */
@Mixin(ServerGamePacketListenerImpl.class)
public abstract class ServerGamePacketListenerVanishMixin {

    @Shadow public ServerPlayer player;

    @Inject(method = "removePlayerFromWorld", at = @At("HEAD"))
    private void abysscore$leaveStart(CallbackInfo ci) {
        VanishMessages.push(this.player);
    }

    @Inject(method = "removePlayerFromWorld", at = @At("RETURN"))
    private void abysscore$leaveEnd(CallbackInfo ci) {
        VanishMessages.pop();
    }
}
