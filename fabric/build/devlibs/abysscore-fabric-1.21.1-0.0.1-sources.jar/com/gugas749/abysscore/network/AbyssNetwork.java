package com.gugas749.abysscore.network;

import com.gugas749.abysscore.platform.Services;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;

/**
 * Static helpers for sending packets from common code.
 *
 * Previously common files called PacketDistributor.sendToX() directly, which is a
 * NeoForge type.  Now they call AbyssNetwork.sendToX(), which delegates to the
 * INetworkPlatform service that each loader implements.
 */
public class AbyssNetwork {

    public static void sendToPlayer(ServerPlayer player, CustomPacketPayload packet) {
        Services.NETWORK.sendToPlayer(player, packet);
    }

    public static void sendToServer(CustomPacketPayload packet) {
        Services.NETWORK.sendToServer(packet);
    }
}
