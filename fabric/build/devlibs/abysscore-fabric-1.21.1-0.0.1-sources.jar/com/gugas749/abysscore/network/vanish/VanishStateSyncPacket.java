package com.gugas749.abysscore.network.vanish;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server → Client: are you vanished, and should the HUD warning be drawn
 * (false when you turned the HUD_WARNING option off).
 */
public record VanishStateSyncPacket(boolean vanished, boolean showHud) implements CustomPacketPayload {

    public static final Type<VanishStateSyncPacket> TYPE =
        new Type<>(ResourceLocation.fromNamespaceAndPath("abysscore", "vanish_state"));

    // composite(codec1, getter1, codec2, getter2, constructor): writes/reads the fields in order
    public static final StreamCodec<ByteBuf, VanishStateSyncPacket> CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, VanishStateSyncPacket::vanished,
            ByteBufCodecs.BOOL, VanishStateSyncPacket::showHud,
            VanishStateSyncPacket::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
