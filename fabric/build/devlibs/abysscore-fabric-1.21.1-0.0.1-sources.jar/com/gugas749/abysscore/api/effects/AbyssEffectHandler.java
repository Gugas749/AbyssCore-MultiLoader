package com.gugas749.abysscore.api.effects;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.*;

/**
 * Keeps registered effects on entities permanently (refreshes them before they expire).
 * Event wiring (NeoForge) lives in NeoForgeEventListeners; only plain methods here.
 */
public class AbyssEffectHandler {

    // UUID → list of effects to keep active on this entity
    private static final Map<UUID, List<MobEffectInstance>> continuousEffects = new HashMap<>();

    private static final int REFRESH_THRESHOLD = 200;

    public static void registerContinuousEffect(UUID target, List<MobEffectInstance> effects) {
        continuousEffects
                .computeIfAbsent(target, k -> new ArrayList<>())
                .addAll(effects);
    }

    public static void registerContinuousEffect(UUID target, MobEffectInstance effect) {
        registerContinuousEffect(target, List.of(effect));
    }

    public static void unregisterEveryContinuousEffect(UUID target) {
        continuousEffects.remove(target);
    }

    public static void unregisterContinuousEffect(UUID target, MobEffectInstance effect) {
        List<MobEffectInstance> effects = continuousEffects.get(target);
        if (effects != null) {
            effects.removeIf(e -> e.getEffect().equals(effect.getEffect()));
            if (effects.isEmpty()) {
                continuousEffects.remove(target);
            }
        }
    }

    /** Called every server-side entity tick by NeoForgeEventListeners. */
    public void onEntityTick(LivingEntity entity) {
        List<MobEffectInstance> effects = continuousEffects.get(entity.getUUID());
        if (effects == null) return;

        for (MobEffectInstance ce : effects) {
            var current = entity.getEffect(ce.getEffect());
            if (current == null || current.getDuration() < REFRESH_THRESHOLD) {
                entity.addEffect(new MobEffectInstance(ce));
            }
        }
    }

    /** Called on player logout by NeoForgeEventListeners to remove continuous effects. */
    public void onPlayerLeave(Player player) {
        continuousEffects.remove(player.getUUID());
    }
}
