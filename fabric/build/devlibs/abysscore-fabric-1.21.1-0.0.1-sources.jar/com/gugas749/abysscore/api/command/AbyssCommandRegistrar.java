package com.gugas749.abysscore.api.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;

import java.util.List;

public abstract class AbyssCommandRegistrar {

    /*
     *       EXAMPLE OF USE
     *
     *    public class ModCommands extends AbyssCommandRegistrar {
     *        @Override
     *        protected List<AbyssCommand> commands() {
     *            return List.of(
     *                SomeCommand::register,
     *                OtherCommand::register
     *            );
     *        }
     *    }
     *
     * Then in the NeoForge loader, on RegisterCommandsEvent:
     *    new ModCommands().register(event.getDispatcher());
     */

    protected abstract List<AbyssCommand> commands();

    /** Called from the loader's RegisterCommandsEvent handler. */
    public void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        commands().forEach(cmd -> cmd.register(dispatcher));
    }
}
